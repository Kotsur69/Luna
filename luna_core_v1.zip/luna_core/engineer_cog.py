"""
Luna Core v1.0 — Engineer Cog
Plugs the full software engineer toolkit into the Discord bot.

Commands:
  !run <language> <code>     — run code in sandbox, see stdout/stderr live
  !write <file> <code>       — write a file to the repo  
  !read <file>               — read a file
  !ls [path]                 — list files
  !fix <task>                — trigger the full self-correction loop
  !brain                     — show LUNA.md summary
  !brain update <text>       — manually add a note to LUNA.md
  !diff <file>               — show proposed changes before writing

Wake-word equivalents (natural language from iPhone):
  "Luna run this: <code>"
  "Luna write <file>: <code>"
  "Luna fix the bug in <file>"
  "Luna show me <file>"
  "Luna update your brain: <text>"
"""

from __future__ import annotations

import asyncio
import re
import textwrap
from pathlib import Path
from typing import Optional

import discord
from discord.ext import commands

from sandbox_executor import run_code, CodeResult
from file_manager import FileManager, file_manager as _fm
from self_correction import SelfCorrectionLoop
from luna_brain import LunaBrain
from config import REPO_DIR


# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _code_block(text: str, lang: str = "") -> str:
    """Wrap text in a Discord code block, splitting if necessary."""
    inner = text[:1800]
    if len(text) > 1800:
        inner += f"\n[... {len(text)-1800} chars truncated ...]"
    return f"```{lang}\n{inner}\n```"


def _extract_code_from_message(msg: str) -> tuple[str, str]:
    """Extract language + code from a message containing a code block."""
    match = re.search(r"```(\w+)?\n([\s\S]+?)```", msg)
    if match:
        lang = match.group(1) or "python"
        code = match.group(2).strip()
        return lang, code
    # No code block — treat the whole thing as python
    return "python", msg.strip()


async def _send_result(
    ctx_or_channel,
    result: CodeResult,
    label: str = "Sandbox Result",
):
    """Send a CodeResult to a Discord channel, respecting the 2000 char limit."""
    report = result.to_luna_report()
    send = ctx_or_channel.send if hasattr(ctx_or_channel, 'send') else ctx_or_channel.reply

    # Header line
    status_icon = "✅" if result.success else ("⏰" if result.timed_out else "❌")
    header = (
        f"{status_icon} **{label}** — `{result.language}` / `{result.backend}` / "
        f"`{result.runtime_ms:.0f}ms`"
    )

    # Send in chunks if needed
    chunks = [report[i:i+1900] for i in range(0, len(report), 1900)]
    first = True
    for chunk in chunks:
        if first:
            await send(f"{header}\n{chunk}")
            first = False
        else:
            await ctx_or_channel.channel.send(chunk)


# ══════════════════════════════════════════════════════════════════════════════
# ENGINEER COG
# ══════════════════════════════════════════════════════════════════════════════

class EngineerCog(commands.Cog):
    """
    Luna's software engineer capabilities as a Discord Cog.
    Attach with: await bot.add_cog(EngineerCog(bot, router, brain))
    """

    def __init__(self, bot: commands.Bot, router, brain: LunaBrain):
        self.bot    = bot
        self.router = router
        self.brain  = brain
        self.fm     = _fm

        # The correction loop needs an LLM call function.
        # We wrap the router so it always uses Gemini for engineering tasks.
        async def _llm(prompt: str) -> str:
            return await self.router.quick(prompt, engine="gemini")

        self._loop = SelfCorrectionLoop(
            llm_call     = _llm,
            file_manager = self.fm,
            brain        = self.brain,
            on_status    = None,  # set per-command below
        )

    def _make_status_sender(self, ctx: commands.Context):
        """Returns an async function that sends status updates to the Discord channel."""
        async def _send(msg: str):
            await ctx.channel.send(msg)
        return _send

    # ── !run ─────────────────────────────────────────────────────────────────

    @commands.command(name="run")
    async def cmd_run(self, ctx: commands.Context, language: str = "python", *, code: str = ""):
        """
        Run code in the sandbox. 
        Usage: !run python <code>  OR  !run python ```code block```
        """
        # Support code blocks in the message
        if "```" in (ctx.message.content + code):
            language, code = _extract_code_from_message(ctx.message.content)
        elif not code:
            return await ctx.reply("Usage: `!run python <code>` or paste a code block.")

        async with ctx.typing():
            result = await run_code(language, code)
        await _send_result(ctx, result, label="Luna ran your code")

    # ── !write ────────────────────────────────────────────────────────────────

    @commands.command(name="write")
    async def cmd_write(self, ctx: commands.Context, filepath: str = "", *, content: str = ""):
        """Write a file to the repo. Usage: !write path/to/file.py <code>"""
        if not filepath:
            return await ctx.reply("Usage: `!write path/to/file.py <content>`")

        # Extract code from code block if present
        if "```" in content:
            _, content = _extract_code_from_message(content)

        # Show diff first
        diff_result = self.fm.diff(filepath, content)
        if diff_result.content and diff_result.content != "(no changes)":
            await ctx.reply(
                f"📝 **Proposed changes to `{Path(filepath).name}`:**\n"
                + _code_block(diff_result.content[:1500], "diff")
            )

        result = self.fm.write_file(filepath, content)
        await ctx.reply(result.to_luna_report())

    # ── !read ─────────────────────────────────────────────────────────────────

    @commands.command(name="read")
    async def cmd_read(self, ctx: commands.Context, filepath: str = "", start: int = None, end: int = None):
        """
        Read a file. Usage: !read path/to/file.py [start_line end_line]
        """
        if not filepath:
            return await ctx.reply("Usage: `!read path/to/file.py` or `!read file.py 10 50`")

        if start and end:
            result = self.fm.read_lines(filepath, start, end)
        else:
            result = self.fm.read_file(filepath)

        if not result.success:
            return await ctx.reply(result.to_luna_report())

        content = result.content or ""
        ext = Path(filepath).suffix.lstrip(".")
        chunks = [content[i:i+1800] for i in range(0, max(1, len(content)), 1800)]
        await ctx.reply(f"📄 `{filepath}` ({result.bytes_affected:,} bytes):")
        for chunk in chunks[:3]:  # max 3 chunks
            await ctx.channel.send(_code_block(chunk, ext))

    # ── !ls ───────────────────────────────────────────────────────────────────

    @commands.command(name="ls")
    async def cmd_ls(self, ctx: commands.Context, path: str = None, *, flags: str = ""):
        """List files. Usage: !ls [path] [-r for recursive]"""
        recursive = "-r" in (flags or "")
        result = self.fm.list_files(path=path or str(REPO_DIR), recursive=recursive)

        if not result.success:
            return await ctx.reply(result.to_luna_report())

        entries = result.entries or []
        lines = []
        for e in entries[:60]:
            icon = "📁" if e["is_dir"] else "📄"
            lines.append(f"{icon} `{e['name']}`{' ' + e['size'] if e['size'] else ''}")

        content = "\n".join(lines) or "(empty)"
        if len(entries) > 60:
            content += f"\n…and {len(entries)-60} more"

        await ctx.reply(f"📂 `{path or REPO_DIR}`:\n{content}")

    # ── !diff ─────────────────────────────────────────────────────────────────

    @commands.command(name="diff")
    async def cmd_diff(self, ctx: commands.Context, filepath: str = "", *, new_content: str = ""):
        """Show diff between current file and proposed content."""
        if not filepath or not new_content:
            return await ctx.reply("Usage: `!diff path/to/file.py <new content>`")

        if "```" in new_content:
            _, new_content = _extract_code_from_message(new_content)

        result = self.fm.diff(filepath, new_content)
        await ctx.reply(
            f"📝 Diff for `{filepath}`:\n"
            + _code_block(result.content[:1800], "diff")
        )

    # ── !fix (Self-Correction Loop) ───────────────────────────────────────────

    @commands.command(name="fix")
    async def cmd_fix(self, ctx: commands.Context, *, task: str = ""):
        """
        Trigger Luna's self-correction loop.
        Usage: !fix add type hints to config.py
               !fix write a function that parses timestamps in utils.py
        """
        if not task:
            return await ctx.reply(
                "Tell me what to fix or build. Example:\n"
                "`!fix add input validation to the auth module`"
            )

        # Extract target file from task if mentioned
        file_match = re.search(r"\b([\w/]+\.py)\b", task)
        target_file = None
        if file_match:
            candidate = str(REPO_DIR / file_match.group(1))
            if Path(candidate).exists():
                target_file = candidate

        # Read LUNA.md for context
        brain_context = self.brain.build_context_block()

        # Inject brain context into Gemini for this session
        full_task = f"{brain_context}\n\nTask: {task}"

        # Wire status updates to this Discord channel
        status_channel = ctx.channel
        async def _status(msg: str):
            await status_channel.send(msg)

        self._loop._status = _status
        self._loop._llm = lambda p: self.router.quick(
            f"{brain_context}\n\n{p}", engine="gemini"
        )

        session = await self._loop.run(
            task        = task,
            target_file = target_file,
            language    = "python",
        )

        # Final summary
        await ctx.channel.send(
            f"```\n{session.summary()}\n```"
        )

    # ── !brain ────────────────────────────────────────────────────────────────

    @commands.command(name="brain")
    async def cmd_brain(self, ctx: commands.Context, action: str = "show", *, content: str = ""):
        """
        Interact with LUNA.md.
        Usage:
          !brain                     — show stats + recent log
          !brain show                — show full LUNA.md
          !brain update <note>       — add a note to Technical Notes
          !brain status <text>       — update Project Status
          !brain bug <description>   — log a known bug
        """
        if action == "show" or action == "read":
            full = self.brain.read()
            chunks = [full[i:i+1900] for i in range(0, len(full), 1900)]
            await ctx.reply(f"🧠 **LUNA.md** ({self.brain.word_count()} words):")
            for chunk in chunks[:4]:
                await ctx.channel.send(_code_block(chunk, "md"))
            return

        if action in ("update", "note", "learn"):
            if not content:
                return await ctx.reply("What should I add? `!brain update <note>`")
            self.brain.prepend_to_section("Technical Notes", content)
            await ctx.reply(f"🧠 Added to Technical Notes: *{content[:80]}*")
            return

        if action == "status":
            if not content:
                return await ctx.reply("What's the status? `!brain status <text>`")
            self.brain.update_project_status(content)
            await ctx.reply(f"📍 Project status updated.")
            return

        if action == "bug":
            if not content:
                return await ctx.reply("Describe the bug. `!brain bug <description>`")
            self.brain.prepend_to_section("Known Bugs", f"[OPEN] {content}")
            await ctx.reply(f"🐛 Bug logged: *{content[:80]}*")
            return

        if action in ("stats", "summary"):
            s = self.brain.stats()
            await ctx.reply(
                f"🧠 **LUNA.md Stats**\n"
                f"```\n"
                f"Lines:      {s['lines']}\n"
                f"Words:      {s['words']}\n"
                f"Sections:   {s['sections']}\n"
                f"Log entries:{s['log_entries']}\n"
                f"Open bugs:  {s['open_bugs']}\n"
                f"```"
            )
            return

        # Default: show stats
        s = self.brain.stats()
        log = self.brain.read_section("Session Log")[:800]
        await ctx.reply(
            f"🧠 **LUNA.md** — {s['words']} words · {s['open_bugs']} open bugs\n"
            f"**Recent Log:**\n{_code_block(log, 'md')}"
        )

    # ── !tools ────────────────────────────────────────────────────────────────

    @commands.command(name="tools")
    async def cmd_tools(self, ctx: commands.Context):
        """Show all MCP tools Luna has available. Usage: !tools"""
        from mcp_client import toolbox
        if not toolbox.tool_count:
            return await ctx.reply(
                "🧰 No MCP tools connected right now.\n"
                "Edit `mcp_servers.json` to enable servers, then restart."
            )
        desc = toolbox.describe_toolbox()
        await ctx.reply(f"🧰 **Luna's MCP Toolbox** — {toolbox.tool_count} tools\n{_code_block(desc)}")

    # ── !devlog ───────────────────────────────────────────────────────────────

    @commands.command(name="devlog")
    async def cmd_devlog(self, ctx: commands.Context, action: str = "show", *, query: str = ""):
        """
        Inspect Luna's dev log.
        Usage:
          !devlog                     — last 15 actions
          !devlog file config.py      — what touched config.py
          !devlog blame               — what changed before the last error
          !devlog failures            — recent failures only
          !devlog stats               — totals
        """
        from dev_log import dev_log

        if action in ("show", "recent"):
            entries = dev_log.recent_changes(minutes=180, limit=15)
            if not entries:
                return await ctx.reply("📋 No dev log entries yet.")
            lines = [e.to_oneliner() for e in entries]
            await ctx.reply(
                f"📋 **Dev Log** (last 3h)\n" + _code_block("\n".join(lines))
            )

        elif action == "file":
            if not query:
                return await ctx.reply("Which file? `!devlog file config.py`")
            entries = dev_log.changes_to_file(query, limit=15)
            lines   = [e.to_oneliner() for e in entries] or ["(no entries for this file)"]
            await ctx.reply(
                f"📋 **Changes to `{query}`**\n" + _code_block("\n".join(lines))
            )

        elif action == "blame":
            report = dev_log.build_blame_report(query or "recent error", window_minutes=15)
            await ctx.reply(f"🔍 **Blame Report**\n{_code_block(report)}")

        elif action == "failures":
            entries = dev_log.get_failures(limit=10)
            lines   = [e.to_oneliner() for e in entries] or ["(no failures recorded)"]
            await ctx.reply(
                f"❌ **Recent Failures**\n" + _code_block("\n".join(lines))
            )

        elif action == "stats":
            s = dev_log.stats()
            await ctx.reply(
                f"📊 **Dev Log Stats**\n"
                f"```\n"
                f"Total entries:  {s.get('total', 0)}\n"
                f"Successes:      {s.get('successes', 0)}\n"
                f"Failures:       {s.get('failures', 0)}\n"
                f"Known breaks:   {s.get('known_breaks', 0)}\n"
                f"Files touched:  {s.get('files_touched', 0)}\n"
                f"```"
            )

        else:
            await ctx.reply(
                "Usage: `!devlog` / `!devlog file <name>` / `!devlog blame` / "
                "`!devlog failures` / `!devlog stats`"
            )

    # ── !audit ────────────────────────────────────────────────────────────────

    @commands.command(name="audit")
    async def cmd_audit(self, ctx: commands.Context, n: int = 15):
        """Show the file manager audit log. Usage: !audit [n]"""
        log = self.fm.audit_log(last_n=min(n, 40))
        await ctx.reply(f"📋 **File Manager Audit Log (last {n})**\n{_code_block(log)}")
