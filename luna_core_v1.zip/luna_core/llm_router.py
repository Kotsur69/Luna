"""
Luna Core v1.0 — Dual LLM Client
  • Ollama  → instant local chat (sub-second, no cost, no internet)
  • Gemini  → deep repository-wide code analysis (cached context)
  • Gemini  → live Google Search grounding (weather, crypto, news, etc.)

Routing logic:
  - 'search' intent  → Gemini + Google Search grounding  (no scraper needed)
  - 'code'   intent  → Gemini + full repo context cache
  - 'chat'   intent  → Ollama local
"""

import asyncio
import json
import re
from typing import AsyncIterator, Optional

import httpx
import google.generativeai as genai

from config import (
    OLLAMA_BASE_URL, OLLAMA_MODEL, OLLAMA_TIMEOUT,
    GEMINI_API_KEY, GEMINI_MODEL, GEMINI_MAX_TOKENS,
)
from memory_engine import MemoryEngine
from context_packer import ContextPacker, RepoContext
from personality import (
    get_chat_prompt, get_code_prompt, get_voice_prompt,
    get_cached_base_prompt, prepare_for_tts,
)
from mcp_client import MCPToolbox, run_agentic_turn, toolbox as _default_toolbox
from dev_log import dev_log as _dev_log, update_dev_log


# ── Message Classification ────────────────────────────────────────────────────

CODE_INTENT_PATTERNS = [
    r"\bfix\b", r"\bbug\b", r"\banalyze\b", r"\banalyse\b", r"\breview\b",
    r"\bexplain\b.*\bcode\b", r"\brefactor\b", r"\boptimize\b", r"\bwhat does\b.*\bdo\b",
    r"\bwhy (is|does|did)\b", r"\berror\b", r"\bexception\b", r"\btraceback\b",
    r"\bimport\b", r"\bfunction\b", r"\bclass\b", r"\bmodule\b",
]

# Queries that need live internet data — routed to Gemini with Google Search grounding.
# Gemini detects it needs fresh info, fires a search, weaves results into its answer.
GROUNDING_INTENT_PATTERNS = [
    # Weather
    r"\bweather\b", r"\btemperature\b", r"\brain(ing)?\b", r"\bforecast\b",
    r"\bhumidity\b", r"\bsnow(ing)?\b", r"\bwindy\b",
    # Finance / markets
    r"\bcrypto\b", r"\bcoin\b", r"\bbitcoin\b", r"\bethereum\b", r"\bsolana\b",
    r"\bstock\b", r"\bprice of\b", r"\bmarket\b", r"\btrading\b",
    r"\bmoving (today|now|atm|right now)\b",
    r"\bvalue of\b", r"\bexchange rate\b", r"\busd\b.*\beur\b", r"\beur\b.*\busd\b",
    # News / current events
    r"\blatest\b", r"\bbreaking\b", r"\bnews\b", r"\btoday\b.*\b(happen|event)\b",
    r"\bwhat.s happening\b", r"\btrending\b",
    # Live lookups
    r"\bright now\b", r"\bcurrently\b", r"\blive (score|result|update)\b",
    r"\bwho (won|is winning|leads)\b",
    # Explicit search signals
    r"\blook (it )?up\b", r"\bsearch (for|about)\b", r"\bgoogle\b",
    r"\bfind out\b", r"\bwhat is the (current|latest|best|top)\b",
]

def classify_intent(message: str) -> str:
    """
    Returns one of three routing lanes:
      'search' → Gemini + Google Search grounding  (live data, no repo context needed)
      'code'   → Gemini + repo context cache        (deep code analysis)
      'chat'   → Ollama local                       (instant, free, offline)
    """
    lower = message.lower()

    # Grounding check runs FIRST — a question about crypto prices is search, not code,
    # even if it mentions words that overlap with code patterns.
    for pattern in GROUNDING_INTENT_PATTERNS:
        if re.search(pattern, lower):
            return "search"

    for pattern in CODE_INTENT_PATTERNS:
        if re.search(pattern, lower):
            return "code"

    return "chat"


# ── Ollama Client ─────────────────────────────────────────────────────────────

class OllamaClient:
    """
    Streams responses from a local Ollama instance.
    Maintains a sliding conversation history for multi-turn context.
    """

    def __init__(self, model: str = OLLAMA_MODEL):
        self.model   = model
        self.history: list[dict] = []
        self._client = httpx.AsyncClient(base_url=OLLAMA_BASE_URL, timeout=OLLAMA_TIMEOUT)
        print(f"[Ollama] Client ready → {OLLAMA_BASE_URL} / model={model}")

    async def chat(
        self,
        user_message: str,
        system_override: str = "",
        stream: bool = True,
        memory_block: str = "",
    ) -> AsyncIterator[str]:
        """Yields streamed text chunks from Ollama."""

        system = system_override or get_chat_prompt(
            memories=[memory_block] if memory_block else None
        )

        # Build messages
        messages = [{"role": "system", "content": system}]
        messages.extend(self.history[-20:])          # last 10 turns
        messages.append({"role": "user", "content": user_message})

        payload = {
            "model":    self.model,
            "messages": messages,
            "stream":   stream,
            "options":  {"temperature": 0.8, "top_p": 0.9},
        }

        full_response = ""
        async with self._client.stream("POST", "/api/chat", json=payload) as resp:
            async for line in resp.aiter_lines():
                if not line.strip():
                    continue
                try:
                    chunk = json.loads(line)
                    token = chunk.get("message", {}).get("content", "")
                    full_response += token
                    yield token
                    if chunk.get("done"):
                        break
                except json.JSONDecodeError:
                    continue

        # Update history
        self.history.append({"role": "user",      "content": user_message})
        self.history.append({"role": "assistant",  "content": full_response})

        # Trim history to last 20 messages
        if len(self.history) > 40:
            self.history = self.history[-40:]

    async def quick_reply(self, message: str, memory_block: str = "") -> str:
        """Non-streaming convenience wrapper."""
        chunks = []
        async for chunk in self.chat(message, stream=True, memory_block=memory_block):
            chunks.append(chunk)
        return "".join(chunks)

    async def health_check(self) -> bool:
        try:
            resp = await self._client.get("/api/tags", timeout=5)
            return resp.status_code == 200
        except Exception:
            return False

    async def close(self):
        await self._client.aclose()


# ── Gemini Client ─────────────────────────────────────────────────────────────

class GeminiClient:
    """
    Uses the Gemini API with optional context caching.
    When a cache_name is provided, the full codebase is NOT re-sent —
    Gemini reads it from cache, saving ~80–95% of input token costs.
    """

    def __init__(self):
        genai.configure(api_key=GEMINI_API_KEY)
        self._model_name  = GEMINI_MODEL
        self._active_model: Optional[genai.GenerativeModel] = None
        self._cache_name:   Optional[str] = None
        print(f"[Gemini] Client ready → model={GEMINI_MODEL}")

    def attach_cache(self, cache_name: str):
        """Attach a Gemini context cache. All subsequent calls will use it."""
        self._cache_name   = cache_name
        self._active_model = genai.GenerativeModel.from_cached_content(
            cached_content = cache_name
        )
        print(f"[Gemini] Cache attached: {cache_name}")

    def detach_cache(self):
        """Fall back to a plain model (no cached codebase)."""
        self._cache_name   = None
        self._active_model = genai.GenerativeModel(
            model_name        = self._model_name,
            system_instruction= get_cached_base_prompt(),
        )
        print("[Gemini] Cache detached — using plain model.")

    async def analyze(
        self,
        prompt: str,
        memory_block: str = "",
        stream: bool = True,
    ) -> AsyncIterator[str]:
        """
        Run a code analysis prompt against the cached repository context.
        Yields streamed text chunks.
        """
        if not self._active_model:
            self.detach_cache()

        full_prompt = prompt
        if memory_block:
            full_prompt = f"{memory_block}\n\n{prompt}"

        generation_config = genai.types.GenerationConfig(
            max_output_tokens = GEMINI_MAX_TOKENS,
            temperature       = 0.4,   # lower = more precise for code
            top_p             = 0.85,
        )

        try:
            if stream:
                response = await asyncio.to_thread(
                    self._active_model.generate_content,
                    full_prompt,
                    generation_config = generation_config,
                    stream            = True,
                )
                full_text = ""
                for chunk in response:
                    text = chunk.text if hasattr(chunk, "text") else ""
                    full_text += text
                    yield text
            else:
                response = await asyncio.to_thread(
                    self._active_model.generate_content,
                    full_prompt,
                    generation_config = generation_config,
                )
                yield response.text

        except Exception as e:
            yield f"\n[Gemini Error] {e}\n"

    async def grounded_search(
        self,
        prompt: str,
        memory_block: str = "",
        stream: bool = True,
    ) -> AsyncIterator[str]:
        """
        Ask Gemini a question with Google Search grounding enabled.

        Gemini decides internally whether a web search is needed, fires it
        automatically, and weaves the live results into its answer — all in
        one API call. No scraper, no extra API keys, no latency overhead.

        NOTE: Google Search grounding cannot be combined with context caching,
        so this always uses a fresh plain model. That's fine — search queries
        don't need the 40k-line codebase in context anyway.

        Sources used are available in response.candidates[0].grounding_metadata
        and are appended as a compact citation block at the end of the response.
        """
        # Build the grounding tool — the one-line switch that enables this whole feature
        search_tool = genai.protos.Tool(
            google_search_retrieval=genai.protos.GoogleSearchRetrieval()
        )

        # Fresh model — grounding is incompatible with cached_content
        model = genai.GenerativeModel(
            model_name        = self._model_name,
            system_instruction= get_cached_base_prompt(),
        )

        full_prompt = prompt
        if memory_block:
            full_prompt = f"{memory_block}\n\n{prompt}"

        generation_config = genai.types.GenerationConfig(
            max_output_tokens = GEMINI_MAX_TOKENS,
            temperature       = 0.7,   # slightly higher than code — conversational answers
            top_p             = 0.90,
        )

        try:
            if stream:
                response = await asyncio.to_thread(
                    model.generate_content,
                    full_prompt,
                    tools             = [search_tool],
                    generation_config = generation_config,
                    stream            = True,
                )
                full_text = ""
                for chunk in response:
                    text = chunk.text if hasattr(chunk, "text") else ""
                    full_text += text
                    yield text

                # Append grounding source citations if available
                try:
                    sources = _extract_grounding_sources(response)
                    if sources:
                        yield f"\n\n{sources}"
                except Exception:
                    pass  # citations are a nice-to-have, never block the response

            else:
                response = await asyncio.to_thread(
                    model.generate_content,
                    full_prompt,
                    tools             = [search_tool],
                    generation_config = generation_config,
                )
                text = response.text or ""
                try:
                    sources = _extract_grounding_sources(response)
                    if sources:
                        text += f"\n\n{sources}"
                except Exception:
                    pass
                yield text

        except Exception as e:
            yield f"\n[Gemini Search Error] {e}\n"


def _extract_grounding_sources(response) -> str:
    """
    Pull source URLs and titles from Gemini's grounding_metadata.
    Returns a compact citation block like:
      📡 *Sources: [Reuters](url) · [CoinGecko](url)*
    """
    try:
        candidates = response.candidates
        if not candidates:
            return ""
        meta = getattr(candidates[0], "grounding_metadata", None)
        if not meta:
            return ""
        chunks = getattr(meta, "grounding_chunks", []) or []
        seen, parts = set(), []
        for chunk in chunks:
            web = getattr(chunk, "web", None)
            if not web:
                continue
            url   = getattr(web, "uri",   "") or ""
            title = getattr(web, "title", "") or url
            if url and url not in seen:
                seen.add(url)
                parts.append(f"[{title[:40]}]({url})")
        if parts:
            return "📡 *Sources: " + " · ".join(parts[:5]) + "*"
    except Exception:
        pass
    return ""


        """
        Focused analysis of a single file.
        If the file content is available in the packer, injects it directly.
        """
        content = packer.get_file_content(filename)
        if content:
            prompt = (
                f"Focus on the file `{filename}`:\n\n"
                f"```python\n{content}\n```\n\n"
                f"Task: {task}"
            )
        else:
            prompt = f"Analyze `{filename}` from the codebase. Task: {task}"

        chunks = []
        async for chunk in self.analyze(prompt):
            chunks.append(chunk)
        return "".join(chunks)

    async def health_check(self) -> bool:
        try:
            model = genai.GenerativeModel(self._model_name)
            resp  = await asyncio.to_thread(
                model.generate_content, "Say 'ok'",
                generation_config=genai.types.GenerationConfig(max_output_tokens=5)
            )
            return bool(resp.text)
        except Exception:
            return False


# ── Unified Router ────────────────────────────────────────────────────────────

class LunaLLMRouter:
    """
    The main entry point for all LLM interactions.
    Automatically routes to Ollama (fast chat) or Gemini (deep code analysis).
    """

    def __init__(self, memory: MemoryEngine, packer: ContextPacker, toolbox: MCPToolbox = None):
        self.memory   = memory
        self.packer   = packer
        self.ollama   = OllamaClient()
        self.gemini   = GeminiClient()
        self.toolbox  = toolbox or _default_toolbox
        self._repo_ctx: Optional[RepoContext] = None

    async def initialize(self):
        """Pack the repo, prime the Gemini cache, and connect MCP servers on startup."""
        print("[Router] Initializing — packing repo...")
        self._repo_ctx = self.packer.pack()
        mem_block = self.memory.build_injection_block()

        cache_name = self.packer.get_or_create_gemini_cache(
            self._repo_ctx, memory_block=mem_block
        )
        if cache_name:
            self.gemini.attach_cache(cache_name)
        else:
            self.gemini.detach_cache()

        # Connect MCP toolbox (non-fatal if no servers are enabled)
        try:
            await self.toolbox.connect()
            if self.toolbox.tool_count:
                print(f"[Router] MCP toolbox: {self.toolbox.tool_count} tools ready")
        except Exception as e:
            print(f"[Router] MCP connect failed (non-fatal): {e}")

        ollama_ok  = await self.ollama.health_check()
        gemini_ok  = await self.gemini.health_check()
        print(f"[Router] Ollama: {'✓' if ollama_ok else '✗'}  |  Gemini: {'✓' if gemini_ok else '✗'}  |  MCP tools: {self.toolbox.tool_count}")
        update_dev_log("startup", "success", description=f"Router initialized. MCP tools: {self.toolbox.tool_count}")
        return self

    async def respond(
        self,
        message: str,
        force_engine: Optional[str] = None,  # "ollama" | "gemini" | "search" | None
        stream: bool = True,
    ) -> AsyncIterator[str]:
        """
        Main dispatch. Yields text chunks.
        force_engine overrides auto-routing.

        Three lanes:
          'search' → Gemini + Google Search grounding (live web data)
          'code'   → Gemini + cached repo context
          'chat'   → Ollama (local, instant)
        """
        intent    = force_engine or classify_intent(message)
        mem_block = self.memory.build_injection_block(query=message)

        # Inject toolbox description into memory block so Luna knows her skills
        if self.toolbox.tool_count:
            tool_desc  = self.toolbox.describe_toolbox()
            mem_block  = f"{tool_desc}\n\n{mem_block}" if mem_block else tool_desc

        if intent == "search":
            print(f"[Router] → Gemini + Google Search grounding")
            update_dev_log("llm_call", "success", description=f"Grounded search: {message[:60]}")
            async for chunk in self.gemini.grounded_search(
                message, memory_block=mem_block, stream=stream
            ):
                yield chunk

        elif intent in ("chat", "ollama"):
            print(f"[Router] → Ollama (intent={intent})")
            async for chunk in self.ollama.chat(message, memory_block=mem_block, stream=stream):
                yield chunk

        else:  # code / gemini — potentially with MCP tool calls
            print(f"[Router] → Gemini repo context (intent={intent})")
            update_dev_log("llm_call", "success", description=f"Code analysis: {message[:60]}")

            # Refresh cache if repo has changed
            new_ctx = self.packer.pack()
            if new_ctx.repo_hash != (self._repo_ctx.repo_hash if self._repo_ctx else ""):
                print("[Router] Repo changed — refreshing Gemini cache...")
                self._repo_ctx = new_ctx
                cache_name = self.packer.get_or_create_gemini_cache(new_ctx, mem_block)
                if cache_name:
                    self.gemini.attach_cache(cache_name)

            # If MCP tools are available, use the agentic loop (tool calling capable)
            if self.toolbox.tool_count and self.gemini._active_model:
                full_prompt = f"{mem_block}\n\n{message}" if mem_block else message
                text, tool_log = await run_agentic_turn(
                    self.gemini._active_model, full_prompt, self.toolbox
                )
                for call in tool_log:
                    update_dev_log("mcp_tool_call", "success",
                                   description=f"Called {call['tool']}", function_name=call['tool'])
                yield text
            else:
                async for chunk in self.gemini.analyze(message, memory_block=mem_block, stream=stream):
                    yield chunk

    async def quick(self, message: str, engine: str = None) -> str:
        """Non-streaming convenience wrapper."""
        chunks = []
        async for c in self.respond(message, force_engine=engine, stream=True):
            chunks.append(c)
        return "".join(chunks)

    async def teardown(self):
        await self.ollama.close()
