"""
Luna Core v1.0 — Luna Brain (LUNA.md Manager)
════════════════════════════════════════════════════════════════════════════════

LUNA.md is Luna's own notebook — her long-term technical memory that persists
across every session restart. It's not just a log file. It's a living document
that shapes how she approaches problems.

Structure of LUNA.md:
  ## Project Status       — current state of what's being built
  ## Active Tasks         — things Luna is mid-way through
  ## Known Bugs           — bugs she's tracking (with status)
  ## Technical Notes      — things she learned that will matter again
  ## Session Log          — timestamped record of completed tasks
  ## API Quirks           — notes on flaky/tricky external dependencies

Luna reads this at the start of every coding session.
Luna updates it every time she completes (or fails) a coding task.

════════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import re
import asyncio
from datetime import datetime
from pathlib import Path
from typing import Optional

from config import LUNA_BRAIN_PATH, REPO_DIR


# ══════════════════════════════════════════════════════════════════════════════
# LUNA.md TEMPLATE — written on first run
# ══════════════════════════════════════════════════════════════════════════════

LUNA_MD_TEMPLATE = """\
# 🌙 LUNA.md — Luna's Technical Brain Dump
> This file is Luna's own persistent memory across sessions.
> It is read at the start of every coding task and updated after each one.
> Last updated: {timestamp}

---

## 📍 Project Status
<!-- Luna updates this to reflect the current state of the project -->
- Project: Not yet set. Luna will fill this in.
- Last active file: —
- Overall health: Unknown (no tasks completed yet)

---

## 🔧 Active Tasks
<!-- Things Luna is mid-way through. Moved to Session Log when done. -->
- (none yet)

---

## 🐛 Known Bugs
<!-- Format: [STATUS] description | file:line | first seen -->
- (none tracked yet)

---

## 📚 Technical Notes
<!-- Hard-won lessons. The kind of thing Luna would tell herself if starting over. -->
- (none yet — these accumulate as Luna works)

---

## ⚠️ API & Library Quirks
<!-- Gotchas, rate limits, weird behavior, version-specific issues -->
- (none noted yet)

---

## 📓 Session Log
<!-- Newest entries at top. Format: [timestamp] task | outcome | attempts -->
- (no tasks completed yet)

---
*Luna updates this file. Do not edit manually unless you want her to get confused.*
""".strip()


# ══════════════════════════════════════════════════════════════════════════════
# BRAIN SECTIONS
# ══════════════════════════════════════════════════════════════════════════════

SECTIONS = [
    "Project Status",
    "Active Tasks",
    "Known Bugs",
    "Technical Notes",
    "API & Library Quirks",
    "Session Log",
]


# ══════════════════════════════════════════════════════════════════════════════
# LUNA BRAIN
# ══════════════════════════════════════════════════════════════════════════════

class LunaBrain:
    """
    Manages LUNA.md — Luna's persistent technical memory.
    """

    def __init__(self, path: Path = LUNA_BRAIN_PATH):
        self.path = path
        self._ensure_exists()
        print(f"[Brain] LUNA.md at: {self.path}")

    # ── Initialization ────────────────────────────────────────────────────────

    def _ensure_exists(self):
        if not self.path.exists():
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(
                LUNA_MD_TEMPLATE.format(timestamp=self._ts()),
                encoding="utf-8"
            )
            print(f"[Brain] Created new LUNA.md at {self.path}")

    # ── Read ─────────────────────────────────────────────────────────────────

    def read(self) -> str:
        """Read the full LUNA.md content."""
        return self.path.read_text(encoding="utf-8")

    def read_section(self, section_name: str) -> str:
        """Extract a specific section from LUNA.md."""
        content = self.read()
        pattern = rf"##[^#].*{re.escape(section_name)}.*?\n([\s\S]*?)(?=\n##|\Z)"
        match   = re.search(pattern, content, re.IGNORECASE)
        return match.group(1).strip() if match else ""

    def build_context_block(self) -> str:
        """
        Returns a formatted block for injection into LLM prompts.
        Luna reads this at the start of every coding session.
        """
        content = self.read()
        return (
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            "LUNA'S TECHNICAL MEMORY (LUNA.md)\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            "Read this before starting any technical task. These are your own notes.\n\n"
            f"{content}\n"
        )

    # ── Section Updates ───────────────────────────────────────────────────────

    def update_section(self, section_name: str, new_content: str) -> bool:
        """Replace the content of a named section."""
        content = self.read()
        # Find the section header
        pattern = rf"(##[^#].*{re.escape(section_name)}.*?\n)([\s\S]*?)(?=\n##|\Z)"
        replacement = rf"\g<1>{new_content}\n"
        new_content_full, n = re.subn(pattern, replacement, content, flags=re.IGNORECASE)
        if n == 0:
            # Section not found — append it
            new_content_full = content.rstrip() + f"\n\n## {section_name}\n{new_content}\n"

        new_content_full = self._update_timestamp(new_content_full)
        self.path.write_text(new_content_full, encoding="utf-8")
        return n > 0

    def prepend_to_section(self, section_name: str, new_line: str) -> bool:
        """Add a line to the top of a section (newest first)."""
        current = self.read_section(section_name)
        placeholder_patterns = [r"\(none.*?\)", r"\(no tasks.*?\)", r"\(not yet.*?\)"]
        cleaned = current
        for p in placeholder_patterns:
            cleaned = re.sub(p, "", cleaned, flags=re.IGNORECASE).strip()

        new_block = f"- {new_line}\n{cleaned}".strip()
        return self.update_section(section_name, new_block)

    # ── High-level update helpers ─────────────────────────────────────────────

    def record_task_completion(
        self,
        task:      str,
        outcome:   str,          # "success" | "gave_up" | "partial"
        file_path: str    = None,
        attempts:  int    = 1,
        lesson:    str    = None,
        new_bug:   str    = None,
        api_quirk: str    = None,
    ) -> str:
        """
        Called by SelfCorrectionLoop after every task attempt.
        Updates Session Log, optionally adds a lesson and/or bug.
        Returns a summary string.
        """
        ts  = self._ts()
        icon = {"success": "✅", "gave_up": "🏳️", "partial": "⚠️"}.get(outcome, "📝")
        file_note = f" | `{Path(file_path).name}`" if file_path else ""
        attempts_note = f" | {attempts} attempt{'s' if attempts > 1 else ''}"

        log_line = f"[{ts}] {icon} {task[:80]}{file_note}{attempts_note}"
        self.prepend_to_section("Session Log", log_line)

        if lesson:
            self.prepend_to_section("Technical Notes", f"[{ts}] {lesson}")

        if new_bug:
            self.prepend_to_section("Known Bugs",
                f"[OPEN] {new_bug} | detected {ts[:10]}"
            )

        if api_quirk:
            self.prepend_to_section("API & Library Quirks",
                f"[{ts[:10]}] {api_quirk}"
            )

        return log_line

    def update_project_status(self, status: str, active_file: str = None):
        """Update the project status section."""
        ts   = self._ts()
        file = f"\n- Last active file: `{active_file}`" if active_file else ""
        block = f"- Updated: {ts}\n- {status}{file}"
        self.update_section("Project Status", block)

    def add_active_task(self, task: str):
        """Add a task to Active Tasks."""
        self.prepend_to_section("Active Tasks", f"[IN PROGRESS] {task}")

    def complete_active_task(self, task: str):
        """Mark a task in Active Tasks as done and move to log."""
        content = self.read_section("Active Tasks")
        # Try to find and mark the task as complete
        updated = re.sub(
            rf"\[IN PROGRESS\]\s*{re.escape(task[:40])}[^\n]*",
            f"[DONE] {task[:80]}",
            content,
        )
        self.update_section("Active Tasks", updated)

    def mark_bug_fixed(self, bug_description: str):
        """Mark a bug in Known Bugs as fixed."""
        content = self.read_section("Known Bugs")
        updated = re.sub(
            rf"\[OPEN\]\s*[^\n]*{re.escape(bug_description[:30])}[^\n]*",
            lambda m: m.group(0).replace("[OPEN]", f"[FIXED {self._ts()[:10]}]"),
            content,
        )
        self.update_section("Known Bugs", updated)

    # ── LLM-powered update ────────────────────────────────────────────────────

    async def smart_update(self, llm_call, task: str, outcome: str, context: str):
        """
        Ask the LLM to synthesize the session into LUNA.md updates.
        More expensive but produces richer notes.
        """
        current = self.read()
        prompt = f"""
You are Luna. You just completed (or attempted) the following task:
Task: {task}
Outcome: {outcome}
Context / notes from this session:
{context[:2000]}

Current LUNA.md:
{current[:3000]}

Generate updated content for these sections of LUNA.md:
1. Technical Notes — any new lessons from this session
2. Known Bugs — any bugs discovered or fixed
3. API & Library Quirks — any quirky behavior you noticed

Respond ONLY with a JSON object:
{{
  "technical_notes": "new note line or null",
  "new_bug": "bug description or null",
  "bug_fixed": "description of fixed bug or null",
  "api_quirk": "quirk noted or null"
}}
        """.strip()

        import json, re as _re
        raw = await llm_call(prompt)
        match = _re.search(r"\{[\s\S]*\}", raw)
        if match:
            try:
                parsed = json.loads(match.group(0))
                self.record_task_completion(
                    task      = task,
                    outcome   = outcome,
                    lesson    = parsed.get("technical_notes"),
                    new_bug   = parsed.get("new_bug"),
                    api_quirk = parsed.get("api_quirk"),
                )
                if parsed.get("bug_fixed"):
                    self.mark_bug_fixed(parsed["bug_fixed"])
            except Exception as e:
                print(f"[Brain] smart_update parse error: {e}")

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _ts() -> str:
        return datetime.utcnow().strftime("%Y-%m-%d %H:%M")

    def _update_timestamp(self, content: str) -> str:
        return re.sub(
            r"Last updated:.*",
            f"Last updated: {self._ts()}",
            content,
        )

    def word_count(self) -> int:
        return len(self.read().split())

    def stats(self) -> dict:
        content = self.read()
        lines   = content.splitlines()
        return {
            "lines":      len(lines),
            "words":      len(content.split()),
            "size_bytes": len(content.encode()),
            "sections":   len(re.findall(r"^##\s", content, re.MULTILINE)),
            "log_entries":len(re.findall(r"^\- \[\d{4}", content, re.MULTILINE)),
            "open_bugs":  len(re.findall(r"\[OPEN\]", content)),
        }

    def __repr__(self):
        s = self.stats()
        return f"<LunaBrain {self.path.name} | {s['words']} words | {s['open_bugs']} open bugs>"
