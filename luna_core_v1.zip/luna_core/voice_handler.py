"""
Luna Core v1.0 — Voice Handler
  • TTS synthesis (edge-tts by default, ElevenLabs premium optional)
  • ffmpeg audio pipeline → PCM stream
  • discord.py VoiceClient integration (PyNaCl handles encryption)

Usage:
    handler = VoiceHandler()
    await handler.speak(voice_client, "Hey, I found a bug in your auth module.")
"""

import asyncio
import io
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

import discord

from config import (
    TTS_ENGINE, TTS_VOICE, FFMPEG_PATH,
    ELEVENLABS_API_KEY, ELEVENLABS_VOICE_ID,
)


# ── Audio Source: ffmpeg PCM ──────────────────────────────────────────────────

class LunaAudioSource(discord.PCMVolumeTransformer):
    """
    Wraps an in-memory audio buffer through an ffmpeg subprocess
    and feeds it to discord.py's voice pipeline.
    PyNaCl handles the Opus encryption transparently.
    """

    def __init__(self, audio_data: bytes, volume: float = 0.85):
        source = discord.FFmpegPCMAudio(
            source     = io.BytesIO(audio_data),
            pipe       = True,
            executable = FFMPEG_PATH,
            options    = "-vn",                          # audio only
            before_options = (
                "-reconnect 1 -reconnect_streamed 1 "
                "-reconnect_delay_max 5"
            ),
        )
        super().__init__(source, volume=volume)


# ── TTS Backends ──────────────────────────────────────────────────────────────

async def _tts_edge(text: str, voice: str = TTS_VOICE) -> bytes:
    """
    Microsoft Edge TTS — free, high quality, 300+ voices.
    Requires: pip install edge-tts
    """
    import edge_tts

    with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp:
        tmp_path = tmp.name

    communicate = edge_tts.Communicate(text, voice)
    await communicate.save(tmp_path)

    with open(tmp_path, "rb") as f:
        data = f.read()

    os.unlink(tmp_path)
    return data


async def _tts_elevenlabs(text: str) -> bytes:
    """
    ElevenLabs — ultra-realistic voices (requires API key + credits).
    Requires: pip install elevenlabs
    """
    import httpx
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            f"https://api.elevenlabs.io/v1/text-to-speech/{ELEVENLABS_VOICE_ID}/stream",
            headers={
                "xi-api-key":   ELEVENLABS_API_KEY,
                "Content-Type": "application/json",
            },
            json={
                "text":           text,
                "model_id":       "eleven_turbo_v2",
                "voice_settings": {"stability": 0.45, "similarity_boost": 0.80},
            },
            timeout=30,
        )
        resp.raise_for_status()
        return resp.content


async def _tts_fallback(text: str) -> bytes:
    """
    System espeak fallback — always available, robotic but functional.
    """
    proc = await asyncio.create_subprocess_exec(
        "espeak", "-w", "/tmp/luna_tts.wav", text,
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.DEVNULL,
    )
    await proc.wait()
    return Path("/tmp/luna_tts.wav").read_bytes()


# ── Voice Handler ─────────────────────────────────────────────────────────────

class VoiceHandler:
    """
    Manages TTS synthesis and Discord voice channel streaming.
    Thread-safe: maintains one active VC connection per guild.
    """

    def __init__(self):
        self._engine    = TTS_ENGINE
        self._vc_map: dict[int, discord.VoiceClient] = {}   # guild_id → vc
        print(f"[Voice] Handler initialized → engine={self._engine}")

    # ── TTS ───────────────────────────────────────────────────────────────────

    async def synthesize(self, text: str) -> bytes:
        """Convert text to audio bytes using the configured engine."""
        # Sanitize: strip markdown, code fences, excess whitespace
        clean = self._clean_text(text)
        if not clean.strip():
            return b""

        try:
            if self._engine == "edge-tts":
                return await _tts_edge(clean)
            elif self._engine == "elevenlabs" and ELEVENLABS_API_KEY:
                return await _tts_elevenlabs(clean)
            else:
                return await _tts_fallback(clean)
        except Exception as e:
            print(f"[Voice] TTS error ({self._engine}): {e} — falling back")
            try:
                return await _tts_fallback(clean)
            except Exception:
                return b""

    def _clean_text(self, text: str) -> str:
        """Strip code blocks and markdown for speech synthesis."""
        import re
        # Remove code fences
        text = re.sub(r"```[\s\S]*?```", "[code block]", text)
        text = re.sub(r"`[^`]+`", "", text)
        # Remove markdown symbols
        text = re.sub(r"[*_~#>]", "", text)
        # Collapse whitespace
        text = re.sub(r"\s+", " ", text).strip()
        return text

    # ── Discord Voice ─────────────────────────────────────────────────────────

    async def join_channel(
        self,
        channel: discord.VoiceChannel,
        guild_id: int,
    ) -> discord.VoiceClient:
        """Join or move to a voice channel."""
        existing = self._vc_map.get(guild_id)

        if existing and existing.is_connected():
            if existing.channel.id != channel.id:
                await existing.move_to(channel)
            return existing

        vc = await channel.connect(cls=discord.VoiceClient, timeout=10)
        self._vc_map[guild_id] = vc
        print(f"[Voice] Joined channel: {channel.name} (guild {guild_id})")
        return vc

    async def leave_channel(self, guild_id: int):
        vc = self._vc_map.pop(guild_id, None)
        if vc and vc.is_connected():
            await vc.disconnect()
            print(f"[Voice] Left channel (guild {guild_id})")

    async def speak(
        self,
        voice_client: discord.VoiceClient,
        text: str,
        interrupt: bool = True,
    ) -> bool:
        """
        Synthesize text and stream it into the Discord voice channel.
        Returns True on success.
        """
        if not voice_client or not voice_client.is_connected():
            print("[Voice] speak() called but not connected.")
            return False

        audio_bytes = await self.synthesize(text)
        if not audio_bytes:
            return False

        if interrupt and voice_client.is_playing():
            voice_client.stop()
            await asyncio.sleep(0.1)

        source = LunaAudioSource(audio_bytes)

        done_event = asyncio.Event()

        def after_play(error):
            if error:
                print(f"[Voice] Playback error: {error}")
            done_event.set()

        voice_client.play(source, after=after_play)

        try:
            await asyncio.wait_for(done_event.wait(), timeout=120)
            return True
        except asyncio.TimeoutError:
            voice_client.stop()
            return False

    async def speak_streaming(
        self,
        voice_client: discord.VoiceClient,
        text_chunks: asyncio.Queue,
        sentence_buffer: int = 60,
    ):
        """
        Consume an async queue of text chunks and speak in sentence-sized
        bursts — so Luna starts talking before the full LLM response is done.
        """
        buffer = ""
        EOS_TOKENS = {".", "!", "?", "...", "\n"}

        while True:
            try:
                chunk = await asyncio.wait_for(text_chunks.get(), timeout=2.0)
            except asyncio.TimeoutError:
                if buffer.strip():
                    await self.speak(voice_client, buffer, interrupt=False)
                    buffer = ""
                break

            if chunk is None:          # sentinel: LLM done
                if buffer.strip():
                    await self.speak(voice_client, buffer, interrupt=False)
                break

            buffer += chunk

            # Flush on sentence boundary or buffer length threshold
            last_char = buffer.rstrip()[-1] if buffer.strip() else ""
            if last_char in EOS_TOKENS or len(buffer) >= sentence_buffer:
                await self.speak(voice_client, buffer, interrupt=False)
                buffer = ""

    def get_vc(self, guild_id: int) -> Optional[discord.VoiceClient]:
        return self._vc_map.get(guild_id)

    def is_connected(self, guild_id: int) -> bool:
        vc = self._vc_map.get(guild_id)
        return vc is not None and vc.is_connected()
