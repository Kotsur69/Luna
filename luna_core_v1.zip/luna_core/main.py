"""
Luna Core v1.0 — Main Entry Point
Run this to start the full system:
  python main.py          → Discord bot mode
  python main.py --cli    → Interactive terminal mode (no Discord)
  python main.py --check  → Health check all services
"""

import asyncio
import argparse
import sys


# ── CLI Mode (no Discord) ─────────────────────────────────────────────────────

async def _cli_mode():
    from memory_engine import MemoryEngine
    from context_packer import ContextPacker
    from llm_router import LunaLLMRouter

    print("\n🌙 Luna Core v1.0 — CLI Mode")
    print("Type your message. Prefix with 'code:' to force Gemini.\n")

    memory = MemoryEngine()
    packer = ContextPacker()
    router = await LunaLLMRouter(memory, packer).initialize()

    while True:
        try:
            user_input = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n[Luna] Goodbye.")
            break

        if not user_input:
            continue
        if user_input.lower() in ("/quit", "/exit"):
            break

        engine = None
        if user_input.startswith("code:"):
            engine = "gemini"
            user_input = user_input[5:].strip()
        elif user_input.startswith("chat:"):
            engine = "ollama"
            user_input = user_input[5:].strip()

        print("Luna: ", end="", flush=True)
        async for chunk in router.respond(user_input, force_engine=engine):
            print(chunk, end="", flush=True)
        print()

    await router.teardown()


# ── Health Check Mode ─────────────────────────────────────────────────────────

async def _health_check():
    from config import (
        OLLAMA_BASE_URL, GEMINI_API_KEY, DISCORD_TOKEN,
        REPO_DIR, DB_PATH
    )
    from context_packer import ContextPacker
    from memory_engine import MemoryEngine

    print("\n🔎 Luna Core — Health Check\n")

    checks = []

    # Ollama
    try:
        import httpx
        async with httpx.AsyncClient() as c:
            r = await c.get(f"{OLLAMA_BASE_URL}/api/tags", timeout=5)
            checks.append(("Ollama",   "✅", r.status_code == 200))
    except Exception as e:
        checks.append(("Ollama",   "❌", str(e)))

    # Gemini API key
    checks.append(("Gemini API Key", "✅" if GEMINI_API_KEY else "❌", bool(GEMINI_API_KEY)))

    # Discord token
    checks.append(("Discord Token",  "✅" if DISCORD_TOKEN else "❌", bool(DISCORD_TOKEN)))

    # Repo dir
    checks.append(("Repo Dir",       "✅" if REPO_DIR.exists() else "❌", REPO_DIR.exists()))

    # DB writable
    try:
        m = MemoryEngine()
        m.close()
        checks.append(("SQLite DB",  "✅", True))
    except Exception as e:
        checks.append(("SQLite DB",  "❌", str(e)))

    # ffmpeg
    import shutil
    checks.append(("ffmpeg",         "✅" if shutil.which("ffmpeg") else "⚠️ missing", bool(shutil.which("ffmpeg"))))

    # PyNaCl
    try:
        import nacl
        checks.append(("PyNaCl",     "✅", True))
    except ImportError:
        checks.append(("PyNaCl",     "❌ pip install PyNaCl", False))

    # edge-tts
    try:
        import edge_tts
        checks.append(("edge-tts",   "✅", True))
    except ImportError:
        checks.append(("edge-tts",   "⚠️ pip install edge-tts", False))

    for name, icon, status in checks:
        label = icon if isinstance(status, bool) else icon
        print(f"  {label}  {name}")

    all_ok = all(v[2] is True for v in checks)
    print(f"\n{'✅ All systems go!' if all_ok else '⚠️  Some issues detected — check above.'}\n")


# ── Entry ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Luna Core v1.0")
    parser.add_argument("--cli",   action="store_true", help="Interactive CLI mode")
    parser.add_argument("--check", action="store_true", help="Health check")
    args = parser.parse_args()

    if args.check:
        asyncio.run(_health_check())
    elif args.cli:
        asyncio.run(_cli_mode())
    else:
        # Default: start Discord bot
        from discord_bot import run
        run()


if __name__ == "__main__":
    main()
