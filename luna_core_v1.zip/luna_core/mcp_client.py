"""
Luna Core v1.0 — MCP Toolbox
════════════════════════════════════════════════════════════════════════════════

Model Context Protocol integration. Luna's plugin system.

Instead of writing custom code for GitHub, Spotify, weather, Notion, etc.,
we plug in any MCP server and Luna discovers the tools automatically.

How it works:
  1. You define MCP servers in mcp_servers.json (or .env)
  2. MCPToolbox connects to each server on startup via stdio or SSE
  3. It fetches the tool manifest: name, description, input schema
  4. It converts those tools into Gemini function declarations
  5. When Gemini decides to call a tool, MCPToolbox executes the call
     against the right MCP server and returns the result
  6. Luna reads the result and continues her response

Luna never needs to know *how* GitHub's API works. She just sees:
  "I have a tool called `github_create_pr` that takes {title, body, branch}."
  She calls it. The MCP server handles the rest.

Install the SDK:
  pip install mcp

Pre-built MCP servers to plug in immediately:
  npx @modelcontextprotocol/server-github       # GitHub
  npx @modelcontextprotocol/server-spotify      # Spotify
  npx @modelcontextprotocol/server-filesystem   # File system (alternative to our file_manager)
  npx @modelcontextprotocol/server-brave-search # Brave search (alternative to grounding)
  npx @modelcontextprotocol/server-slack        # Slack
  pip install mcp-server-sqlite                 # SQLite (for Luna's own DBs)

════════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

# MCP SDK — pip install mcp
try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    from mcp.client.sse import sse_client
    import mcp.types as mcp_types
    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False
    print("[MCP] SDK not installed — pip install mcp. Toolbox will be empty.")

import google.generativeai as genai

from config import BASE_DIR


# ══════════════════════════════════════════════════════════════════════════════
# SERVER CONFIG
# ══════════════════════════════════════════════════════════════════════════════

MCP_SERVERS_CONFIG = BASE_DIR / "mcp_servers.json"

# Default server definitions — copy this to mcp_servers.json and edit
DEFAULT_SERVERS: list[dict] = [
    {
        "name":        "github",
        "enabled":     False,
        "transport":   "stdio",
        "command":     "npx",
        "args":        ["-y", "@modelcontextprotocol/server-github"],
        "env":         {"GITHUB_PERSONAL_ACCESS_TOKEN": "${GITHUB_TOKEN}"},
        "description": "GitHub: repos, PRs, issues, commits",
    },
    {
        "name":        "spotify",
        "enabled":     False,
        "transport":   "stdio",
        "command":     "npx",
        "args":        ["-y", "@modelcontextprotocol/server-spotify"],
        "env":         {
            "SPOTIFY_CLIENT_ID":     "${SPOTIFY_CLIENT_ID}",
            "SPOTIFY_CLIENT_SECRET": "${SPOTIFY_CLIENT_SECRET}",
        },
        "description": "Spotify: play, search, control playback",
    },
    {
        "name":        "brave_search",
        "enabled":     False,
        "transport":   "stdio",
        "command":     "npx",
        "args":        ["-y", "@modelcontextprotocol/server-brave-search"],
        "env":         {"BRAVE_API_KEY": "${BRAVE_API_KEY}"},
        "description": "Web search via Brave (alternative to Gemini grounding)",
    },
    {
        "name":        "sqlite",
        "enabled":     False,
        "transport":   "stdio",
        "command":     "python",
        "args":        ["-m", "mcp_server_sqlite", "--db-path", str(BASE_DIR / "luna_memory.db")],
        "env":         {},
        "description": "SQLite: direct SQL access to Luna's memory database",
    },
    {
        "name":        "filesystem",
        "enabled":     False,
        "transport":   "stdio",
        "command":     "npx",
        "args":        ["-y", "@modelcontextprotocol/server-filesystem", str(BASE_DIR)],
        "env":         {},
        "description": "Filesystem: alternative file read/write via MCP",
    },
]


def _load_server_configs() -> list[dict]:
    """Load server definitions from mcp_servers.json, falling back to defaults."""
    if MCP_SERVERS_CONFIG.exists():
        try:
            configs = json.loads(MCP_SERVERS_CONFIG.read_text())
            print(f"[MCP] Loaded {len(configs)} server configs from {MCP_SERVERS_CONFIG.name}")
            return configs
        except Exception as e:
            print(f"[MCP] Failed to parse mcp_servers.json: {e} — using defaults")
    else:
        # Write the defaults so the user can edit them
        MCP_SERVERS_CONFIG.write_text(json.dumps(DEFAULT_SERVERS, indent=2))
        print(f"[MCP] Created {MCP_SERVERS_CONFIG.name} — edit to enable servers")
    return DEFAULT_SERVERS


def _resolve_env(env_dict: dict) -> dict:
    """Replace ${VAR} placeholders with actual environment variable values."""
    resolved = {}
    for k, v in env_dict.items():
        if v.startswith("${") and v.endswith("}"):
            var_name = v[2:-1]
            resolved[k] = os.getenv(var_name, "")
        else:
            resolved[k] = v
    return resolved


# ══════════════════════════════════════════════════════════════════════════════
# TOOL REGISTRY
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class MCPTool:
    """A single tool discovered from an MCP server."""
    server_name:  str
    name:         str           # full qualified name: "github.create_pr"
    raw_name:     str           # server's original name: "create_pr"
    description:  str
    input_schema: dict          # JSON Schema for input parameters

    def to_gemini_declaration(self) -> genai.protos.FunctionDeclaration:
        """Convert to a Gemini FunctionDeclaration for function calling."""
        # Gemini expects a flat properties dict with type/description per field
        props = {}
        required = []
        schema = self.input_schema or {}

        for prop_name, prop_def in schema.get("properties", {}).items():
            gemini_type = _json_type_to_gemini(prop_def.get("type", "string"))
            props[prop_name] = genai.protos.Schema(
                type        = gemini_type,
                description = prop_def.get("description", ""),
            )
        required = schema.get("required", [])

        return genai.protos.FunctionDeclaration(
            name        = self.name,   # qualified: "github.create_pr"
            description = f"[{self.server_name}] {self.description}",
            parameters  = genai.protos.Schema(
                type       = genai.protos.Type.OBJECT,
                properties = props,
                required   = required,
            ),
        )

    def to_prompt_line(self) -> str:
        """One-line description for injection into system prompt."""
        return f"  • `{self.name}` — {self.description[:80]}"


def _json_type_to_gemini(json_type: str):
    """Map JSON Schema types to Gemini proto types."""
    mapping = {
        "string":  genai.protos.Type.STRING,
        "number":  genai.protos.Type.NUMBER,
        "integer": genai.protos.Type.INTEGER,
        "boolean": genai.protos.Type.BOOLEAN,
        "array":   genai.protos.Type.ARRAY,
        "object":  genai.protos.Type.OBJECT,
    }
    return mapping.get(json_type, genai.protos.Type.STRING)


# ══════════════════════════════════════════════════════════════════════════════
# MCP TOOLBOX
# ══════════════════════════════════════════════════════════════════════════════

class MCPToolbox:
    """
    Luna's plugin system. Connects to MCP servers, discovers tools,
    and executes them when Gemini decides to call them.

    Usage:
        toolbox = MCPToolbox()
        await toolbox.connect()                          # boot all enabled servers
        tools   = toolbox.get_gemini_tools()             # pass to Gemini API
        result  = await toolbox.call("github.create_pr", {...})  # execute call
        await toolbox.disconnect()
    """

    def __init__(self):
        self._tools:    dict[str, MCPTool]    = {}   # qualified_name → MCPTool
        self._sessions: dict[str, Any]        = {}   # server_name → ClientSession
        self._configs:  list[dict]            = _load_server_configs()
        self._connected = False

    # ── Connect ───────────────────────────────────────────────────────────────

    async def connect(self):
        """Connect to all enabled MCP servers and discover their tools."""
        if not MCP_AVAILABLE:
            print("[MCP] SDK missing — skipping connect. pip install mcp")
            return

        enabled = [c for c in self._configs if c.get("enabled", False)]
        if not enabled:
            print("[MCP] No servers enabled. Edit mcp_servers.json to enable some.")
            return

        print(f"[MCP] Connecting to {len(enabled)} server(s)...")
        results = await asyncio.gather(
            *[self._connect_server(cfg) for cfg in enabled],
            return_exceptions=True,
        )
        for cfg, result in zip(enabled, results):
            if isinstance(result, Exception):
                print(f"[MCP] ✗ {cfg['name']}: {result}")
            else:
                print(f"[MCP] ✓ {cfg['name']}: {result} tools discovered")

        self._connected = True
        print(f"[MCP] Toolbox ready — {len(self._tools)} total tools across {len(self._sessions)} server(s)")

    async def _connect_server(self, cfg: dict) -> int:
        """Connect to a single MCP server and register its tools. Returns tool count."""
        name      = cfg["name"]
        transport = cfg.get("transport", "stdio")
        env       = {**os.environ, **_resolve_env(cfg.get("env", {}))}

        try:
            if transport == "stdio":
                server_params = StdioServerParameters(
                    command = cfg["command"],
                    args    = cfg.get("args", []),
                    env     = env,
                )
                # We keep the context manager alive by storing its __aenter__ result
                cm      = stdio_client(server_params)
                streams = await cm.__aenter__()
                session = ClientSession(*streams)
                await session.__aenter__()

            elif transport == "sse":
                url = cfg.get("url", "")
                cm      = sse_client(url)
                streams = await cm.__aenter__()
                session = ClientSession(*streams)
                await session.__aenter__()

            else:
                raise ValueError(f"Unknown transport: {transport}")

            await session.initialize()
            self._sessions[name] = session

            # Discover tools
            tools_response = await session.list_tools()
            count = 0
            for tool in (tools_response.tools or []):
                qualified = f"{name}.{tool.name}"
                self._tools[qualified] = MCPTool(
                    server_name  = name,
                    name         = qualified,
                    raw_name     = tool.name,
                    description  = tool.description or "",
                    input_schema = tool.inputSchema or {},
                )
                count += 1
            return count

        except Exception as e:
            raise RuntimeError(f"Connection failed: {e}") from e

    # ── Disconnect ────────────────────────────────────────────────────────────

    async def disconnect(self):
        """Gracefully close all server connections."""
        for name, session in self._sessions.items():
            try:
                await session.__aexit__(None, None, None)
            except Exception:
                pass
        self._sessions.clear()
        self._connected = False
        print("[MCP] Disconnected from all servers.")

    # ── Execute ───────────────────────────────────────────────────────────────

    async def call(self, tool_name: str, arguments: dict) -> dict:
        """
        Execute an MCP tool call.
        tool_name: qualified name like "github.create_pr"
        arguments: dict matching the tool's input schema
        Returns: {"content": [...], "is_error": bool}
        """
        tool = self._tools.get(tool_name)
        if not tool:
            return {
                "content":  [{"type": "text", "text": f"Tool not found: `{tool_name}`"}],
                "is_error": True,
            }

        session = self._sessions.get(tool.server_name)
        if not session:
            return {
                "content":  [{"type": "text", "text": f"Server `{tool.server_name}` not connected"}],
                "is_error": True,
            }

        print(f"[MCP] Calling {tool_name}({json.dumps(arguments, default=str)[:120]})")
        try:
            result = await session.call_tool(tool.raw_name, arguments=arguments)
            # Flatten content blocks to plain text for Luna to read
            text_parts = []
            for block in (result.content or []):
                if hasattr(block, "text"):
                    text_parts.append(block.text)
                elif isinstance(block, dict):
                    text_parts.append(block.get("text", str(block)))
            return {
                "content":  [{"type": "text", "text": "\n".join(text_parts)}],
                "is_error": getattr(result, "isError", False),
            }
        except Exception as e:
            return {
                "content":  [{"type": "text", "text": f"Tool call failed: {e}"}],
                "is_error": True,
            }

    # ── Gemini Integration ────────────────────────────────────────────────────

    def get_gemini_tools(self) -> Optional[list]:
        """
        Returns a Gemini Tool object containing all MCP tool declarations.
        Pass this to model.generate_content(tools=[...]).
        Returns None if no tools are available (avoids empty tools param).
        """
        if not self._tools:
            return None

        declarations = [t.to_gemini_declaration() for t in self._tools.values()]
        return [genai.protos.Tool(function_declarations=declarations)]

    async def handle_gemini_function_call(
        self,
        function_call: Any,   # genai.protos.FunctionCall
    ) -> genai.protos.Part:
        """
        Execute a Gemini function call against MCP and return a FunctionResponse Part.
        Used inside the Gemini agentic loop.
        """
        tool_name = function_call.name
        arguments = dict(function_call.args) if function_call.args else {}

        result = await self.call(tool_name, arguments)
        text   = result["content"][0]["text"] if result["content"] else ""

        return genai.protos.Part(
            function_response=genai.protos.FunctionResponse(
                name     = tool_name,
                response = {"result": text, "is_error": result["is_error"]},
            )
        )

    # ── Luna-facing helpers ───────────────────────────────────────────────────

    def describe_toolbox(self) -> str:
        """
        Returns a human-readable summary of all available tools.
        Injected into Luna's system prompt so she knows what she can do.
        """
        if not self._tools:
            return ""

        by_server: dict[str, list[MCPTool]] = {}
        for tool in self._tools.values():
            by_server.setdefault(tool.server_name, []).append(tool)

        lines = ["━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
                 "YOUR MCP TOOLBOX (skills you can use right now)",
                 "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
                 "When you need to use one of these, call the function directly.",
                 "You don't need to ask permission — just use the tool.\n"]

        for server, tools in by_server.items():
            lines.append(f"[{server.upper()}]")
            for t in tools:
                lines.append(t.to_prompt_line())
            lines.append("")

        return "\n".join(lines)

    def list_tools(self) -> list[dict]:
        return [
            {"name": t.name, "server": t.server_name, "description": t.description}
            for t in self._tools.values()
        ]

    @property
    def tool_count(self) -> int:
        return len(self._tools)

    @property
    def is_connected(self) -> bool:
        return self._connected and bool(self._sessions)


# ══════════════════════════════════════════════════════════════════════════════
# AGENTIC GEMINI LOOP WITH MCP
# ══════════════════════════════════════════════════════════════════════════════

async def run_agentic_turn(
    model:    "genai.GenerativeModel",
    prompt:   str,
    toolbox:  MCPToolbox,
    max_tool_calls: int = 10,
) -> tuple[str, list[dict]]:
    """
    Run a full agentic Gemini turn with MCP tool calling.

    Gemini may decide to call tools multiple times before producing a final
    text response. This loop handles that automatically:

      User prompt
        → Gemini responds with function_call
        → We execute via MCP
        → Feed result back as function_response
        → Gemini may call another tool, or produce final text

    Returns: (final_text, tool_call_log)
    """
    if not MCP_AVAILABLE or not toolbox.tool_count:
        # No tools — just do a plain generate
        response = await asyncio.to_thread(model.generate_content, prompt)
        return (response.text or ""), []

    gemini_tools = toolbox.get_gemini_tools()
    messages     = [{"role": "user", "parts": [prompt]}]
    tool_log     = []

    for _ in range(max_tool_calls):
        response = await asyncio.to_thread(
            model.generate_content,
            messages,
            tools = gemini_tools,
        )

        candidate  = response.candidates[0] if response.candidates else None
        if not candidate:
            break

        # Check if Gemini wants to call a tool
        function_calls = [
            part.function_call
            for part in (candidate.content.parts or [])
            if hasattr(part, "function_call") and part.function_call.name
        ]

        if not function_calls:
            # No more tool calls — Gemini is done, return text
            text = "".join(
                part.text for part in candidate.content.parts
                if hasattr(part, "text")
            )
            return text, tool_log

        # Execute all tool calls (may be parallel in one turn)
        tool_result_parts = []
        for fc in function_calls:
            tool_log.append({"tool": fc.name, "args": dict(fc.args or {})})
            result_part = await toolbox.handle_gemini_function_call(fc)
            tool_result_parts.append(result_part)

        # Add the assistant's function_call turn + our function_response turn
        messages.append({
            "role":  "model",
            "parts": list(candidate.content.parts),
        })
        messages.append({
            "role":  "user",
            "parts": tool_result_parts,
        })

    # If we exit the loop (too many calls), return whatever the last text was
    last_text = ""
    if response and response.candidates:
        last_text = "".join(
            part.text for part in response.candidates[0].content.parts
            if hasattr(part, "text")
        ) or "(Luna ran out of tool call budget)"
    return last_text, tool_log


# ── Module-level singleton ────────────────────────────────────────────────────
toolbox = MCPToolbox()
