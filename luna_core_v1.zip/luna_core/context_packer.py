"""
Luna Core v1.0 — Context Packer
Reads every .py file in the repo, assembles a rich system prompt,
and manages Gemini Context Caching to avoid re-uploading 40k lines
of code on every single API call (saves $$$).

Gemini Context Caching docs:
  https://ai.google.dev/gemini-api/docs/caching
"""

import os
import re
import json
import time
import hashlib
import asyncio
from pathlib import Path
from typing import Optional
from dataclasses import dataclass

import google.generativeai as genai

from config import (
    REPO_DIR, CACHE_DIR, GEMINI_API_KEY,
    GEMINI_MODEL, GEMINI_CACHE_TTL,
)
from personality import get_cached_base_prompt


# ── Data Structures ──────────────────────────────────────────────────────────

@dataclass
class FileSnapshot:
    path: str            # relative path
    lines: int
    size_bytes: int
    content: str
    checksum: str

@dataclass
class RepoContext:
    total_files: int
    total_lines: int
    total_tokens_est: int
    file_map: dict[str, FileSnapshot]   # rel_path → snapshot
    system_prompt: str
    repo_hash: str                       # changes when any file changes


# ── Context Packer ───────────────────────────────────────────────────────────

class ContextPacker:
    """
    Reads all .py files → builds a structured system prompt →
    manages a Gemini cached_content so the codebase is uploaded once
    and reused across many API calls within the TTL window.
    """

    CACHE_META_FILE = CACHE_DIR / "gemini_cache_meta.json"
    MAX_FILE_BYTES  = 200_000   # skip generated / minified files
    SKIP_DIRS       = {".git", "__pycache__", ".venv", "venv", "node_modules",
                       ".mypy_cache", "dist", "build", ".pytest_cache"}

    def __init__(self):
        genai.configure(api_key=GEMINI_API_KEY)
        self._cache_meta: dict = self._load_cache_meta()
        self._repo_ctx:  Optional[RepoContext] = None

    # ── Public API ────────────────────────────────────────────────────────────

    def pack(self, repo_dir: Path = REPO_DIR) -> RepoContext:
        """
        Scan repo, build system prompt, return RepoContext.
        Caches result in memory — call invalidate() to force re-scan.
        """
        snapshots = self._scan_repo(repo_dir)
        repo_hash = self._compute_repo_hash(snapshots)

        if self._repo_ctx and self._repo_ctx.repo_hash == repo_hash:
            print("[ContextPacker] Cache hit — repo unchanged.")
            return self._repo_ctx

        print(f"[ContextPacker] Packing {len(snapshots)} files...")
        system_prompt = self._build_system_prompt(snapshots)
        total_lines   = sum(s.lines for s in snapshots.values())
        tokens_est    = sum(len(s.content.split()) * 1.3 for s in snapshots.values())

        self._repo_ctx = RepoContext(
            total_files     = len(snapshots),
            total_lines     = total_lines,
            total_tokens_est= int(tokens_est),
            file_map        = snapshots,
            system_prompt   = system_prompt,
            repo_hash       = repo_hash,
        )
        print(f"[ContextPacker] Packed: {total_lines} lines, ~{tokens_est/1000:.1f}k tokens")
        return self._repo_ctx

    def get_or_create_gemini_cache(
        self,
        repo_ctx: RepoContext,
        memory_block: str = "",
    ) -> Optional[str]:
        """
        Returns a Gemini cache_name if the current codebase is already cached
        and still valid. Otherwise uploads everything and creates a new cache.

        Returns: cache_name string (pass to GenerativeModel as cached_content)
        """
        cached = self._cache_meta.get("cache_name")
        cached_hash = self._cache_meta.get("repo_hash")
        cached_expiry = self._cache_meta.get("expires_at", 0)

        if (
            cached
            and cached_hash == repo_ctx.repo_hash
            and time.time() < cached_expiry - 60  # 60s buffer
        ):
            print(f"[ContextPacker] Reusing Gemini cache: {cached}")
            return cached

        # Build the full cacheable content
        print("[ContextPacker] Creating new Gemini context cache...")
        cache_content = self._assemble_cache_content(repo_ctx, memory_block)

        try:
            cache = genai.caching.CachedContent.create(
                model        = GEMINI_MODEL,
                system_instruction = get_cached_base_prompt(),
                contents     = [cache_content],
                ttl          = GEMINI_CACHE_TTL,
                display_name = f"luna-repo-{repo_ctx.repo_hash[:8]}",
            )
            self._cache_meta = {
                "cache_name": cache.name,
                "repo_hash":  repo_ctx.repo_hash,
                "expires_at": time.time() + GEMINI_CACHE_TTL,
                "files":      repo_ctx.total_files,
                "lines":      repo_ctx.total_lines,
            }
            self._save_cache_meta()
            print(f"[ContextPacker] Cache created: {cache.name} (TTL={GEMINI_CACHE_TTL}s)")
            return cache.name

        except Exception as e:
            print(f"[ContextPacker] Cache creation failed: {e} — falling back to direct prompt")
            return None

    def invalidate(self):
        """Force re-scan on next pack() call."""
        self._repo_ctx = None
        print("[ContextPacker] Cache invalidated.")

    def get_file_content(self, filename: str) -> Optional[str]:
        """Return content of a specific file by name or partial path."""
        if not self._repo_ctx:
            return None
        for path, snap in self._repo_ctx.file_map.items():
            if filename in path:
                return snap.content
        return None

    # ── Scanning ─────────────────────────────────────────────────────────────

    def _scan_repo(self, repo_dir: Path) -> dict[str, FileSnapshot]:
        snapshots = {}
        py_files  = self._find_py_files(repo_dir)

        for fpath in py_files:
            try:
                content = fpath.read_text(encoding="utf-8", errors="replace")
                if len(content.encode()) > self.MAX_FILE_BYTES:
                    print(f"[ContextPacker] Skipping large file: {fpath.name}")
                    continue
                rel = str(fpath.relative_to(repo_dir))
                snapshots[rel] = FileSnapshot(
                    path      = rel,
                    lines     = content.count("\n"),
                    size_bytes= len(content.encode()),
                    content   = content,
                    checksum  = hashlib.md5(content.encode()).hexdigest(),
                )
            except Exception as e:
                print(f"[ContextPacker] Skipping {fpath}: {e}")

        return snapshots

    def _find_py_files(self, repo_dir: Path) -> list[Path]:
        results = []
        for root, dirs, files in os.walk(repo_dir):
            dirs[:] = [d for d in dirs if d not in self.SKIP_DIRS]
            for f in files:
                if f.endswith(".py"):
                    results.append(Path(root) / f)
        return sorted(results)

    # ── Prompt Assembly ───────────────────────────────────────────────────────

    def _build_system_prompt(self, snapshots: dict[str, FileSnapshot]) -> str:
        """
        Builds the rich system prompt that describes the entire codebase.
        This goes into the Gemini cached context.
        """
        file_index = "\n".join(
            f"  • {snap.path} ({snap.lines} lines)"
            for snap in sorted(snapshots.values(), key=lambda s: -s.lines)
        )

        file_blocks = []
        for rel_path, snap in snapshots.items():
            block = (
                f"### FILE: {rel_path}\n"
                f"# Lines: {snap.lines} | Size: {snap.size_bytes} bytes\n"
                f"```python\n{snap.content}\n```"
            )
            file_blocks.append(block)

        return f"""
{get_cached_base_prompt()}

## Repository Overview
You have complete access to the developer's codebase. Here is the full file index:

{file_index}

## Full Source Code
{chr(10).join(file_blocks)}
""".strip()

    def _assemble_cache_content(self, repo_ctx: RepoContext, memory_block: str) -> str:
        """Assembles everything that goes into the Gemini cache."""
        parts = [repo_ctx.system_prompt]
        if memory_block:
            parts.append(f"\n\n{memory_block}")
        return "\n\n".join(parts)

    def _compute_repo_hash(self, snapshots: dict[str, FileSnapshot]) -> str:
        combined = "".join(
            f"{path}:{snap.checksum}"
            for path, snap in sorted(snapshots.items())
        )
        return hashlib.sha256(combined.encode()).hexdigest()[:24]

    # ── Cache Meta Persistence ────────────────────────────────────────────────

    def _load_cache_meta(self) -> dict:
        if self.CACHE_META_FILE.exists():
            try:
                return json.loads(self.CACHE_META_FILE.read_text())
            except Exception:
                pass
        return {}

    def _save_cache_meta(self):
        self.CACHE_META_FILE.write_text(json.dumps(self._cache_meta, indent=2))

    def summary(self) -> str:
        if not self._repo_ctx:
            return "No repo context loaded yet."
        ctx = self._repo_ctx
        return (
            f"📦 Repo Context Summary\n"
            f"  Files:  {ctx.total_files}\n"
            f"  Lines:  {ctx.total_lines:,}\n"
            f"  Tokens: ~{ctx.total_tokens_est:,}\n"
            f"  Hash:   {ctx.repo_hash[:12]}...\n"
            f"  Cache:  {self._cache_meta.get('cache_name', 'none')}"
        )
