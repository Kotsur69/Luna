import { useState, useEffect, useRef, useCallback } from "react";

// ── Mock data for dashboard preview (replace ws:// with real server in prod) ─
const MOCK_CHAINS = [
  {
    chain_id: "a1b2c3d4e5f6",
    session_id: "sess_001",
    created_at: new Date(Date.now() - 12000).toISOString(),
    completed: true,
    total_latency_ms: 1840,
    intent: { raw_input: "Hej Luna fix the auth bug", classified_as: "code_fix", engine_selected: "gemini", wake_word_used: "hej luna", latency_ms: 12 },
    memory: { query: "fix auth bug", total_in_db: 47, memories_found: 6, memories_injected: [
      { id: "a1b2c3d4", category: "code_style", content: "Prefers type hints end-to-end", importance: 0.85 },
      { id: "b2c3d4e5", category: "preference", content: "Wants to keep API costs low", importance: 0.78 },
      { id: "c3d4e5f6", category: "humor", content: "Appreciates dry sarcasm", importance: 0.62 },
    ], injection_tokens: 184 },
    personality: { prompt_variant: "code", blocks_active: ["CORE_IDENTITY","MEMORY_INSTRUCTIONS","CODE_MODE","CURIOSITY"], voice_mode: false, code_mode: true, estimated_tokens: 2840, fillers_detected: ["hmm","ohh"] },
    generation: { engine: "gemini", model: "gemini-1.5-pro-latest", prompt_tokens: 3240, output_tokens: 412, total_tokens: 3652, latency_ms: 1710, raw_output: "hmm... okay wait. I think I found it. line 94 in auth.py — see where you're awaiting that coroutine inside a sync context? yeah... that's your culprit. it's not crashing loudly, it's just silently dropping the result. (classic, honestly — I've seen this one before.) want me to write the fix?", cache_hit: true, fillers_in_output: ["hmm", "wait"] },
    voice: { tts_engine: "edge-tts", voice_id: "en-US-AriaNeural", stability: 0.35, similarity_boost: 0.80, style_exaggeration: 0.45, raw_text_length: 412, cleaned_text_length: 380, chars_removed: 32, audio_duration_ms: 8200, synthesis_latency_ms: 890 },
    feedback: { sentiment: "loved", tags: ["funny", "accurate"], source: "reaction", raw: "💜", memory_effect: "Stored positive filler pattern: hmm, wait", given_at: new Date(Date.now() - 8000).toISOString() },
  },
  {
    chain_id: "f6e5d4c3b2a1",
    session_id: "sess_001",
    created_at: new Date(Date.now() - 65000).toISOString(),
    completed: true,
    total_latency_ms: 420,
    intent: { raw_input: "what's the weather like", classified_as: "chat", engine_selected: "ollama", wake_word_used: null, latency_ms: 8 },
    memory: { query: "weather", total_in_db: 47, memories_found: 0, memories_injected: [], injection_tokens: 0 },
    personality: { prompt_variant: "chat", blocks_active: ["CORE_IDENTITY","MEMORY_INSTRUCTIONS","CURIOSITY","EXAMPLES"], voice_mode: false, code_mode: false, estimated_tokens: 1840, fillers_detected: [] },
    generation: { engine: "ollama", model: "llama3.1:8b", prompt_tokens: 1840, output_tokens: 68, total_tokens: 1908, latency_ms: 390, raw_output: "ohh that's not really my department — I live in your terminal, not the atmosphere. check your phone? but seriously, if you're asking because you want to go outside, I support that.", cache_hit: false, fillers_in_output: ["ohh"] },
    voice: null,
    feedback: { sentiment: "liked", tags: ["funny"], source: "reaction", raw: "😂", memory_effect: "Stored positive filler pattern: ohh", given_at: new Date(Date.now() - 60000).toISOString() },
  },
  {
    chain_id: "1a2b3c4d5e6f",
    session_id: "sess_001",
    created_at: new Date(Date.now() - 3000).toISOString(),
    completed: false,
    total_latency_ms: 0,
    intent: { raw_input: "review the dubbing engine", classified_as: "code_review", engine_selected: "gemini", wake_word_used: "hey luna", latency_ms: 9 },
    memory: { query: "review dubbing engine", total_in_db: 47, memories_found: 4, memories_injected: [
      { id: "d4e5f6a1", category: "code_style", content: "Working on dubbinger v1.py", importance: 0.92 },
      { id: "e5f6a1b2", category: "financial", content: "Goal: reach profitability with dubbing project", importance: 0.88 },
    ], injection_tokens: 96 },
    personality: { prompt_variant: "code", blocks_active: ["CORE_IDENTITY","MEMORY_INSTRUCTIONS","CODE_MODE","CURIOSITY"], voice_mode: false, code_mode: true, estimated_tokens: 2840, fillers_detected: [] },
    generation: null,
    voice: null,
    feedback: null,
  },
];

// ── Sentiment config ──────────────────────────────────────────────────────────
const SENTIMENT_STYLE = {
  loved:    { color: "#c084fc", bg: "rgba(192,132,252,0.12)", icon: "💜", label: "Loved" },
  liked:    { color: "#34d399", bg: "rgba(52,211,153,0.12)",  icon: "👍", label: "Liked" },
  neutral:  { color: "#94a3b8", bg: "rgba(148,163,184,0.08)", icon: "🤔", label: "Neutral" },
  disliked: { color: "#fb923c", bg: "rgba(251,146,60,0.12)",  icon: "👎", label: "Disliked" },
  hated:    { color: "#f87171", bg: "rgba(248,113,113,0.12)", icon: "😭", label: "Hated" },
};

const STAGE_CONFIG = {
  intent:      { icon: "⚡", label: "Intent", color: "#38bdf8" },
  memory:      { icon: "🧠", label: "Memory", color: "#a78bfa" },
  personality: { icon: "✨", label: "Persona", color: "#f472b6" },
  generation:  { icon: "🤖", label: "Generate", color: "#34d399" },
  voice:       { icon: "🎙️", label: "Voice", color: "#fb923c" },
};

const ENGINE_COLOR = { gemini: "#4285f4", ollama: "#10b981" };

// ── Helpers ───────────────────────────────────────────────────────────────────
const timeAgo = (iso) => {
  const secs = Math.round((Date.now() - new Date(iso)) / 1000);
  if (secs < 60) return `${secs}s ago`;
  if (secs < 3600) return `${Math.round(secs/60)}m ago`;
  return `${Math.round(secs/3600)}h ago`;
};

const truncate = (s, n) => s && s.length > n ? s.slice(0, n) + "…" : (s || "");

// ══════════════════════════════════════════════════════════════════════════════
// SUB-COMPONENTS
// ══════════════════════════════════════════════════════════════════════════════

function StagePill({ stage, data, active }) {
  const cfg = STAGE_CONFIG[stage];
  const done = !!data;
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 6,
      padding: "4px 10px", borderRadius: 20,
      background: done ? `${cfg.color}18` : "rgba(255,255,255,0.04)",
      border: `1px solid ${done ? cfg.color + "60" : "rgba(255,255,255,0.08)"}`,
      opacity: active && !done ? 0.5 : 1,
      transition: "all 0.3s ease",
      animation: active && !done ? "pulse 1.4s infinite" : "none",
    }}>
      <span style={{ fontSize: 12 }}>{cfg.icon}</span>
      <span style={{ fontSize: 11, color: done ? cfg.color : "#64748b", fontWeight: 600, letterSpacing: "0.04em" }}>
        {cfg.label}
      </span>
      {done && <span style={{ fontSize: 10, color: cfg.color, opacity: 0.7 }}>✓</span>}
    </div>
  );
}

function MemoryTag({ mem }) {
  const catColors = {
    code_style: "#38bdf8", preference: "#a78bfa",
    humor: "#f472b6", financial: "#fbbf24", fact: "#94a3b8",
  };
  const c = catColors[mem.category] || "#94a3b8";
  return (
    <div style={{
      display: "flex", gap: 6, alignItems: "flex-start",
      padding: "6px 10px", borderRadius: 8,
      background: `${c}10`, border: `1px solid ${c}30`,
      marginBottom: 4,
    }}>
      <span style={{ fontSize: 9, color: c, fontWeight: 700, letterSpacing: "0.08em", marginTop: 1, whiteSpace: "nowrap" }}>
        {mem.category.toUpperCase().replace("_", " ")}
      </span>
      <span style={{ fontSize: 11, color: "#cbd5e1", lineHeight: 1.4 }}>
        {truncate(mem.content, 80)}
      </span>
      <span style={{ fontSize: 9, color: c, marginLeft: "auto", opacity: 0.7, whiteSpace: "nowrap" }}>
        {(mem.importance * 100).toFixed(0)}%
      </span>
    </div>
  );
}

function FillerBadge({ filler }) {
  return (
    <span style={{
      display: "inline-flex", padding: "2px 8px", borderRadius: 12,
      background: "rgba(244,114,182,0.15)", border: "1px solid rgba(244,114,182,0.3)",
      fontSize: 11, color: "#f472b6", fontStyle: "italic", marginRight: 4,
    }}>
      "{filler}..."
    </span>
  );
}

function VoiceParamBar({ label, value, max = 1, color = "#fb923c" }) {
  const pct = Math.round((value / max) * 100);
  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
        <span style={{ fontSize: 10, color: "#94a3b8", letterSpacing: "0.06em" }}>{label}</span>
        <span style={{ fontSize: 10, color, fontWeight: 700 }}>{value.toFixed(2)}</span>
      </div>
      <div style={{ height: 4, borderRadius: 2, background: "rgba(255,255,255,0.06)", overflow: "hidden" }}>
        <div style={{
          height: "100%", width: `${pct}%`, borderRadius: 2,
          background: `linear-gradient(90deg, ${color}80, ${color})`,
          transition: "width 0.6s ease",
        }} />
      </div>
    </div>
  );
}

function FeedbackBadge({ feedback }) {
  if (!feedback) return null;
  const s = SENTIMENT_STYLE[feedback.sentiment] || SENTIMENT_STYLE.neutral;
  return (
    <div style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      padding: "4px 12px", borderRadius: 16,
      background: s.bg, border: `1px solid ${s.color}50`,
    }}>
      <span style={{ fontSize: 13 }}>{s.icon}</span>
      <span style={{ fontSize: 11, color: s.color, fontWeight: 700 }}>{s.label}</span>
      {feedback.tags.map(t => (
        <span key={t} style={{
          fontSize: 9, color: s.color, opacity: 0.8,
          background: `${s.color}15`, borderRadius: 8, padding: "1px 6px",
          letterSpacing: "0.06em",
        }}>{t}</span>
      ))}
    </div>
  );
}

// ── Chain Detail Panel ────────────────────────────────────────────────────────
function ChainDetail({ chain }) {
  const [tab, setTab] = useState("intent");
  const stages = ["intent", "memory", "personality", "generation", "voice"];
  const completedStages = stages.filter(s => chain[s]);

  const tabs = [...completedStages, ...(chain.feedback ? ["feedback"] : [])];

  const renderStageContent = () => {
    const data = chain[tab];
    if (!data) return <div style={{ color: "#64748b", padding: 16, fontSize: 12 }}>Awaiting this stage...</div>;

    switch (tab) {
      case "intent": return (
        <div>
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 10, color: "#64748b", letterSpacing: "0.08em", marginBottom: 4 }}>RAW INPUT</div>
            <div style={{ fontSize: 13, color: "#e2e8f0", fontStyle: "italic", padding: "8px 12px", background: "rgba(255,255,255,0.04)", borderRadius: 8, borderLeft: "3px solid #38bdf8" }}>
              "{data.raw_input}"
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
            {[
              ["Classified", data.classified_as, "#38bdf8"],
              ["Engine", data.engine_selected, ENGINE_COLOR[data.engine_selected] || "#94a3b8"],
              ["Latency", `${data.latency_ms}ms`, "#34d399"],
            ].map(([label, val, col]) => (
              <div key={label} style={{ padding: "10px 12px", background: "rgba(255,255,255,0.04)", borderRadius: 8, border: `1px solid ${col}30` }}>
                <div style={{ fontSize: 9, color: "#64748b", letterSpacing: "0.08em", marginBottom: 4 }}>{label}</div>
                <div style={{ fontSize: 13, color: col, fontWeight: 700 }}>{val}</div>
              </div>
            ))}
          </div>
          {data.wake_word_used && (
            <div style={{ marginTop: 8, fontSize: 11, color: "#a78bfa" }}>
              ⚡ Wake word: <strong>"{data.wake_word_used}"</strong>
            </div>
          )}
        </div>
      );

      case "memory": return (
        <div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 6, marginBottom: 12 }}>
            {[
              ["In DB", data.total_in_db, "#94a3b8"],
              ["Relevant", data.memories_found, "#a78bfa"],
              ["Injected", data.memories_injected.length, "#c084fc"],
              ["Tokens", data.injection_tokens, "#f472b6"],
            ].map(([l, v, c]) => (
              <div key={l} style={{ padding: "8px 10px", background: `${c}10`, borderRadius: 8, border: `1px solid ${c}25` }}>
                <div style={{ fontSize: 9, color: "#64748b", letterSpacing: "0.06em" }}>{l}</div>
                <div style={{ fontSize: 16, color: c, fontWeight: 800, marginTop: 2 }}>{v}</div>
              </div>
            ))}
          </div>
          {data.memories_injected.length > 0 ? (
            <div>
              <div style={{ fontSize: 10, color: "#64748b", letterSpacing: "0.08em", marginBottom: 6 }}>INJECTED MEMORIES</div>
              {data.memories_injected.map(m => <MemoryTag key={m.id} mem={m} />)}
            </div>
          ) : (
            <div style={{ fontSize: 11, color: "#475569", textAlign: "center", padding: 16 }}>No memories matched this query</div>
          )}
        </div>
      );

      case "personality": return (
        <div>
          <div style={{ marginBottom: 10 }}>
            <div style={{ fontSize: 10, color: "#64748b", letterSpacing: "0.08em", marginBottom: 6 }}>ACTIVE PROMPT BLOCKS</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
              {data.blocks_active.map(b => (
                <span key={b} style={{
                  fontSize: 10, padding: "3px 9px", borderRadius: 12,
                  background: "rgba(244,114,182,0.12)", border: "1px solid rgba(244,114,182,0.3)",
                  color: "#f472b6", fontWeight: 600, letterSpacing: "0.04em",
                }}>{b}</span>
              ))}
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 6, marginBottom: 10 }}>
            {[
              ["Variant", data.prompt_variant, "#f472b6"],
              ["Est. Tokens", data.estimated_tokens, "#94a3b8"],
              ["Voice Mode", data.voice_mode ? "ON" : "OFF", data.voice_mode ? "#34d399" : "#475569"],
            ].map(([l, v, c]) => (
              <div key={l} style={{ padding: "8px 10px", background: `${c}10`, borderRadius: 8, border: `1px solid ${c}25` }}>
                <div style={{ fontSize: 9, color: "#64748b", letterSpacing: "0.06em" }}>{l}</div>
                <div style={{ fontSize: 12, color: c, fontWeight: 700, marginTop: 2 }}>{v}</div>
              </div>
            ))}
          </div>
          {data.fillers_detected.length > 0 && (
            <div>
              <div style={{ fontSize: 10, color: "#64748b", letterSpacing: "0.08em", marginBottom: 5 }}>FILLERS REQUESTED IN PROMPT</div>
              <div>{data.fillers_detected.map(f => <FillerBadge key={f} filler={f} />)}</div>
            </div>
          )}
        </div>
      );

      case "generation": return (
        <div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 6, marginBottom: 10 }}>
            {[
              ["Engine", `${data.engine} / ${data.model}`, ENGINE_COLOR[data.engine] || "#94a3b8"],
              ["Latency", `${data.latency_ms.toFixed(0)}ms`, "#34d399"],
              ["Prompt Tokens", data.prompt_tokens, "#94a3b8"],
              ["Output Tokens", data.output_tokens, "#38bdf8"],
              ["Total Tokens", data.total_tokens, "#a78bfa"],
              ["Cache Hit", data.cache_hit ? "✓ Yes" : "✗ No", data.cache_hit ? "#34d399" : "#fb923c"],
            ].map(([l, v, c]) => (
              <div key={l} style={{ padding: "8px 10px", background: `${c}10`, borderRadius: 8, border: `1px solid ${c}25` }}>
                <div style={{ fontSize: 9, color: "#64748b", letterSpacing: "0.06em" }}>{l}</div>
                <div style={{ fontSize: 11, color: c, fontWeight: 700, marginTop: 2 }}>{v}</div>
              </div>
            ))}
          </div>
          {data.fillers_in_output.length > 0 && (
            <div style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 10, color: "#64748b", letterSpacing: "0.08em", marginBottom: 5 }}>FILLERS DETECTED IN OUTPUT</div>
              <div>{data.fillers_in_output.map(f => <FillerBadge key={f} filler={f} />)}</div>
            </div>
          )}
          <div>
            <div style={{ fontSize: 10, color: "#64748b", letterSpacing: "0.08em", marginBottom: 5 }}>RAW OUTPUT</div>
            <div style={{
              fontSize: 12, color: "#94a3b8", lineHeight: 1.6,
              padding: "10px 12px", background: "rgba(0,0,0,0.25)",
              borderRadius: 8, border: "1px solid rgba(255,255,255,0.06)",
              maxHeight: 140, overflowY: "auto", fontStyle: "italic",
            }}>
              "{data.raw_output}"
            </div>
          </div>
        </div>
      );

      case "voice": return (
        <div>
          <div style={{ marginBottom: 10, padding: "8px 12px", background: "rgba(251,146,60,0.08)", borderRadius: 8, border: "1px solid rgba(251,146,60,0.2)" }}>
            <span style={{ fontSize: 11, color: "#fb923c", fontWeight: 600 }}>
              {data.tts_engine} / {data.voice_id}
            </span>
          </div>
          <VoiceParamBar label="STABILITY (lower = more human)" value={data.stability} color="#fb923c" />
          <VoiceParamBar label="SIMILARITY BOOST" value={data.similarity_boost} color="#f59e0b" />
          <VoiceParamBar label="STYLE EXAGGERATION (pitch range)" value={data.style_exaggeration} color="#fbbf24" />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 6, marginTop: 10 }}>
            {[
              ["Raw Chars", data.raw_text_length, "#94a3b8"],
              ["Clean Chars", data.cleaned_text_length, "#38bdf8"],
              ["Stripped", data.chars_removed, "#fb923c"],
              ["Duration", `${(data.audio_duration_ms/1000).toFixed(1)}s`, "#34d399"],
              ["Synth Latency", `${data.synthesis_latency_ms.toFixed(0)}ms`, "#a78bfa"],
            ].map(([l, v, c]) => (
              <div key={l} style={{ padding: "8px 10px", background: `${c}10`, borderRadius: 8, border: `1px solid ${c}25` }}>
                <div style={{ fontSize: 9, color: "#64748b", letterSpacing: "0.06em" }}>{l}</div>
                <div style={{ fontSize: 12, color: c, fontWeight: 700, marginTop: 2 }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      );

      case "feedback": {
        const fb = chain.feedback;
        const s = SENTIMENT_STYLE[fb.sentiment] || SENTIMENT_STYLE.neutral;
        return (
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
              <span style={{ fontSize: 32 }}>{s.icon}</span>
              <div>
                <div style={{ fontSize: 18, color: s.color, fontWeight: 800 }}>{s.label}</div>
                <div style={{ fontSize: 10, color: "#64748b" }}>via {fb.source} · {timeAgo(fb.given_at)}</div>
              </div>
            </div>
            {fb.tags.length > 0 && (
              <div style={{ marginBottom: 10 }}>
                <div style={{ fontSize: 10, color: "#64748b", letterSpacing: "0.08em", marginBottom: 5 }}>TAGS</div>
                <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
                  {fb.tags.map(t => (
                    <span key={t} style={{
                      fontSize: 11, padding: "3px 10px", borderRadius: 12,
                      background: `${s.color}15`, border: `1px solid ${s.color}40`,
                      color: s.color, fontWeight: 600,
                    }}>{t}</span>
                  ))}
                </div>
              </div>
            )}
            {fb.memory_effect && (
              <div style={{ padding: "10px 12px", background: "rgba(167,139,250,0.08)", borderRadius: 8, border: "1px solid rgba(167,139,250,0.2)" }}>
                <div style={{ fontSize: 10, color: "#64748b", letterSpacing: "0.08em", marginBottom: 3 }}>MEMORY EFFECT</div>
                <div style={{ fontSize: 11, color: "#a78bfa" }}>{fb.memory_effect}</div>
              </div>
            )}
          </div>
        );
      }

      default: return null;
    }
  };

  return (
    <div style={{
      background: "rgba(15,20,30,0.95)", borderRadius: 14,
      border: "1px solid rgba(255,255,255,0.08)",
      overflow: "hidden",
    }}>
      {/* Stage pipeline */}
      <div style={{ padding: "14px 16px", borderBottom: "1px solid rgba(255,255,255,0.06)", display: "flex", flexWrap: "wrap", gap: 6, alignItems: "center" }}>
        {["intent","memory","personality","generation","voice"].map((s, i) => (
          <div key={s} style={{ display: "flex", alignItems: "center", gap: 5 }}>
            {i > 0 && <span style={{ color: "#1e293b", fontSize: 12 }}>→</span>}
            <StagePill stage={s} data={chain[s]} active={!chain.completed} />
          </div>
        ))}
        <div style={{ marginLeft: "auto", display: "flex", gap: 8, alignItems: "center" }}>
          {chain.feedback && <FeedbackBadge feedback={chain.feedback} />}
          {chain.total_latency_ms > 0 && (
            <span style={{ fontSize: 10, color: "#475569" }}>{chain.total_latency_ms.toFixed(0)}ms total</span>
          )}
        </div>
      </div>

      {/* Tab bar */}
      <div style={{ display: "flex", borderBottom: "1px solid rgba(255,255,255,0.06)", overflowX: "auto" }}>
        {tabs.map(t => {
          const cfg = STAGE_CONFIG[t] || { icon: "📊", label: "Feedback", color: "#c084fc" };
          const active = tab === t;
          return (
            <button key={t} onClick={() => setTab(t)} style={{
              padding: "10px 16px", border: "none", cursor: "pointer",
              background: active ? `${cfg.color}12` : "transparent",
              borderBottom: active ? `2px solid ${cfg.color}` : "2px solid transparent",
              color: active ? cfg.color : "#475569",
              fontSize: 11, fontWeight: active ? 700 : 400,
              letterSpacing: "0.06em", whiteSpace: "nowrap",
              transition: "all 0.2s",
            }}>
              {cfg.icon} {cfg.label.toUpperCase()}
            </button>
          );
        })}
      </div>

      {/* Stage content */}
      <div style={{ padding: 16, minHeight: 180 }}>
        {renderStageContent()}
      </div>
    </div>
  );
}

// ── Filler Heatmap ─────────────────────────────────────────────────────────────
function FillerHeatmap({ chains }) {
  const stats = {};
  chains.forEach(c => {
    const fillers = c.generation?.fillers_in_output || [];
    const sent = c.feedback?.sentiment || "neutral";
    fillers.forEach(f => {
      if (!stats[f]) stats[f] = { loved: 0, liked: 0, neutral: 0, disliked: 0, hated: 0 };
      if (stats[f][sent] !== undefined) stats[f][sent]++;
    });
  });

  const fillers = Object.keys(stats);
  if (fillers.length === 0) return (
    <div style={{ color: "#475569", fontSize: 12, textAlign: "center", padding: 20 }}>
      No filler data yet — Luna needs more conversations!
    </div>
  );

  return (
    <div>
      {fillers.map(f => {
        const d = stats[f];
        const total = Object.values(d).reduce((a, b) => a + b, 0);
        const positivity = total > 0 ? ((d.loved * 2 + d.liked) / (total * 2)) : 0;
        return (
          <div key={f} style={{ marginBottom: 10 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
              <span style={{ fontSize: 12, color: "#f472b6", fontStyle: "italic" }}>"{f}..."</span>
              <span style={{ fontSize: 10, color: "#475569" }}>{total} uses</span>
            </div>
            <div style={{ display: "flex", height: 8, borderRadius: 4, overflow: "hidden", gap: 1 }}>
              {[["loved","#c084fc"], ["liked","#34d399"], ["neutral","#475569"], ["disliked","#fb923c"], ["hated","#f87171"]].map(([sent, col]) => {
                const pct = total > 0 ? (d[sent] / total) * 100 : 0;
                return pct > 0 ? <div key={sent} style={{ width: `${pct}%`, background: col }} /> : null;
              })}
            </div>
            <div style={{ display: "flex", gap: 3, marginTop: 3 }}>
              {[["loved","💜"], ["liked","👍"], ["neutral","🤔"], ["disliked","👎"], ["hated","😭"]].map(([sent, emoji]) =>
                d[sent] > 0 ? (
                  <span key={sent} style={{ fontSize: 9, color: "#64748b" }}>{emoji}{d[sent]}</span>
                ) : null
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// MAIN DASHBOARD
// ══════════════════════════════════════════════════════════════════════════════

export default function LunaDashboard() {
  const [chains, setChains]           = useState(MOCK_CHAINS);
  const [selectedChain, setSelected]  = useState(MOCK_CHAINS[0]);
  const [wsStatus, setWsStatus]       = useState("demo");  // "demo"|"connected"|"disconnected"
  const [liveEvents, setLiveEvents]   = useState([]);
  const wsRef = useRef(null);

  // ── WebSocket connection ───────────────────────────────────────────────────
  useEffect(() => {
    const connect = () => {
      try {
        const ws = new WebSocket("ws://localhost:8765");
        wsRef.current = ws;

        ws.onopen = () => {
          setWsStatus("connected");
          setChains([]);
        };

        ws.onmessage = (e) => {
          const event = JSON.parse(e.data);

          if (event.type === "history") {
            setChains(event.chains.reverse());
            if (event.chains.length > 0) setSelected(event.chains[0]);
            return;
          }

          setLiveEvents(prev => [event, ...prev].slice(0, 50));

          if (event.type === "chain_start") {
            const newChain = {
              chain_id: event.chain_id, session_id: event.session_id,
              created_at: new Date().toISOString(), completed: false,
              total_latency_ms: 0,
              intent: null, memory: null, personality: null, generation: null, voice: null, feedback: null,
            };
            setChains(prev => [newChain, ...prev]);
            setSelected(newChain);
          }

          if (event.type === "stage_update") {
            setChains(prev => prev.map(c => {
              if (c.chain_id !== event.chain_id) return c;
              return { ...c, [event.stage]: event.data };
            }));
            setSelected(prev => prev?.chain_id === event.chain_id
              ? { ...prev, [event.stage]: event.data }
              : prev
            );
          }

          if (event.type === "chain_complete") {
            setChains(prev => prev.map(c =>
              c.chain_id === event.chain_id ? { ...c, completed: true, total_latency_ms: event.latency_ms } : c
            ));
          }

          if (event.type === "feedback_received") {
            setChains(prev => prev.map(c => {
              if (c.chain_id !== event.chain_id) return c;
              return { ...c, feedback: { sentiment: event.sentiment, tags: event.tags, source: "reaction", raw: "", memory_effect: event.memory_effect, given_at: new Date().toISOString() } };
            }));
          }
        };

        ws.onclose = () => { setWsStatus("disconnected"); setTimeout(connect, 3000); };
        ws.onerror = () => ws.close();
      } catch (e) {
        setWsStatus("disconnected");
      }
    };
    connect();
    return () => wsRef.current?.close();
  }, []);

  // ── Stats ──────────────────────────────────────────────────────────────────
  const stats = {
    total: chains.length,
    loved: chains.filter(c => c.feedback?.sentiment === "loved").length,
    gemini: chains.filter(c => c.intent?.engine_selected === "gemini").length,
    ollama: chains.filter(c => c.intent?.engine_selected === "ollama").length,
    avgLatency: chains.filter(c => c.total_latency_ms > 0).reduce((acc, c, _, arr) =>
      acc + c.total_latency_ms / arr.length, 0),
    cacheHits: chains.filter(c => c.generation?.cache_hit).length,
  };

  // ── Styles ─────────────────────────────────────────────────────────────────
  const styles = {
    root: {
      fontFamily: "'JetBrains Mono', 'Fira Code', 'Courier New', monospace",
      background: "#070b14",
      minHeight: "100vh",
      color: "#e2e8f0",
      padding: 0,
    },
  };

  return (
    <div style={styles.root}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;600;700;800&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 2px; }
        @keyframes pulse { 0%,100% { opacity: 0.5; } 50% { opacity: 1; } }
        @keyframes slideIn { from { opacity:0; transform: translateY(-6px); } to { opacity:1; transform:translateY(0); } }
        @keyframes glow { 0%,100% { box-shadow: 0 0 12px rgba(192,132,252,0.2); } 50% { box-shadow: 0 0 28px rgba(192,132,252,0.45); } }
      `}</style>

      {/* ── Header ────────────────────────────────────────────────────────── */}
      <div style={{
        padding: "16px 24px", display: "flex", alignItems: "center", justifyContent: "space-between",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        background: "rgba(192,132,252,0.04)",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{
            width: 36, height: 36, borderRadius: "50%",
            background: "radial-gradient(circle, #c084fc, #7c3aed)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 18, animation: "glow 3s ease-in-out infinite",
          }}>🌙</div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 800, letterSpacing: "0.12em", color: "#c084fc" }}>
              LUNA CORE
            </div>
            <div style={{ fontSize: 9, color: "#475569", letterSpacing: "0.1em" }}>
              DECISION CHAIN MONITOR v1.0
            </div>
          </div>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          {/* Stats row */}
          {[
            [`${stats.total}`, "CHAINS"],
            [`${stats.loved}`, "LOVED"],
            [`${stats.cacheHits}`, "CACHE HITS"],
            [`${stats.avgLatency.toFixed(0)}ms`, "AVG LATENCY"],
          ].map(([val, lbl]) => (
            <div key={lbl} style={{ textAlign: "right" }}>
              <div style={{ fontSize: 16, fontWeight: 800, color: "#c084fc" }}>{val}</div>
              <div style={{ fontSize: 8, color: "#475569", letterSpacing: "0.1em" }}>{lbl}</div>
            </div>
          ))}

          {/* WS status */}
          <div style={{
            display: "flex", alignItems: "center", gap: 5,
            padding: "5px 10px", borderRadius: 20,
            background: wsStatus === "connected" ? "rgba(52,211,153,0.1)" : wsStatus === "demo" ? "rgba(251,146,60,0.1)" : "rgba(248,113,113,0.1)",
            border: `1px solid ${wsStatus === "connected" ? "#34d39940" : wsStatus === "demo" ? "#fb923c40" : "#f8717140"}`,
          }}>
            <div style={{
              width: 6, height: 6, borderRadius: "50%",
              background: wsStatus === "connected" ? "#34d399" : wsStatus === "demo" ? "#fb923c" : "#f87171",
              animation: wsStatus === "connected" ? "pulse 2s infinite" : "none",
            }} />
            <span style={{ fontSize: 9, color: wsStatus === "connected" ? "#34d399" : wsStatus === "demo" ? "#fb923c" : "#f87171", letterSpacing: "0.1em" }}>
              {wsStatus === "demo" ? "DEMO MODE" : wsStatus === "connected" ? "LIVE" : "DISCONNECTED"}
            </span>
          </div>
        </div>
      </div>

      {/* ── Main layout ────────────────────────────────────────────────────── */}
      <div style={{ display: "grid", gridTemplateColumns: "280px 1fr 240px", height: "calc(100vh - 65px)" }}>

        {/* ── Left: Chain List ────────────────────────────────────────────── */}
        <div style={{ borderRight: "1px solid rgba(255,255,255,0.06)", overflowY: "auto", padding: "8px 0" }}>
          <div style={{ padding: "8px 14px 4px", fontSize: 9, color: "#475569", letterSpacing: "0.1em" }}>
            RECENT CHAINS
          </div>
          {chains.map(chain => {
            const isActive = !chain.completed;
            const isSelected = selectedChain?.chain_id === chain.chain_id;
            const fb = chain.feedback;
            const s = fb ? (SENTIMENT_STYLE[fb.sentiment] || SENTIMENT_STYLE.neutral) : null;

            return (
              <div key={chain.chain_id} onClick={() => setSelected(chain)} style={{
                padding: "10px 14px", cursor: "pointer",
                background: isSelected ? "rgba(192,132,252,0.08)" : "transparent",
                borderLeft: isSelected ? "2px solid #c084fc" : "2px solid transparent",
                borderBottom: "1px solid rgba(255,255,255,0.03)",
                transition: "all 0.15s",
                animation: isActive ? "pulse 2s infinite" : "none",
              }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
                  <span style={{ fontSize: 9, color: chain.intent ? ENGINE_COLOR[chain.intent.engine_selected] : "#475569", fontWeight: 700 }}>
                    {chain.intent?.classified_as || "…"}
                  </span>
                  <span style={{ fontSize: 9, color: "#334155" }}>
                    {timeAgo(chain.created_at)}
                  </span>
                </div>
                <div style={{ fontSize: 11, color: isSelected ? "#e2e8f0" : "#94a3b8", marginBottom: 4, lineHeight: 1.4 }}>
                  {truncate(chain.intent?.raw_input || "…", 38)}
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 9, color: "#1e293b", fontFamily: "monospace" }}>
                    {chain.chain_id}
                  </span>
                  {isActive ? (
                    <span style={{ fontSize: 8, color: "#38bdf8", animation: "pulse 1.4s infinite" }}>● LIVE</span>
                  ) : s ? (
                    <span style={{ fontSize: 11 }}>{s.icon}</span>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>

        {/* ── Center: Chain Detail ─────────────────────────────────────────── */}
        <div style={{ overflowY: "auto", padding: 16 }}>
          {selectedChain ? (
            <div style={{ animation: "slideIn 0.2s ease" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                <div>
                  <div style={{ fontSize: 11, color: "#c084fc", fontWeight: 700, letterSpacing: "0.08em" }}>
                    CHAIN {selectedChain.chain_id}
                  </div>
                  <div style={{ fontSize: 9, color: "#475569", marginTop: 2 }}>
                    {new Date(selectedChain.created_at).toLocaleString()}
                    {selectedChain.total_latency_ms > 0 && ` · ${selectedChain.total_latency_ms.toFixed(0)}ms`}
                  </div>
                </div>
                {selectedChain.feedback && <FeedbackBadge feedback={selectedChain.feedback} />}
              </div>
              <ChainDetail chain={selectedChain} />
            </div>
          ) : (
            <div style={{ color: "#334155", textAlign: "center", marginTop: 80, fontSize: 13 }}>
              ← Select a chain to inspect
            </div>
          )}
        </div>

        {/* ── Right: Analytics + Live Feed ─────────────────────────────────── */}
        <div style={{ borderLeft: "1px solid rgba(255,255,255,0.06)", overflowY: "auto", padding: 12 }}>

          {/* Engine split */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 9, color: "#475569", letterSpacing: "0.1em", marginBottom: 8 }}>ENGINE SPLIT</div>
            <div style={{ height: 8, borderRadius: 4, overflow: "hidden", display: "flex" }}>
              {stats.total > 0 && <>
                <div style={{ width: `${(stats.ollama/stats.total)*100}%`, background: "#10b981" }} />
                <div style={{ width: `${(stats.gemini/stats.total)*100}%`, background: "#4285f4" }} />
              </>}
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}>
              <span style={{ fontSize: 9, color: "#10b981" }}>ollama {stats.ollama}</span>
              <span style={{ fontSize: 9, color: "#4285f4" }}>gemini {stats.gemini}</span>
            </div>
          </div>

          {/* Sentiment breakdown */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 9, color: "#475569", letterSpacing: "0.1em", marginBottom: 8 }}>FEEDBACK SENTIMENT</div>
            {["loved","liked","neutral","disliked","hated"].map(sent => {
              const n = chains.filter(c => c.feedback?.sentiment === sent).length;
              const pct = chains.filter(c => c.feedback).length > 0 ? (n / chains.filter(c => c.feedback).length) * 100 : 0;
              const s = SENTIMENT_STYLE[sent];
              return n > 0 ? (
                <div key={sent} style={{ marginBottom: 6 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
                    <span style={{ fontSize: 10 }}>{s.icon} {s.label}</span>
                    <span style={{ fontSize: 9, color: s.color }}>{n}</span>
                  </div>
                  <div style={{ height: 4, borderRadius: 2, background: "rgba(255,255,255,0.04)" }}>
                    <div style={{ height: "100%", width: `${pct}%`, background: s.color, borderRadius: 2 }} />
                  </div>
                </div>
              ) : null;
            })}
          </div>

          {/* Filler heatmap */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 9, color: "#475569", letterSpacing: "0.1em", marginBottom: 8 }}>FILLER SENTIMENT HEATMAP</div>
            <FillerHeatmap chains={chains} />
          </div>

          {/* Live event feed */}
          <div>
            <div style={{ fontSize: 9, color: "#475569", letterSpacing: "0.1em", marginBottom: 8 }}>LIVE EVENT FEED</div>
            {wsStatus !== "connected" ? (
              <div style={{ fontSize: 10, color: "#334155", textAlign: "center", padding: "12px 8px", background: "rgba(251,146,60,0.05)", borderRadius: 6, border: "1px solid rgba(251,146,60,0.15)" }}>
                Connect Luna backend to see live events
                <div style={{ fontSize: 9, color: "#475569", marginTop: 4 }}>ws://localhost:8765</div>
              </div>
            ) : liveEvents.length === 0 ? (
              <div style={{ fontSize: 10, color: "#334155", textAlign: "center", padding: 12 }}>
                Waiting for events...
              </div>
            ) : (
              liveEvents.slice(0, 12).map((e, i) => (
                <div key={i} style={{
                  padding: "5px 8px", marginBottom: 3, borderRadius: 6,
                  background: "rgba(255,255,255,0.03)", fontSize: 9,
                  color: "#64748b", animation: i === 0 ? "slideIn 0.2s ease" : "none",
                  borderLeft: `2px solid ${
                    e.type === "stage_update" ? STAGE_CONFIG[e.stage]?.color || "#475569" :
                    e.type === "feedback_received" ? "#c084fc" :
                    e.type === "chain_start" ? "#38bdf8" : "#475569"
                  }40`,
                }}>
                  <span style={{ color: "#475569" }}>{e.type}</span>
                  {e.chain_id && <span style={{ color: "#334155", marginLeft: 4 }}>{e.chain_id.slice(0,8)}</span>}
                  {e.stage && <span style={{ color: STAGE_CONFIG[e.stage]?.color || "#94a3b8", marginLeft: 4 }}>→{e.stage}</span>}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
