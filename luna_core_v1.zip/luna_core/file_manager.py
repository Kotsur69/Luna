"""
Luna Core v1.0 — File Manager (Luna's Hands)
════════════════════════════════════════════════════════════════════════════════

Luna can read and write files inside the repository.
She CANNOT touch anything outside the allowed roots,
cannot read secrets, and cannot write more than FILE_MAX_WRITE_BYTES at once.

Every operation is:
  • Validated against allowed roots and blocked patterns
  • Logged with a one-line audit trail
  • Returned as a FileResult so Luna's self-correction loop can act on it

════════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import difflib
import fnmatch
import os
import shutil
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

from config import (
    REPO_DIR, BASE_DIR,
    FILE_ALLOWED_ROOTS, FILE_BLOCKED_PATTERNS,
    FILE_MAX_READ_BYTES, FILE_MAX_WRITE_BYTES,
)


# ══════════════════════════════════════════════════════════════════════════════
# RESULT TYPE
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class FileResult:
    success:  bool
    path:     str
    operation:str           # read | write | list | delete | diff
    content:  Optional[str] = None    # for read
    entries:  Optional[list] = None   # for list
    message:  str           = ""
    bytes_affected: int     = 0

    def to_luna_report(self) -> str:
        if not self.success:
            return f"❌ File op failed [{self.operation}] `{self.path}`\n{self.message}"
        if self.operation == "read":
            return f"📄 `{self.path}` ({self.bytes_affected} bytes):\n```\n{self.content}\n```"
        if self.operation == "write":
            return f"✅ Written `{self.path}` ({self.bytes_affected} bytes)"
        if self.operation == "list":
            lines = "\n".join(
                f"  {'📁' if e['is_dir'] else '📄'} {e['name']:40s} {e.get('size','')}"
                for e in (self.entries or [])
            )
            return f"📂 `{self.path}`:\n{lines}"
        if self.operation == "diff":
            return f"📝 Diff for `{self.path}`:\n```diff\n{self.content}\n```"
        return f"✅ {self.operation} `{self.path}`"


@dataclass
class AuditEntry:
    ts:        str
    operation: str
    path:      str
    success:   bool
    detail:    str = ""


# ══════════════════════════════════════════════════════════════════════════════
# GUARDRAILS
# ══════════════════════════════════════════════════════════════════════════════

def _resolve_and_validate(raw_path: str) -> tuple[Optional[Path], Optional[str]]:
    """
    Resolve the path and check it against allowed roots and blocked patterns.
    Returns (resolved_path, None) on success, or (None, error_message) on deny.
    """
    # Resolve to absolute path (resolves ../ etc.)
    try:
        target = Path(raw_path).expanduser().resolve()
    except Exception as e:
        return None, f"Invalid path: {e}"

    # ── Must be inside an allowed root ────────────────────────────────────────
    allowed = [Path(r).resolve() for r in FILE_ALLOWED_ROOTS]
    inside_any = any(
        str(target).startswith(str(root)) for root in allowed
    )
    if not inside_any:
        return None, (
            f"🛑 Path outside allowed roots: `{target}`\n"
            f"Allowed: {[str(r) for r in allowed]}"
        )

    # ── Blocked patterns ──────────────────────────────────────────────────────
    target_str = str(target)
    for pattern in FILE_BLOCKED_PATTERNS:
        if fnmatch.fnmatch(target_str, pattern) or fnmatch.fnmatch(target.name, pattern):
            return None, f"🛑 Path matches blocked pattern `{pattern}`: `{target}`"

    return target, None


def _deny(op: str, path: str, reason: str) -> FileResult:
    print(f"[FileManager] DENY {op} '{path}': {reason}")
    return FileResult(success=False, path=path, operation=op, message=reason)


# ══════════════════════════════════════════════════════════════════════════════
# FILE MANAGER
# ══════════════════════════════════════════════════════════════════════════════

class FileManager:
    """
    Luna's file I/O interface.
    All methods are synchronous — call from async context with asyncio.to_thread().
    """

    def __init__(self):
        self._audit: list[AuditEntry] = []
        print(f"[FileManager] Initialized. Allowed roots: {FILE_ALLOWED_ROOTS}")

    # ── Read ──────────────────────────────────────────────────────────────────

    def read_file(self, path: str, max_bytes: int = None) -> FileResult:
        """
        Read a file and return its contents.
        Respects FILE_MAX_READ_BYTES unless overridden.
        """
        resolved, err = _resolve_and_validate(path)
        if err:
            return _deny("read", path, err)

        if not resolved.exists():
            return _deny("read", path, f"File not found: `{resolved}`")

        if resolved.is_dir():
            return _deny("read", path, f"Path is a directory. Use list_files() instead.")

        limit   = max_bytes or FILE_MAX_READ_BYTES
        size    = resolved.stat().st_size

        if size > limit:
            return _deny("read", path,
                f"File too large: {size:,} bytes (limit {limit:,}). "
                f"Use `read_file(path, max_bytes=…)` or read a specific line range."
            )

        try:
            content = resolved.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            return _deny("read", path, str(e))

        self._log("read", str(resolved), True)
        return FileResult(
            success=True, path=str(resolved), operation="read",
            content=content, bytes_affected=size,
            message=f"Read {size:,} bytes."
        )

    def read_lines(self, path: str, start: int, end: int) -> FileResult:
        """
        Read a specific line range (1-indexed, inclusive).
        Useful when the full file is too large.
        """
        result = self.read_file(path)
        if not result.success:
            return result

        lines = result.content.splitlines()
        s, e  = max(0, start - 1), min(len(lines), end)
        snippet = "\n".join(f"{i+s+1}: {l}" for i, l in enumerate(lines[s:e]))

        return FileResult(
            success=True, path=result.path, operation="read",
            content=snippet, bytes_affected=len(snippet),
            message=f"Lines {start}–{end} of {len(lines)} total."
        )

    # ── Write ─────────────────────────────────────────────────────────────────

    def write_file(
        self,
        path:    str,
        content: str,
        create_dirs: bool = True,
        backup:      bool = True,
    ) -> FileResult:
        """
        Write content to a file.
        - Creates parent directories if create_dirs=True.
        - Creates a .bak backup of the previous version if backup=True.
        """
        resolved, err = _resolve_and_validate(path)
        if err:
            return _deny("write", path, err)

        if len(content.encode()) > FILE_MAX_WRITE_BYTES:
            return _deny("write", path,
                f"Content too large: {len(content.encode()):,} bytes (limit {FILE_MAX_WRITE_BYTES:,})"
            )

        if create_dirs:
            resolved.parent.mkdir(parents=True, exist_ok=True)

        # Backup existing file
        if backup and resolved.exists():
            bak = resolved.with_suffix(resolved.suffix + ".bak")
            try:
                shutil.copy2(resolved, bak)
            except Exception:
                pass  # backup failure is non-fatal

        try:
            resolved.write_text(content, encoding="utf-8")
        except Exception as e:
            return _deny("write", path, str(e))

        size = len(content.encode())
        self._log("write", str(resolved), True, f"{size} bytes")
        print(f"[FileManager] Written: {resolved} ({size} bytes)")
        return FileResult(
            success=True, path=str(resolved), operation="write",
            bytes_affected=size,
            message=f"Wrote {size:,} bytes to `{resolved.name}`."
        )

    def append_to_file(self, path: str, content: str) -> FileResult:
        """Append content to the end of an existing file."""
        resolved, err = _resolve_and_validate(path)
        if err:
            return _deny("append", path, err)

        try:
            with open(resolved, "a", encoding="utf-8") as f:
                f.write(content)
        except Exception as e:
            return _deny("append", path, str(e))

        self._log("append", str(resolved), True)
        return FileResult(
            success=True, path=str(resolved), operation="write",
            bytes_affected=len(content.encode()),
            message=f"Appended {len(content):,} chars to `{resolved.name}`."
        )

    def patch_file(self, path: str, old_text: str, new_text: str) -> FileResult:
        """
        Safe in-place patch: find `old_text` in the file and replace it with `new_text`.
        Safer than write_file for targeted edits — if old_text isn't found, it fails loudly.
        """
        result = self.read_file(path)
        if not result.success:
            return result

        if old_text not in result.content:
            return _deny("patch", path,
                f"Could not find the target text to replace.\n"
                f"Looking for:\n```\n{old_text[:200]}\n```"
            )

        count   = result.content.count(old_text)
        if count > 1:
            return _deny("patch", path,
                f"Target text appears {count} times — ambiguous. Make it more specific."
            )

        new_content = result.content.replace(old_text, new_text, 1)
        return self.write_file(path, new_content)

    # ── List ──────────────────────────────────────────────────────────────────

    def list_files(
        self,
        path:      str         = None,
        pattern:   str         = "*",
        recursive: bool        = False,
        max_depth: int         = 3,
    ) -> FileResult:
        """
        List files in a directory. Defaults to REPO_DIR.
        """
        raw = path or str(REPO_DIR)
        resolved, err = _resolve_and_validate(raw)
        if err:
            return _deny("list", raw, err)

        if not resolved.is_dir():
            return _deny("list", raw, f"Not a directory: `{resolved}`")

        entries = []
        skip_dirs = {".git", "__pycache__", ".venv", "venv", "node_modules", ".mypy_cache"}

        def _scan(p: Path, depth: int):
            if depth > max_depth:
                return
            try:
                items = sorted(p.iterdir(), key=lambda x: (x.is_file(), x.name.lower()))
            except PermissionError:
                return
            for item in items:
                if item.name.startswith(".") and item.name not in [".env.template"]:
                    continue
                if item.is_dir() and item.name in skip_dirs:
                    continue
                rel = str(item.relative_to(resolved))
                if fnmatch.fnmatch(item.name, pattern) or item.is_dir():
                    size_str = ""
                    if item.is_file():
                        try:
                            size_str = f"{item.stat().st_size:,}b"
                        except Exception:
                            pass
                    entries.append({
                        "name":   rel,
                        "is_dir": item.is_dir(),
                        "size":   size_str,
                        "path":   str(item),
                    })
                if recursive and item.is_dir():
                    _scan(item, depth + 1)

        _scan(resolved, 1)
        self._log("list", str(resolved), True, f"{len(entries)} entries")
        return FileResult(
            success=True, path=str(resolved), operation="list",
            entries=entries, message=f"{len(entries)} items."
        )

    # ── Diff ──────────────────────────────────────────────────────────────────

    def diff(self, path: str, new_content: str) -> FileResult:
        """
        Return a unified diff between the current file and proposed new content.
        Use this BEFORE writing to show Luna (and the user) exactly what will change.
        """
        result = self.read_file(path)
        original = result.content if result.success else ""

        diff_lines = list(difflib.unified_diff(
            original.splitlines(keepends=True),
            new_content.splitlines(keepends=True),
            fromfile=f"a/{Path(path).name}",
            tofile=f"b/{Path(path).name}",
            n=3,
        ))
        diff_text = "".join(diff_lines) or "(no changes)"

        return FileResult(
            success=True, path=path, operation="diff",
            content=diff_text,
            message=f"{len(diff_lines)} diff lines."
        )

    # ── Delete ────────────────────────────────────────────────────────────────

    def delete_file(self, path: str) -> FileResult:
        """Delete a file. Requires explicit call — Luna can't delete dirs."""
        resolved, err = _resolve_and_validate(path)
        if err:
            return _deny("delete", path, err)

        if not resolved.exists():
            return _deny("delete", path, "File not found.")

        if resolved.is_dir():
            return _deny("delete", path, "Cannot delete directories. Only files.")

        try:
            bak = resolved.with_suffix(resolved.suffix + ".deleted.bak")
            shutil.copy2(resolved, bak)
            resolved.unlink()
        except Exception as e:
            return _deny("delete", path, str(e))

        self._log("delete", str(resolved), True)
        return FileResult(
            success=True, path=str(resolved), operation="delete",
            message=f"Deleted `{resolved.name}` (backup at `{bak.name}`)."
        )

    # ── Audit ─────────────────────────────────────────────────────────────────

    def _log(self, op: str, path: str, success: bool, detail: str = ""):
        entry = AuditEntry(
            ts        = datetime.utcnow().isoformat()[:19],
            operation = op,
            path      = path,
            success   = success,
            detail    = detail,
        )
        self._audit.append(entry)
        if len(self._audit) > 500:
            self._audit = self._audit[-500:]

    def audit_log(self, last_n: int = 20) -> str:
        rows = self._audit[-last_n:]
        lines = [f"{'TS':20s} {'OP':8s} {'OK':3s} {'PATH':<50s} DETAIL"]
        lines.append("─" * 100)
        for e in rows:
            ok = "✓" if e.success else "✗"
            lines.append(f"{e.ts:20s} {e.operation:8s} {ok:3s} {e.path:<50s} {e.detail}")
        return "\n".join(lines)


# ── Module-level singleton ────────────────────────────────────────────────────
file_manager = FileManager()
