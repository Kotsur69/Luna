"""
Luna Core v1.0 — Memory Engine
Stores user facts (humor, financial goals, code style preferences) in a local
SQLite DB and injects the most relevant ones into every Gemini prompt.

Schema mirrors Mem0's concept of "memories" but runs 100% locally.
"""

import sqlite3
import json
import time
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, asdict

from config import DB_PATH, MEMORY_INJECT_LIMIT


# ── Data Model ────────────────────────────────────────────────────────────────

@dataclass
class Memory:
    id: str
    category: str          # humor | financial | code_style | preference | fact
    content: str           # the actual memory text
    importance: float      # 0.0–1.0  (higher = injected first)
    source: str            # "user_said" | "inferred" | "explicit"
    created_at: str
    updated_at: str
    access_count: int = 0
    metadata: dict = None

    def to_prompt_line(self) -> str:
        return f"[{self.category.upper()}] {self.content}"


# ── DB Layer ──────────────────────────────────────────────────────────────────

class MemoryEngine:
    """
    Local SQLite-backed memory system.
    API-compatible with Mem0's .add() / .search() / .get_all() patterns.
    """

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self._conn  = sqlite3.connect(str(db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()
        print(f"[Memory] Loaded DB: {db_path}")

    # ── Schema ────────────────────────────────────────────────────────────────

    def _init_schema(self):
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS memories (
                id           TEXT PRIMARY KEY,
                category     TEXT NOT NULL,
                content      TEXT NOT NULL,
                importance   REAL DEFAULT 0.5,
                source       TEXT DEFAULT 'inferred',
                created_at   TEXT NOT NULL,
                updated_at   TEXT NOT NULL,
                access_count INTEGER DEFAULT 0,
                metadata     TEXT DEFAULT '{}'
            );

            CREATE TABLE IF NOT EXISTS memory_tags (
                memory_id TEXT REFERENCES memories(id),
                tag       TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_memory_category ON memories(category);
            CREATE INDEX IF NOT EXISTS idx_memory_importance ON memories(importance DESC);
        """)
        self._conn.commit()

    # ── CRUD ──────────────────────────────────────────────────────────────────

    def add(
        self,
        content: str,
        category: str = "fact",
        importance: float = 0.5,
        source: str = "inferred",
        tags: list[str] = None,
        metadata: dict = None,
    ) -> Memory:
        """Store a new memory. Deduplicates by content hash."""
        mem_id   = hashlib.sha256(content.encode()).hexdigest()[:16]
        now      = datetime.utcnow().isoformat()
        meta_str = json.dumps(metadata or {})

        self._conn.execute("""
            INSERT INTO memories (id, category, content, importance, source,
                                  created_at, updated_at, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                importance   = MAX(importance, excluded.importance),
                access_count = access_count + 1,
                updated_at   = excluded.updated_at
        """, (mem_id, category, content, importance, source, now, now, meta_str))

        if tags:
            self._conn.executemany(
                "INSERT OR IGNORE INTO memory_tags VALUES (?, ?)",
                [(mem_id, t) for t in tags]
            )

        self._conn.commit()
        return self._row_to_memory(self._conn.execute(
            "SELECT * FROM memories WHERE id = ?", (mem_id,)
        ).fetchone())

    def update_importance(self, mem_id: str, delta: float = 0.05):
        """Boost importance when a memory proves relevant."""
        self._conn.execute("""
            UPDATE memories
            SET importance   = MIN(1.0, importance + ?),
                access_count = access_count + 1,
                updated_at   = ?
            WHERE id = ?
        """, (delta, datetime.utcnow().isoformat(), mem_id))
        self._conn.commit()

    def delete(self, mem_id: str):
        self._conn.execute("DELETE FROM memories WHERE id = ?", (mem_id,))
        self._conn.execute("DELETE FROM memory_tags WHERE memory_id = ?", (mem_id,))
        self._conn.commit()

    # ── Retrieval ─────────────────────────────────────────────────────────────

    def get_all(self, category: str = None, limit: int = 50) -> list[Memory]:
        if category:
            rows = self._conn.execute(
                "SELECT * FROM memories WHERE category = ? ORDER BY importance DESC LIMIT ?",
                (category, limit)
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM memories ORDER BY importance DESC LIMIT ?", (limit,)
            ).fetchall()
        return [self._row_to_memory(r) for r in rows]

    def search(self, query: str, limit: int = MEMORY_INJECT_LIMIT) -> list[Memory]:
        """
        Simple keyword search. For production, swap with sqlite-vss or
        a local embedding search (e.g., chroma + nomic-embed-text).
        """
        words   = query.lower().split()
        results = {}

        for word in words:
            rows = self._conn.execute("""
                SELECT * FROM memories
                WHERE LOWER(content) LIKE ?
                ORDER BY importance DESC
                LIMIT ?
            """, (f"%{word}%", limit * 2)).fetchall()

            for row in rows:
                m = self._row_to_memory(row)
                if m.id not in results:
                    results[m.id] = (m, 0)
                results[m.id] = (m, results[m.id][1] + m.importance)

        ranked = sorted(results.values(), key=lambda x: x[1], reverse=True)
        return [m for m, _ in ranked[:limit]]

    def build_injection_block(self, query: str = "") -> str:
        """
        Returns a formatted string block ready to inject into any LLM prompt.
        Fetches top memories by importance + relevance to query.
        """
        if query:
            memories = self.search(query, limit=MEMORY_INJECT_LIMIT)
        else:
            memories = self.get_all(limit=MEMORY_INJECT_LIMIT)

        if not memories:
            return ""

        lines = [m.to_prompt_line() for m in memories]
        block = "\n".join(lines)
        return f"## What Luna Knows About You\n{block}\n"

    # ── Convenience Writers ───────────────────────────────────────────────────

    def remember_code_style(self, style: str, importance: float = 0.7):
        return self.add(style, category="code_style", importance=importance, source="inferred")

    def remember_preference(self, pref: str, importance: float = 0.6):
        return self.add(pref, category="preference", importance=importance, source="user_said")

    def remember_financial_goal(self, goal: str, importance: float = 0.8):
        return self.add(goal, category="financial", importance=importance, source="user_said")

    def remember_humor(self, note: str, importance: float = 0.5):
        return self.add(note, category="humor", importance=importance, source="inferred")

    # ── Utils ─────────────────────────────────────────────────────────────────

    def _row_to_memory(self, row) -> Memory:
        return Memory(
            id          = row["id"],
            category    = row["category"],
            content     = row["content"],
            importance  = row["importance"],
            source      = row["source"],
            created_at  = row["created_at"],
            updated_at  = row["updated_at"],
            access_count= row["access_count"],
            metadata    = json.loads(row["metadata"] or "{}"),
        )

    def stats(self) -> dict:
        counts = self._conn.execute("""
            SELECT category, COUNT(*) as n, AVG(importance) as avg_imp
            FROM memories GROUP BY category
        """).fetchall()
        return {
            row["category"]: {
                "count":       row["n"],
                "avg_importance": round(row["avg_imp"], 3)
            }
            for row in counts
        }

    def close(self):
        self._conn.close()


# ── Auto-extraction helper ────────────────────────────────────────────────────

def extract_memories_from_conversation(
    engine: MemoryEngine,
    user_text: str,
    assistant_text: str,
):
    """
    Lightweight heuristic extractor — no extra LLM call needed.
    For deeper extraction, pipe both texts through Gemini Flash.
    """
    lower = user_text.lower()

    # Financial goals
    if any(kw in lower for kw in ["save", "invest", "goal", "budget", "money", "earn"]):
        engine.add(
            f"User mentioned financial context: '{user_text[:120]}'",
            category="financial", importance=0.65, source="inferred"
        )

    # Code style signals
    if any(kw in lower for kw in ["prefer", "always use", "never use", "style", "format"]):
        engine.add(
            f"Code preference noted: '{user_text[:120]}'",
            category="code_style", importance=0.7, source="user_said"
        )

    # Humor / personality
    if any(kw in lower for kw in ["lol", "haha", "joke", "funny", "sarcas"]):
        engine.add(
            "User has a sense of humor — appreciates wit and sarcasm.",
            category="humor", importance=0.5, source="inferred"
        )
