"""
Luna Core v1.0 — Sandbox Executor
════════════════════════════════════════════════════════════════════════════════

Luna writes code → Luna runs it → Luna reads the result → Luna fixes it.
That loop is what makes her feel like a real software engineer.

Three backends (choose in .env → SANDBOX_BACKEND):

  subprocess  Local isolated process with timeout + memory limits.
              Fastest. Good for trusted, iterative dev work.
              Runs in a restricted tempdir with no shell escaping.

  docker      Runs code inside luna-sandbox:latest container.
              Full isolation — container can't touch host filesystem.
              Slightly slower on first call (container spin-up ~0.3s).
              Recommended for anything that touches the network.

  e2b         Managed cloud sandbox (e2b.dev). Zero local setup.
              Requires E2B_API_KEY. Good for untrusted one-offs.

All backends return a CodeResult with the same structure so the
self-correction loop doesn't care which one ran.

════════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import asyncio
import os
import re
import shutil
import subprocess
import sys
import tempfile
import textwrap
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from config import (
    SANDBOX_BACKEND, SANDBOX_TIMEOUT_SEC, SANDBOX_MAX_OUTPUT,
    DOCKER_IMAGE, E2B_API_KEY, SANDBOX_LANGUAGES,
)


# ══════════════════════════════════════════════════════════════════════════════
# RESULT TYPE
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class CodeResult:
    success:       bool
    stdout:        str
    stderr:        str
    exit_code:     int
    runtime_ms:    float
    language:      str
    backend:       str
    timed_out:     bool      = False
    exception_type:Optional[str] = None   # e.g. "TypeError", "ZeroDivisionError"
    traceback:     Optional[str] = None   # cleaned traceback for Luna to read

    # ── Luna-readable summary ─────────────────────────────────────────────────
    def to_luna_report(self) -> str:
        """
        Returns a structured text block that Luna injects into her context
        so she can read the output exactly as a terminal would show it.
        """
        lines: list[str] = []
        lines.append(f"```\n[Sandbox: {self.backend} / {self.language} / {self.runtime_ms:.0f}ms]")

        if self.timed_out:
            lines.append(f"⏰ TIMEOUT after {SANDBOX_TIMEOUT_SEC}s — code was still running.")
        elif self.success:
            lines.append("✓ Exit 0 — code ran successfully.")
        else:
            lines.append(f"✗ Exit {self.exit_code} — execution failed.")

        if self.stdout.strip():
            lines.append(f"\n── stdout ──\n{self.stdout.strip()}")

        if self.stderr.strip():
            lines.append(f"\n── stderr ──\n{self.stderr.strip()}")

        if self.traceback:
            lines.append(f"\n── traceback ──\n{self.traceback.strip()}")
            if self.exception_type:
                lines.append(f"\nException type: {self.exception_type}")

        lines.append("```")
        return "\n".join(lines)

    @property
    def has_error(self) -> bool:
        return not self.success or self.timed_out


# ══════════════════════════════════════════════════════════════════════════════
# SAFETY / VALIDATION
# ══════════════════════════════════════════════════════════════════════════════

# Patterns that are never allowed — even in subprocess mode
_BLOCKED_PATTERNS = [
    r"import\s+os\s*;\s*os\s*\.\s*system",
    r"subprocess\.(?:call|run|Popen)\s*\(\s*[\"\'](?:rm|del|format|mkfs)",
    r"shutil\.rmtree\s*\(\s*[\"\']/",       # rmtree on absolute path
    r"open\s*\(\s*[\"\']/(?:etc|usr|bin|sys|root)",
    r"__import__\s*\(\s*['\"]builtins",
    r"ctypes",                               # FFI / memory manipulation
    r"socket\.(?:AF_INET|SOCK_RAW)",         # raw sockets
]
_BLOCKED_RE = [re.compile(p, re.IGNORECASE) for p in _BLOCKED_PATTERNS]

def _validate_code(code: str) -> Optional[str]:
    """Return an error message if the code contains blocked patterns, else None."""
    for pat in _BLOCKED_RE:
        if pat.search(code):
            return f"Blocked pattern detected: `{pat.pattern[:60]}`"
    return None


def _clean_traceback(tb: str) -> str:
    """Strip tempdir paths from tracebacks so Luna sees clean file names."""
    tb = re.sub(r'File "/tmp/[^"]+/', 'File "<luna_sandbox>/', tb)
    tb = re.sub(r'File "/var/folders/[^"]+/', 'File "<luna_sandbox>/', tb)
    return tb.strip()


def _extract_exception_type(stderr: str) -> Optional[str]:
    """Parse 'TypeError: ...' from the last line of a traceback."""
    match = re.search(r"^(\w+(?:Error|Exception|Warning))\s*:", stderr, re.MULTILINE)
    return match.group(1) if match else None


def _truncate(s: str, max_chars: int = SANDBOX_MAX_OUTPUT) -> str:
    if len(s) <= max_chars:
        return s
    half = max_chars // 2
    return s[:half] + f"\n\n[… {len(s) - max_chars} chars truncated …]\n\n" + s[-half:]


# ══════════════════════════════════════════════════════════════════════════════
# BACKEND: SUBPROCESS
# ══════════════════════════════════════════════════════════════════════════════

async def _run_subprocess(language: str, code: str) -> CodeResult:
    """
    Runs code in an isolated subprocess inside a fresh tempdir.
    The process:
      - Gets its own tempdir as cwd (deleted after)
      - Has no write access outside the tempdir
      - Is killed after SANDBOX_TIMEOUT_SEC seconds
      - Gets no DISPLAY, limited PATH
    """
    cmd = SANDBOX_LANGUAGES.get(language)
    if not cmd:
        return CodeResult(
            success=False, stdout="", stderr=f"Language '{language}' not supported.",
            exit_code=1, runtime_ms=0, language=language, backend="subprocess",
        )

    with tempfile.TemporaryDirectory(prefix="luna_sandbox_") as tmpdir:
        env = {
            "PATH":       "/usr/local/bin:/usr/bin:/bin",
            "HOME":       tmpdir,
            "TMPDIR":     tmpdir,
            "PYTHONPATH": "",
            "LANG":       "en_US.UTF-8",
        }

        t_start = time.perf_counter()
        timed_out = False

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdin  = asyncio.subprocess.PIPE,
                stdout = asyncio.subprocess.PIPE,
                stderr = asyncio.subprocess.PIPE,
                cwd    = tmpdir,
                env    = env,
            )
            try:
                stdout_b, stderr_b = await asyncio.wait_for(
                    proc.communicate(input=code.encode()),
                    timeout=SANDBOX_TIMEOUT_SEC,
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.communicate()
                timed_out = True
                stdout_b, stderr_b = b"", b"Process killed after timeout."

        except FileNotFoundError:
            return CodeResult(
                success=False, stdout="",
                stderr=f"Interpreter not found: `{cmd[0]}`. Install it or switch SANDBOX_BACKEND.",
                exit_code=127, runtime_ms=0, language=language, backend="subprocess",
            )

        runtime_ms = (time.perf_counter() - t_start) * 1000
        stdout = _truncate(stdout_b.decode("utf-8", errors="replace"))
        stderr = _truncate(stderr_b.decode("utf-8", errors="replace"))
        exit_code = proc.returncode or (124 if timed_out else 0)

        tb = _clean_traceback(stderr) if "Traceback" in stderr else None
        exc = _extract_exception_type(stderr)

        return CodeResult(
            success      = exit_code == 0 and not timed_out,
            stdout       = stdout,
            stderr       = stderr,
            exit_code    = exit_code,
            runtime_ms   = runtime_ms,
            language     = language,
            backend      = "subprocess",
            timed_out    = timed_out,
            traceback    = tb,
            exception_type = exc,
        )


# ══════════════════════════════════════════════════════════════════════════════
# BACKEND: DOCKER
# ══════════════════════════════════════════════════════════════════════════════

async def _run_docker(language: str, code: str) -> CodeResult:
    """
    Runs code inside the luna-sandbox Docker container.
    Container has no network, no volume mounts, 256 MB RAM limit, 1 CPU.
    """
    if not shutil.which("docker"):
        # Fall back gracefully
        print("[Sandbox] Docker not found, falling back to subprocess.")
        return await _run_subprocess(language, code)

    cmd_in_container = SANDBOX_LANGUAGES.get(language, ["python3", "-u", "-"])
    docker_cmd = [
        "docker", "run",
        "--rm",
        "--network=none",          # NO internet access
        "--memory=256m",           # 256 MB RAM cap
        "--cpus=1",
        "--pids-limit=64",         # prevent fork bombs
        "--ulimit", "nofile=64:64",
        "--security-opt=no-new-privileges",
        "--read-only",             # container filesystem is read-only
        "--tmpfs", "/tmp:size=32m",  # writable /tmp only
        "-i",
        DOCKER_IMAGE,
        *cmd_in_container,
    ]

    t_start   = time.perf_counter()
    timed_out = False

    try:
        proc = await asyncio.create_subprocess_exec(
            *docker_cmd,
            stdin  = asyncio.subprocess.PIPE,
            stdout = asyncio.subprocess.PIPE,
            stderr = asyncio.subprocess.PIPE,
        )
        try:
            stdout_b, stderr_b = await asyncio.wait_for(
                proc.communicate(input=code.encode()),
                timeout=SANDBOX_TIMEOUT_SEC + 5,  # extra 5s for container spin-up
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            timed_out = True
            stdout_b, stderr_b = b"", b"Docker container killed after timeout."

    except Exception as e:
        return CodeResult(
            success=False, stdout="", stderr=str(e),
            exit_code=1, runtime_ms=0, language=language, backend="docker",
        )

    runtime_ms = (time.perf_counter() - t_start) * 1000
    stdout = _truncate(stdout_b.decode("utf-8", errors="replace"))
    stderr = _truncate(stderr_b.decode("utf-8", errors="replace"))
    exit_code = proc.returncode or (124 if timed_out else 0)
    tb  = _clean_traceback(stderr) if "Traceback" in stderr else None
    exc = _extract_exception_type(stderr)

    return CodeResult(
        success        = exit_code == 0 and not timed_out,
        stdout         = stdout,
        stderr         = stderr,
        exit_code      = exit_code,
        runtime_ms     = runtime_ms,
        language       = language,
        backend        = "docker",
        timed_out      = timed_out,
        traceback      = tb,
        exception_type = exc,
    )


# ══════════════════════════════════════════════════════════════════════════════
# BACKEND: E2B (managed cloud sandbox)
# ══════════════════════════════════════════════════════════════════════════════

async def _run_e2b(language: str, code: str) -> CodeResult:
    """
    Executes code in a managed E2B sandbox (https://e2b.dev).
    Fully isolated, no local setup beyond pip install e2b.
    """
    try:
        from e2b_code_interpreter import CodeInterpreter  # type: ignore
    except ImportError:
        return CodeResult(
            success=False, stdout="",
            stderr="e2b not installed. pip install e2b-code-interpreter",
            exit_code=1, runtime_ms=0, language=language, backend="e2b",
        )

    if not E2B_API_KEY:
        return CodeResult(
            success=False, stdout="",
            stderr="E2B_API_KEY not set in .env",
            exit_code=1, runtime_ms=0, language=language, backend="e2b",
        )

    t_start = time.perf_counter()
    try:
        async with CodeInterpreter(api_key=E2B_API_KEY) as sandbox:
            result = await asyncio.to_thread(sandbox.notebook.exec_cell, code)
        runtime_ms = (time.perf_counter() - t_start) * 1000

        stdout = _truncate("\n".join(str(o) for o in (result.logs.stdout or [])))
        stderr = _truncate("\n".join(str(e) for e in (result.logs.stderr or [])))
        err    = result.error
        success = err is None

        return CodeResult(
            success        = success,
            stdout         = stdout,
            stderr         = stderr + (f"\n{err.name}: {err.value}" if err else ""),
            exit_code      = 0 if success else 1,
            runtime_ms     = runtime_ms,
            language       = language,
            backend        = "e2b",
            traceback      = _clean_traceback(err.traceback) if err and err.traceback else None,
            exception_type = err.name if err else None,
        )
    except Exception as exc:
        return CodeResult(
            success=False, stdout="", stderr=str(exc),
            exit_code=1, runtime_ms=(time.perf_counter() - t_start) * 1000,
            language=language, backend="e2b",
        )


# ══════════════════════════════════════════════════════════════════════════════
# DOCKERFILE GENERATOR
# ══════════════════════════════════════════════════════════════════════════════

DOCKERFILE_CONTENT = """
# Luna Sandbox — minimal, hardened Python execution environment
FROM python:3.12-slim

# Install node for JS support
RUN apt-get update && apt-get install -y --no-install-recommends \\
    nodejs npm bash \\
    && rm -rf /var/lib/apt/lists/*

# Install common Python packages Luna might need in sandbox
RUN pip install --no-cache-dir numpy pandas requests pytest

# Create non-root user for code execution
RUN useradd -m -u 1000 sandbox
USER sandbox
WORKDIR /home/sandbox

# Stdin is the code — stdout/stderr are captured
ENTRYPOINT []
""".strip()


def generate_dockerfile(output_dir: Path = None) -> Path:
    """Write the Dockerfile for the Luna sandbox image."""
    target = output_dir or Path.cwd()
    df_path = target / "Dockerfile.luna-sandbox"
    df_path.write_text(DOCKERFILE_CONTENT)
    print(f"[Sandbox] Dockerfile written to: {df_path}")
    print(f"[Sandbox] Build with: docker build -f {df_path} -t luna-sandbox:latest .")
    return df_path


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC API
# ══════════════════════════════════════════════════════════════════════════════

async def run_code(language: str, code: str, backend: str = None) -> CodeResult:
    """
    Luna's primary tool for executing code.

    Args:
        language: "python" | "javascript" | "bash" | "typescript"
        code:     The source code to run (as a string)
        backend:  Override SANDBOX_BACKEND from config. None = use config default.

    Returns:
        CodeResult with stdout, stderr, traceback, success flag, runtime.
    """
    language = language.lower().strip()
    backend  = (backend or SANDBOX_BACKEND).lower()

    # ── Validate ──────────────────────────────────────────────────────────────
    if language not in SANDBOX_LANGUAGES:
        return CodeResult(
            success=False, stdout="",
            stderr=f"Unsupported language: '{language}'. Use: {list(SANDBOX_LANGUAGES.keys())}",
            exit_code=1, runtime_ms=0, language=language, backend=backend,
        )

    block_reason = _validate_code(code)
    if block_reason:
        return CodeResult(
            success=False, stdout="",
            stderr=f"🛑 Code blocked by Luna safety filter: {block_reason}",
            exit_code=1, runtime_ms=0, language=language, backend=backend,
        )

    # ── Dispatch ──────────────────────────────────────────────────────────────
    print(f"[Sandbox] Running {language} ({len(code)} chars) via {backend}...")

    if backend == "docker":
        result = await _run_docker(language, code)
    elif backend == "e2b":
        result = await _run_e2b(language, code)
    else:
        result = await _run_subprocess(language, code)

    status = "✓" if result.success else "✗"
    print(f"[Sandbox] {status} exit={result.exit_code} time={result.runtime_ms:.0f}ms")
    return result


def run_code_sync(language: str, code: str, backend: str = None) -> CodeResult:
    """Synchronous wrapper for contexts that can't await."""
    return asyncio.get_event_loop().run_until_complete(
        run_code(language, code, backend)
    )
