"""
Luna Core v1.0 — Feedback Loop
════════════════════════════════════════════════════════════════════════════════

Three ways to give Luna feedback on her responses:

  1. DISCORD REACTIONS  — React with 💜/👍/👎/😭 on any Luna message.
                          Instant, no typing required. Works from iPhone.

  2. VOICE COMMAND      — Say "Luna that was [great/funny/too long/etc]" in VC.
                          Luna hears it, tags the last response, thanks you.

  3. DISCORD COMMAND    — `!tag funny` `!tag too_long` `!dislike` `!loved`
                          More precise, any device, any time after the fact.

All three paths converge at luna_logger.apply_feedback(), which:
  → Stores the sentiment in the decision chain
  → Feeds learning back into the MemoryEngine
  → Broadcasts the event to the live dashboard

════════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import asyncio
import re
from typing import Optional

import discord
from discord.ext import commands

import luna_logger as logger
from memory_engine import MemoryEngine


# ══════════════════════════════════════════════════════════════════════════════
# REACTION MAP
# Emoji → sentiment label
# ══════════════════════════════════════════════════════════════════════════════

REACTION_SENTIMENT: dict[str, str] = {
    "💜": "loved",       # heart  → loved
    "❤️": "loved",       # heart  → loved
    "😍": "loved",       # heart eyes → loved
    "👍": "liked",       # thumbs up  → liked
    "✅": "liked",       # check  → liked
    "😄": "liked",       # smile  → liked
    "😂": "liked",       # laughing → liked (humor hit)
    "💀": "liked",       # skull (dead from laughing) → liked
    "😐": "neutral",     # meh → neutral
    "🤔": "neutral",     # thinking → neutral (flag for review)
    "👎": "disliked",    # thumbs down → disliked
    "😒": "disliked",    # unamused → disliked
    "😭": "hated",       # crying → hated
    "🤖": "hated",       # robot → "too robotic" flag
    "💤": "hated",       # sleeping → "too boring/long"
}

# Emoji → auto-tags (in addition to the sentiment)
REACTION_AUTO_TAGS: dict[str, list[str]] = {
    "😂": ["funny"],
    "💀": ["funny", "dark_humor"],
    "🤖": ["too_robotic", "no_personality"],
    "💤": ["too_long", "boring"],
    "🤔": ["confusing", "needs_clarification"],
    "😍": ["warm", "perfect_tone"],
}


# ══════════════════════════════════════════════════════════════════════════════
# VOICE COMMAND PATTERNS
# Natural language → sentiment + tags
# ══════════════════════════════════════════════════════════════════════════════

VOICE_FEEDBACK_PATTERNS: list[tuple[list[str], str, list[str]]] = [
    # (trigger phrases, sentiment, auto_tags)
    (["that was perfect", "that was amazing", "i love that", "love that"],
     "loved", ["perfect"]),

    (["that was great", "that was good", "nice one", "good answer", "well done"],
     "liked", ["helpful"]),

    (["that was funny", "you're funny", "haha", "lol", "made me laugh"],
     "liked", ["funny"]),

    (["that was helpful", "very helpful", "exactly what i needed"],
     "liked", ["helpful", "accurate"]),

    (["that was okay", "it was fine", "alright"],
     "neutral", []),

    (["too long", "too much", "shorten that", "keep it shorter"],
     "disliked", ["too_long"]),

    (["too robotic", "sounds robotic", "be more natural", "that was stiff"],
     "disliked", ["too_robotic"]),

    (["boring", "that was boring", "put me to sleep"],
     "disliked", ["boring"]),

    (["wrong", "that's wrong", "incorrect", "that's incorrect"],
     "disliked", ["incorrect"]),

    (["i hated that", "terrible", "awful", "the worst"],
     "hated", ["negative"]),
]

def parse_voice_feedback(text: str) -> Optional[tuple[str, list[str]]]:
    """
    Parse a voice command for feedback intent.
    Returns (sentiment, tags) or None if no feedback detected.
    """
    lower = text.lower().strip()
    # Strip wake word if present
    for wake in ["luna", "hey luna", "hej luna"]:
        if lower.startswith(wake):
            lower = lower[len(wake):].strip(" ,.")

    for triggers, sentiment, tags in VOICE_FEEDBACK_PATTERNS:
        if any(trigger in lower for trigger in triggers):
            # Parse extra tags from the text
            extra_tags = _extract_inline_tags(lower)
            return sentiment, list(set(tags + extra_tags))

    return None

def _extract_inline_tags(text: str) -> list[str]:
    """Pull free-form tag words from text like 'tag this as funny and too long'"""
    tag_match = re.search(r"tag (?:this |it )?(?:as )?(.+)", text)
    if tag_match:
        raw = tag_match.group(1)
        # Split on commas, "and", spaces
        words = re.split(r"[,\s]+(?:and\s+)?", raw)
        return [w.strip().lower().replace(" ", "_") for w in words if w.strip()]
    return []


# ══════════════════════════════════════════════════════════════════════════════
# SESSION TRACKER
# Keeps a rolling window of "which chain_id belongs to which Discord message"
# so reactions map back to the right decision chain.
# ══════════════════════════════════════════════════════════════════════════════

class SessionTracker:
    """
    Maps Discord message IDs → Luna decision chain IDs.
    Holds the last 50 messages per guild (auto-evicts old ones).
    """

    MAX_HISTORY = 50

    def __init__(self):
        # guild_id → deque of (message_id, chain_id)
        self._map: dict[int, list[tuple[int, str]]] = {}

    def register(self, guild_id: int, message_id: int, chain_id: str):
        history = self._map.setdefault(guild_id, [])
        history.append((message_id, chain_id))
        if len(history) > self.MAX_HISTORY:
            history.pop(0)

    def lookup(self, guild_id: int, message_id: int) -> Optional[str]:
        for mid, cid in reversed(self._map.get(guild_id, [])):
            if mid == message_id:
                return cid
        return None

    def latest(self, guild_id: int) -> Optional[str]:
        """Return the chain_id of the most recent Luna message in this guild."""
        history = self._map.get(guild_id, [])
        return history[-1][1] if history else None


# ══════════════════════════════════════════════════════════════════════════════
# FEEDBACK COG — plugs into the discord bot
# ══════════════════════════════════════════════════════════════════════════════

class FeedbackCog(commands.Cog):
    """
    Discord Cog that handles all feedback collection.
    Add to the LunaBot with: await bot.add_cog(FeedbackCog(bot, memory_engine, tracker))
    """

    def __init__(self, bot: commands.Bot, memory: MemoryEngine, tracker: SessionTracker):
        self.bot     = bot
        self.memory  = memory
        self.tracker = tracker

    # ── Reaction handler ──────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent):
        """Handle emoji reactions on any message."""
        # Ignore bot reactions
        if payload.user_id == self.bot.user.id:
            return

        emoji_str = str(payload.emoji)
        sentiment = REACTION_SENTIMENT.get(emoji_str)
        if not sentiment:
            return  # not a feedback emoji

        # Look up which chain this message belongs to
        chain_id = self.tracker.lookup(payload.guild_id or 0, payload.message_id)
        if not chain_id:
            return  # message wasn't from Luna (or too old)

        auto_tags = REACTION_AUTO_TAGS.get(emoji_str, [])

        updated = logger.apply_feedback(
            chain_id      = chain_id,
            sentiment     = sentiment,
            tags          = auto_tags,
            source        = "reaction",
            raw           = emoji_str,
            memory_engine = self.memory,
        )

        if updated:
            # Send a brief acknowledgment in the same channel
            channel = self.bot.get_channel(payload.channel_id)
            if channel:
                ack = self._ack_message(sentiment, auto_tags)
                msg = await channel.send(ack)
                # Auto-delete the ack after 4s to avoid clutter
                await asyncio.sleep(4)
                try:
                    await msg.delete()
                except discord.HTTPException:
                    pass

    def _ack_message(self, sentiment: str, tags: list[str]) -> str:
        acks = {
            "loved":    "💜 noted — I'll keep doing more of that.",
            "liked":    "👍 got it, glad that landed.",
            "neutral":  "🤔 okay, filing that away.",
            "disliked": "👎 duly noted. I'll adjust.",
            "hated":    "😬 yikes, message received. won't do that again.",
        }
        base = acks.get(sentiment, "✅ feedback recorded.")
        if tags:
            base += f" *(tagged: {', '.join(tags)})*"
        return base

    # ── Discord commands ──────────────────────────────────────────────────────

    @commands.command(name="loved")
    async def cmd_loved(self, ctx: commands.Context):
        """Tag last response as loved. !loved"""
        await self._apply_cmd_feedback(ctx, "loved", [])

    @commands.command(name="liked")
    async def cmd_liked(self, ctx: commands.Context):
        """Tag last response as liked. !liked"""
        await self._apply_cmd_feedback(ctx, "liked", [])

    @commands.command(name="dislike")
    async def cmd_dislike(self, ctx: commands.Context, *, reason: str = ""):
        """Tag last response as disliked. !dislike too_long"""
        tags = reason.replace(",", " ").split() if reason else []
        await self._apply_cmd_feedback(ctx, "disliked", tags)

    @commands.command(name="tag")
    async def cmd_tag(self, ctx: commands.Context, *tags: str):
        """Add tags to last response. !tag funny helpful"""
        chain_id = self.tracker.latest(ctx.guild.id if ctx.guild else 0)
        if not chain_id:
            return await ctx.reply("😕 Nothing to tag yet.")
        chain = logger.apply_feedback(
            chain_id      = chain_id,
            sentiment     = "neutral",
            tags          = list(tags),
            source        = "discord_cmd",
            raw           = f"!tag {' '.join(tags)}",
            memory_engine = self.memory,
        )
        await ctx.reply(f"🏷️ Tagged: `{', '.join(tags)}`")

    @commands.command(name="feedback")
    async def cmd_feedback(self, ctx: commands.Context, sentiment: str, *tags: str):
        """Full feedback command. !feedback loved funny warm"""
        valid = {"loved", "liked", "neutral", "disliked", "hated"}
        if sentiment not in valid:
            return await ctx.reply(f"❌ Sentiment must be one of: {', '.join(valid)}")
        await self._apply_cmd_feedback(ctx, sentiment, list(tags))

    async def _apply_cmd_feedback(
        self,
        ctx:       commands.Context,
        sentiment: str,
        tags:      list[str],
    ):
        guild_id = ctx.guild.id if ctx.guild else 0
        chain_id = self.tracker.latest(guild_id)
        if not chain_id:
            return await ctx.reply("😕 No recent response to rate.")

        logger.apply_feedback(
            chain_id      = chain_id,
            sentiment     = sentiment,
            tags          = tags,
            source        = "discord_cmd",
            raw           = ctx.message.content,
            memory_engine = self.memory,
        )
        acks = {
            "loved":    "💜 amazing, I'll lean into that.",
            "liked":    "👍 glad it landed.",
            "neutral":  "🤔 noted.",
            "disliked": "👎 I hear you. adjusting.",
            "hated":    "😬 really noted. won't happen again.",
        }
        reply = acks.get(sentiment, "✅ recorded.")
        if tags:
            reply += f" *(tags: {', '.join(tags)})*"
        await ctx.reply(reply)

    # ── Voice feedback parser (called by bot when VC message is detected) ──────

    async def handle_voice_feedback(
        self,
        text:     str,
        guild_id: int,
        channel:  Optional[discord.TextChannel] = None,
    ) -> bool:
        """
        Called by the Discord bot whenever a voice message is transcribed.
        Returns True if feedback was detected and processed.
        """
        result = parse_voice_feedback(text)
        if not result:
            return False

        sentiment, tags = result
        chain_id = self.tracker.latest(guild_id)
        if not chain_id:
            return False

        logger.apply_feedback(
            chain_id      = chain_id,
            sentiment     = sentiment,
            tags          = tags,
            source        = "voice_cmd",
            raw           = text,
            memory_engine = self.memory,
        )

        # Confirm in text channel if available
        if channel:
            ack = self._ack_message(sentiment, tags)
            msg = await channel.send(ack)
            await asyncio.sleep(4)
            try:
                await msg.delete()
            except discord.HTTPException:
                pass

        return True
