"""
Luna Core v1.0 — Discord Bot
Full discord.py bot with:
  • Slash commands + prefix commands
  • Voice channel join/leave
  • "Hej Luna fix the bug" natural language command listener
  • Mobile-friendly: send from iPhone, runs on home PC
  • Streaming text + TTS responses
  • Code analysis loop trigger from any device
"""

import asyncio
import re
import time
from typing import Optional

import discord
from discord.ext import commands, tasks

from config import (
    DISCORD_TOKEN, DISCORD_GUILD_ID, DISCORD_PREFIX,
    WAKE_WORDS, COMMAND_KEYWORDS, LUNA_PERSONA,
)
from memory_engine import MemoryEngine, extract_memories_from_conversation
from context_packer import ContextPacker
from llm_router import LunaLLMRouter, classify_intent
from voice_handler import VoiceHandler


# ── Intents ───────────────────────────────────────────────────────────────────

intents                      = discord.Intents.default()
intents.message_content      = True   # required for prefix commands
intents.voice_states         = True   # required for voice channel tracking
intents.guilds               = True


# ── Bot Setup ─────────────────────────────────────────────────────────────────

class LunaBot(commands.Bot):

    def __init__(self):
        super().__init__(
            command_prefix = DISCORD_PREFIX,
            intents        = intents,
            help_command   = None,      # custom help
        )
        # Core services
        self.memory     = MemoryEngine()
        self.packer     = ContextPacker()
        self.router:    Optional[LunaLLMRouter] = None
        self.voice_hdlr = VoiceHandler()

        # State
        self.analysis_in_progress = False
        self.startup_time         = time.time()

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    async def setup_hook(self):
        """Called once before the bot connects. Initialize heavy services."""
        print("[Luna] Initializing LLM router (packing repo + priming Gemini cache)...")
        self.router = await LunaLLMRouter(self.memory, self.packer).initialize()
        print("[Luna] Bot ready.")

    async def on_ready(self):
        print(f"[Luna] Logged in as {self.user} (id={self.user.id})")
        print(f"[Luna] Serving guild: {DISCORD_GUILD_ID}")
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="your codebase 👁️"
            )
        )

    async def on_message(self, message: discord.Message):
        if message.author.bot:
            return

        # Check for wake word
        lower = message.content.lower().strip()
        detected_wake = any(lower.startswith(w) for w in WAKE_WORDS)

        if detected_wake:
            await self._handle_luna_command(message)
        else:
            # Normal prefix command processing
            await self.process_commands(message)

    # ── Wake Word Handler ─────────────────────────────────────────────────────

    async def _handle_luna_command(self, message: discord.Message):
        """
        Parse natural language Luna commands.
        "Hej Luna fix the bug in auth.py"
        "Hey Luna review my last commit"
        "Luna what's the weather"  (→ chat)
        """
        raw      = message.content.strip()
        # Strip wake word prefix
        for wake in WAKE_WORDS:
            if raw.lower().startswith(wake):
                raw = raw[len(wake):].strip(" ,.")
                break

        if not raw:
            raw = "Hey, what can you help me with right now?"

        # Detect command intent
        cmd_type  = self._parse_command(raw)
        guild_id  = message.guild.id if message.guild else 0

        print(f"[Bot] Wake word → cmd={cmd_type} | msg='{raw}'")

        async with message.channel.typing():

            if cmd_type == "code_fix":
                await self._run_code_loop(message, task=raw, task_type="fix")

            elif cmd_type in ("code_analyze", "code_review", "code_explain"):
                await self._run_code_loop(message, task=raw, task_type=cmd_type)

            else:
                # General chat
                await self._stream_response(message, raw, engine="ollama")

    def _parse_command(self, text: str) -> str:
        lower = text.lower()
        for keyword, cmd in COMMAND_KEYWORDS.items():
            if keyword in lower:
                return cmd
        return "chat"

    # ── Code Analysis Loop ────────────────────────────────────────────────────

    async def _run_code_loop(
        self,
        message: discord.Message,
        task: str,
        task_type: str = "analyze",
    ):
        """
        The main code intelligence loop.
        1. Re-pack repo (detects changes since last run)
        2. Refresh Gemini cache if needed
        3. Stream analysis response
        4. Speak result in VC if connected
        """
        if self.analysis_in_progress:
            await message.reply("⏳ Analysis already running — hold on.")
            return

        self.analysis_in_progress = True

        try:
            # Status indicator
            status_msg = await message.reply(
                f"🔍 **Luna Code Loop** — `{task_type}` mode\n"
                f"📦 Re-packing repo...",
                mention_author=False,
            )

            # Force re-pack to pick up any file changes
            self.packer.invalidate()
            await status_msg.edit(
                content = f"🔍 **Luna Code Loop** — `{task_type}` mode\n"
                          f"🧠 Querying Gemini with full context..."
            )

            full_response = await self._collect_response(task, engine="gemini")

            await status_msg.delete()

            # Split long responses into Discord chunks (2000 char limit)
            chunks = self._split_for_discord(full_response)
            for i, chunk in enumerate(chunks):
                await message.channel.send(
                    f"{'**[Luna Analysis]**' if i == 0 else ''}\n{chunk}"
                )

            # If user is in a VC, also speak the response
            if message.author.voice:
                vc_channel = message.author.voice.channel
                vc = await self.voice_hdlr.join_channel(vc_channel, message.guild.id)
                # Speak a condensed version
                brief = full_response[:500] + ("..." if len(full_response) > 500 else "")
                await self.voice_hdlr.speak(vc, brief)

            # Extract and store any memories from this interaction
            extract_memories_from_conversation(self.memory, task, full_response)

        except Exception as e:
            await message.reply(f"❌ Analysis error: `{e}`")
            print(f"[Bot] Code loop error: {e}")
        finally:
            self.analysis_in_progress = False

    # ── Response Streaming ────────────────────────────────────────────────────

    async def _stream_response(
        self,
        message: discord.Message,
        prompt: str,
        engine: str = None,
    ):
        """Stream response tokens into a Discord message (edit-as-you-go)."""
        reply      = await message.reply("💭 ...", mention_author=False)
        buffer     = ""
        last_edit  = 0
        EDIT_RATE  = 1.0    # seconds between edits (avoid rate limits)

        async for chunk in self.router.respond(prompt, force_engine=engine):
            buffer    += chunk
            now        = asyncio.get_event_loop().time()

            if now - last_edit > EDIT_RATE and buffer.strip():
                try:
                    preview = buffer[:1990] + ("…" if len(buffer) > 1990 else "")
                    await reply.edit(content=preview)
                    last_edit = now
                except discord.HTTPException:
                    pass

        # Final edit with full response
        if len(buffer) <= 2000:
            await reply.edit(content=buffer or "*(no response)*")
        else:
            await reply.edit(content=buffer[:1997] + "…")
            for chunk in self._split_for_discord(buffer[2000:]):
                await message.channel.send(chunk)

        extract_memories_from_conversation(self.memory, prompt, buffer)

    async def _collect_response(self, prompt: str, engine: str = None) -> str:
        chunks = []
        async for c in self.router.respond(prompt, force_engine=engine):
            chunks.append(c)
        return "".join(chunks)

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _split_for_discord(text: str, limit: int = 1990) -> list[str]:
        chunks, current = [], ""
        for line in text.splitlines(keepends=True):
            if len(current) + len(line) > limit:
                chunks.append(current)
                current = ""
            current += line
        if current:
            chunks.append(current)
        return chunks or ["*(empty)*"]


# ── Commands ──────────────────────────────────────────────────────────────────

bot = LunaBot()


@bot.command(name="join")
async def cmd_join(ctx: commands.Context):
    """Join your current voice channel."""
    if not ctx.author.voice:
        return await ctx.reply("❌ You're not in a voice channel.")
    vc = await bot.voice_hdlr.join_channel(ctx.author.voice.channel, ctx.guild.id)
    await ctx.reply(f"🎙️ Joined **{vc.channel.name}**")


@bot.command(name="leave")
async def cmd_leave(ctx: commands.Context):
    """Leave the voice channel."""
    await bot.voice_hdlr.leave_channel(ctx.guild.id)
    await ctx.reply("👋 Left the voice channel.")


@bot.command(name="analyze", aliases=["analyse"])
async def cmd_analyze(ctx: commands.Context, *, query: str = ""):
    """Run a full repo analysis. Usage: !analyze why is auth.py slow"""
    task = query or "Give me a full health report on this codebase."
    await bot._run_code_loop(ctx.message, task=task, task_type="code_analyze")


@bot.command(name="fix")
async def cmd_fix(ctx: commands.Context, *, query: str = ""):
    """Ask Luna to find and fix a bug. Usage: !fix the null pointer in db.py"""
    task = query or "Find and explain the most critical bug in the codebase."
    await bot._run_code_loop(ctx.message, task=task, task_type="code_fix")


@bot.command(name="review")
async def cmd_review(ctx: commands.Context, filename: str = "", *, task: str = ""):
    """Review a specific file. Usage: !review auth.py check for security issues"""
    if filename:
        prompt = f"Review the file `{filename}`. {task or 'Look for bugs, smells, and improvements.'}"
    else:
        prompt = task or "Do a general code review of the most important files."
    await bot._run_code_loop(ctx.message, task=prompt, task_type="code_review")


@bot.command(name="chat")
async def cmd_chat(ctx: commands.Context, *, message: str):
    """Chat with Luna directly. Usage: !chat how's the architecture looking?"""
    await bot._stream_response(ctx.message, message, engine="ollama")


@bot.command(name="memory")
async def cmd_memory(ctx: commands.Context, *, fact: str = ""):
    """Show or add a memory. Usage: !memory I prefer type hints everywhere"""
    if fact:
        mem = bot.memory.remember_preference(fact, importance=0.75)
        await ctx.reply(f"✅ Remembered: `{fact}` (id: `{mem.id}`)")
    else:
        stats = bot.memory.stats()
        lines = [f"**Luna's Memory** ({sum(v['count'] for v in stats.values())} facts)"]
        for cat, data in stats.items():
            lines.append(f"  `{cat}`: {data['count']} facts (avg imp: {data['avg_importance']})")
        await ctx.reply("\n".join(lines))


@bot.command(name="status")
async def cmd_status(ctx: commands.Context):
    """System status."""
    uptime  = int(time.time() - bot.startup_time)
    h, m, s = uptime // 3600, (uptime % 3600) // 60, uptime % 60
    summary = bot.packer.summary()
    stats   = bot.memory.stats()
    total_m = sum(v["count"] for v in stats.values())
    vc_conn = bot.voice_hdlr.is_connected(ctx.guild.id)

    await ctx.reply(
        f"**🌙 Luna Core v1.0 — Status**\n"
        f"⏱️ Uptime: `{h:02d}:{m:02d}:{s:02d}`\n"
        f"🧠 Memories: `{total_m}` facts\n"
        f"🎙️ Voice: `{'connected' if vc_conn else 'disconnected'}`\n"
        f"```\n{summary}\n```"
    )


@bot.command(name="help")
async def cmd_help(ctx: commands.Context):
    await ctx.reply(
        "**🌙 Luna Commands**\n\n"
        "**Natural Language** (mobile-friendly):\n"
        "  `Hej Luna fix the bug in auth.py`\n"
        "  `Hey Luna review my latest changes`\n"
        "  `Luna what does the db module do`\n\n"
        "**Prefix Commands**:\n"
        "  `!analyze [query]` — Full codebase analysis\n"
        "  `!fix [description]` — Bug hunt + fix suggestions\n"
        "  `!review [file] [task]` — Code review\n"
        "  `!chat [message]` — Casual chat (local, instant)\n"
        "  `!memory [fact]` — View or add a memory\n"
        "  `!join / !leave` — Voice channel\n"
        "  `!status` — System status\n"
    )


# ── Entry Point ───────────────────────────────────────────────────────────────

def run():
    if not DISCORD_TOKEN:
        raise ValueError("DISCORD_TOKEN is not set in .env")
    bot.run(DISCORD_TOKEN, log_handler=None)


if __name__ == "__main__":
    run()
