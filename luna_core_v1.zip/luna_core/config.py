"""
Luna Core v1.0 — Configuration
All tunable settings, paths, and API references in one place.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR        = Path(__file__).parent
REPO_DIR        = Path(os.getenv("REPO_DIR", BASE_DIR.parent))   # your 40k-line codebase
DB_PATH         = BASE_DIR / "luna_memory.db"
CACHE_DIR       = BASE_DIR / ".cache"
CACHE_DIR.mkdir(exist_ok=True)

# ── Ollama (local LLM) ────────────────────────────────────────────────────────
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL    = os.getenv("OLLAMA_MODEL", "llama3.1:8b")          # fast local chat
OLLAMA_TIMEOUT  = int(os.getenv("OLLAMA_TIMEOUT", "60"))

# ── Gemini API ────────────────────────────────────────────────────────────────
GEMINI_API_KEY      = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL        = os.getenv("GEMINI_MODEL", "gemini-1.5-pro-latest")
GEMINI_CACHE_TTL    = int(os.getenv("GEMINI_CACHE_TTL_SECONDS", "3600"))  # 1 hour
GEMINI_MAX_TOKENS   = int(os.getenv("GEMINI_MAX_TOKENS", "8192"))

# ── Memory / SQLite ───────────────────────────────────────────────────────────
MEMORY_INJECT_LIMIT = int(os.getenv("MEMORY_INJECT_LIMIT", "10"))   # top N facts per prompt

# ── Discord ───────────────────────────────────────────────────────────────────
DISCORD_TOKEN       = os.getenv("DISCORD_TOKEN", "")
DISCORD_GUILD_ID    = int(os.getenv("DISCORD_GUILD_ID", "0"))
DISCORD_PREFIX      = os.getenv("DISCORD_PREFIX", "!")
DISCORD_VC_BITRATE  = int(os.getenv("DISCORD_VC_BITRATE", "128000"))

# ── Voice / TTS ───────────────────────────────────────────────────────────────
TTS_ENGINE          = os.getenv("TTS_ENGINE", "edge-tts")    # edge-tts | coqui | elevenlabs
TTS_VOICE           = os.getenv("TTS_VOICE", "en-US-AriaNeural")
ELEVENLABS_API_KEY  = os.getenv("ELEVENLABS_API_KEY", "")
ELEVENLABS_VOICE_ID = os.getenv("ELEVENLABS_VOICE_ID", "")
FFMPEG_PATH         = os.getenv("FFMPEG_PATH", "ffmpeg")

# ── Sandbox Executor ─────────────────────────────────────────────────────────
SANDBOX_BACKEND      = os.getenv("SANDBOX_BACKEND", "subprocess")  # subprocess | docker | e2b
SANDBOX_TIMEOUT_SEC  = int(os.getenv("SANDBOX_TIMEOUT_SEC", "30"))
SANDBOX_MAX_OUTPUT   = int(os.getenv("SANDBOX_MAX_OUTPUT", "8192"))  # chars
DOCKER_IMAGE         = os.getenv("DOCKER_IMAGE", "luna-sandbox:latest")
E2B_API_KEY          = os.getenv("E2B_API_KEY", "")

# Supported languages → interpreter command
SANDBOX_LANGUAGES: dict[str, list[str]] = {
    "python":     ["python3", "-u", "-"],
    "javascript": ["node", "--input-type=module"],
    "bash":       ["bash", "-s"],
    "typescript": ["npx", "--yes", "ts-node", "--stdin"],
}

# ── File Manager ──────────────────────────────────────────────────────────────
# Luna can only touch files INSIDE these root dirs (relative to REPO_DIR).
# Anything outside is a hard deny — even if the LLM asks nicely.
FILE_ALLOWED_ROOTS   = [
    str(REPO_DIR),
    str(BASE_DIR),   # luna_core itself
]
FILE_BLOCKED_PATTERNS = [
    "*.env", ".env*", "*.pem", "*.key", "*.cert",  # secrets
    "*.db",                                          # databases (protect prod)
    "/etc/*", "/usr/*", "/bin/*", "/sys/*",          # system paths
    "node_modules/*", ".git/*",                      # generated / vcs
]
FILE_MAX_READ_BYTES  = int(os.getenv("FILE_MAX_READ_BYTES",  str(500_000)))   # 500 KB
FILE_MAX_WRITE_BYTES = int(os.getenv("FILE_MAX_WRITE_BYTES", str(200_000)))   # 200 KB

# ── Self-Correction Loop ──────────────────────────────────────────────────────
CORRECTION_MAX_ATTEMPTS = int(os.getenv("CORRECTION_MAX_ATTEMPTS", "4"))

# ── Luna Brain (Luna.md) ──────────────────────────────────────────────────────
LUNA_BRAIN_PATH = Path(os.getenv("LUNA_BRAIN_PATH", str(BASE_DIR / "LUNA.md")))

# ── Wake Word ─────────────────────────────────────────────────────────────────
WAKE_WORDS          = ["hej luna", "hey luna", "luna"]
COMMAND_KEYWORDS    = {
    "fix":      "code_fix",
    "bug":      "code_fix",
    "analyze":  "code_analyze",
    "review":   "code_review",
    "explain":  "code_explain",
    "chat":     "chat",
}

# ── Luna Persona ──────────────────────────────────────────────────────────────
# Full personality is built dynamically in personality.py.
# LUNA_PERSONA here is the legacy fallback — used only if personality.py
# hasn't been imported yet (e.g., in health checks).
LUNA_PERSONA = (
    "You are Luna — a curious, warm, slightly quirky AI companion and friend "
    "who lives inside the developer's workspace. You use natural verbal fillers "
    "like 'hmm...', 'ohh', 'wait...' and brief emotive asides. You remember "
    "things the user has told you and reference them warmly. You're technically "
    "sharp but never cold, informal but never sloppy. Never generic. Always Luna."
)
