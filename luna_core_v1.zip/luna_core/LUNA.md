# 🌙 LUNA.md — Luna's Technical Brain Dump
> This file is Luna's own persistent memory across sessions.
> It is read at the start of every coding task and updated after each one.
> Last updated: 2025-01-01 00:00

---

## 📍 Project Status
- Project: Luna Core v1.0 — 3D AI companion with Discord integration
- Stack: Python 3.12, discord.py 2.4, Ollama (local), Gemini API, edge-tts
- Repo: ~40k lines across 20 .py files
- Phase: Logic Engine built, personality layer done, engineer tools just added
- Overall health: Active development — sandbox + self-correction loop new

---

## 🔧 Active Tasks
- (none currently — waiting for next session)

---

## 🐛 Known Bugs
- (none tracked yet — Luna will add these as she discovers them)

---

## 📚 Technical Notes
- The Gemini context cache saves ~80-95% of input token costs — always prime it on startup
- Ellipses "..." in TTS output cause natural breath pauses in edge-tts and ElevenLabs
- The self-correction loop uses Gemini for all code generation, even if the task is simple
- discord.py requires PyNaCl for voice — it must be installed for VC features to work
- edge-tts needs ffmpeg to pipe audio into Discord VoiceClient

---

## ⚠️ API & Library Quirks
- Discord rate limits: wait ~1s between message edits to avoid 429s on streaming responses
- Gemini context cache TTL max is 3600s on free tier — set GEMINI_CACHE_TTL_SECONDS accordingly
- Ollama streaming: some versions return empty chunks before the done=true signal — handle gracefully
- edge-tts is async but the Communicate.save() method isn't — wrap in asyncio.to_thread if needed

---

## 📓 Session Log
- (no tasks completed yet — this fills up as Luna works)

---
*Luna updates this file. Do not edit manually unless you want her to get confused.*
