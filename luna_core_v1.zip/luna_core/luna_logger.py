"""
Luna Core v1.0 — Decision Chain Logger
════════════════════════════════════════════════════════════════════════════════

Captures every stage of Luna's thought process as a structured event,
stores it in SQLite, and broadcasts it over WebSocket so the live
dashboard can show the chain in real time.

The 5 stages of every Luna response:
  ① INTENT     — raw input → classified intent → engine selected
  ② MEMORY     — query → memories found → injection block built
  ③ PERSONALITY — prompt variant selected → blocks assembled → token count
  ④ GENERATION  — LLM call → raw output → latency + token usage
  ⑤ VOICE       — TTS params → text cleaned → audio synthesized

Every stage event is:
  a) Written to SQLite (persists across restarts)
  b) Broadcast via WebSocket (live dashboard feed)
  c) Tagged with a session_id + chain_id so the full chain is reconstructable

════════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
import time
import uuid
import weakref
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

try:
    import websockets
    from websockets.server import WebSocketServerProtocol
    WS_AVAILABLE = True
except ImportError:
    WS_AVAILABLE = False
    print("[Logger] websockets not installed — dashboard feed disabled. pip install websockets")

from config import BASE_DIR

# ── Paths ─────────────────────────────────────────────────────────────────────
LOG_DB_PATH  = BASE_DIR / "luna_decisions.db"
WS_HOST      = "localhost"
WS_PORT      = 8765


# ══════════════════════════════════════════════════════════════════════════════
# DATA STRUCTURES
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class StageIntent:
    raw_input:        str
    classified_as:    str           # "chat" | "code" | "code_fix" | etc.
    engine_selected:  str           # "ollama" | "gemini"
    wake_word_used:   Optional[str] = None
    latency_ms:       float         = 0.0

@dataclass
class StageMemory:
    query:              str
    total_in_db:        int
    memories_found:     int
    memories_injected:  list[dict]  = field(default_factory=list)  # [{id, category, content, importance}]
    injection_tokens:   int         = 0

@dataclass
class StagePersonality:
    prompt_variant:     str         # "chat" | "code" | "voice" | "greeting"
    blocks_active:      list[str]   = field(default_factory=list)  # ["CORE_IDENTITY", "CURIOSITY", ...]
    voice_mode:         bool        = False
    code_mode:          bool        = False
    estimated_tokens:   int         = 0
    fillers_detected:   list[str]   = field(default_factory=list)  # ["hmm", "ohh", "wait"]

@dataclass
class StageGeneration:
    engine:             str
    model:              str
    prompt_tokens:      int         = 0
    output_tokens:      int         = 0
    total_tokens:       int         = 0
    latency_ms:         float       = 0.0
    raw_output:         str         = ""
    cache_hit:          bool        = False  # Gemini context cache used
    fillers_in_output:  list[str]   = field(default_factory=list)

@dataclass
class StageVoice:
    tts_engine:         str
    voice_id:           str
    stability:          float       = 0.0
    similarity_boost:   float       = 0.0
    style_exaggeration: float       = 0.0
    raw_text_length:    int         = 0
    cleaned_text_length:int         = 0
    chars_removed:      int         = 0     # markdown stripped
    audio_duration_ms:  float       = 0.0
    synthesis_latency_ms: float     = 0.0

@dataclass
class ChainFeedback:
    sentiment:          str         = "neutral"   # "loved"|"liked"|"neutral"|"disliked"|"hated"
    tags:               list[str]   = field(default_factory=list)  # ["funny", "helpful", "too_long", ...]
    source:             str         = "none"      # "reaction"|"voice_cmd"|"discord_cmd"
    raw_feedback:       str         = ""
    memory_effect:      str         = ""          # description of what got stored
    given_at:           str         = ""

@dataclass
class DecisionChain:
    """Complete record of one Luna response cycle."""
    chain_id:    str  = field(default_factory=lambda: str(uuid.uuid4())[:12])
    session_id:  str  = ""
    created_at:  str  = field(default_factory=lambda: datetime.utcnow().isoformat())

    # The 5 stages (populated progressively as they complete)
    intent:      Optional[StageIntent]      = None
    memory:      Optional[StageMemory]      = None
    personality: Optional[StagePersonality] = None
    generation:  Optional[StageGeneration]  = None
    voice:       Optional[StageVoice]       = None
    feedback:    Optional[ChainFeedback]    = None

    # Computed totals
    total_latency_ms: float = 0.0
    completed:        bool  = False

    def to_dict(self) -> dict:
        d = asdict(self)
        return d

    def stage_summary(self) -> str:
        parts = []
        if self.intent:
            parts.append(f"[①INTENT:{self.intent.classified_as}/{self.intent.engine_selected}]")
        if self.memory:
            parts.append(f"[②MEM:{self.memory.memories_injected.__len__()}facts]")
        if self.personality:
            parts.append(f"[③PERSONA:{self.personality.prompt_variant}]")
        if self.generation:
            parts.append(f"[④GEN:{self.generation.latency_ms:.0f}ms/{self.generation.total_tokens}tok]")
        if self.voice:
            parts.append(f"[⑤VOICE:{self.voice.tts_engine}]")
        return " → ".join(parts)


# ══════════════════════════════════════════════════════════════════════════════
# FILLER DETECTOR
# Post-hoc analysis: did Luna actually use the verbal fillers we asked for?
# ══════════════════════════════════════════════════════════════════════════════

FILLER_PATTERNS = {
    "hmm":        ["hmm", "hm,", "hmm,", "hmm..."],
    "ohh":        ["ohh", "ohh!", "ohh,", "oh!", "ooh"],
    "wait":       ["wait—", "wait,", "wait...", "wait!"],
    "let me think": ["let me think", "let me think..."],
    "okay so":    ["okay so", "okay, so"],
    "ooh actually":["ooh, actually", "ooh actually"],
    "right so":   ["right, so", "right so"],
}

def detect_fillers(text: str) -> list[str]:
    lower  = text.lower()
    found  = []
    for filler, patterns in FILLER_PATTERNS.items():
        if any(p in lower for p in patterns):
            found.append(filler)
    return found

def detect_emotive_asides(text: str) -> list[str]:
    """Find parenthetical emotional asides like '(okay that's actually cool)'"""
    import re
    asides = re.findall(r'\(([^)]{5,80})\)', text)
    return asides[:5]  # cap at 5


# ══════════════════════════════════════════════════════════════════════════════
# WEBSOCKET BROADCASTER
# ══════════════════════════════════════════════════════════════════════════════

class WSBroadcaster:
    """
    Runs a WebSocket server on localhost:8765.
    The React dashboard connects here to receive live decision chain events.
    """
    def __init__(self):
        self._clients: set = set()
        self._server  = None
        self._queue: asyncio.Queue = asyncio.Queue(maxsize=200)

    async def start(self):
        if not WS_AVAILABLE:
            return
        self._server = await websockets.serve(
            self._handle_client, WS_HOST, WS_PORT
        )
        asyncio.create_task(self._broadcast_loop())
        print(f"[Logger] WebSocket server → ws://{WS_HOST}:{WS_PORT}")

    async def _handle_client(self, ws: "WebSocketServerProtocol", path: str):
        self._clients.add(ws)
        print(f"[Logger] Dashboard connected ({len(self._clients)} clients)")
        try:
            # Send last 20 chains on connect
            chains = _db.get_recent_chains(limit=20)
            await ws.send(json.dumps({
                "type":   "history",
                "chains": [c.to_dict() for c in chains],
            }))
            await ws.wait_closed()
        finally:
            self._clients.discard(ws)

    async def _broadcast_loop(self):
        while True:
            event = await self._queue.get()
            dead  = set()
            for ws in list(self._clients):
                try:
                    await ws.send(json.dumps(event))
                except Exception:
                    dead.add(ws)
            self._clients -= dead

    def push(self, event_type: str, data: dict):
        """Thread-safe push — works from sync context too."""
        event = {"type": event_type, "ts": time.time(), **data}
        try:
            self._queue.put_nowait(event)
        except asyncio.QueueFull:
            pass  # drop if queue is full, never block


# ══════════════════════════════════════════════════════════════════════════════
# SQLITE STORE
# ══════════════════════════════════════════════════════════════════════════════

class DecisionStore:

    def __init__(self, path: Path = LOG_DB_PATH):
        self._conn = sqlite3.connect(str(path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self):
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS decision_chains (
                chain_id     TEXT PRIMARY KEY,
                session_id   TEXT,
                created_at   TEXT,
                completed    INTEGER DEFAULT 0,
                total_latency_ms REAL DEFAULT 0,
                chain_json   TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS stage_events (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                chain_id   TEXT REFERENCES decision_chains(chain_id),
                stage      TEXT,   -- intent|memory|personality|generation|voice|feedback
                event_at   TEXT,
                data_json  TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_chain_session ON decision_chains(session_id);
            CREATE INDEX IF NOT EXISTS idx_chain_created ON decision_chains(created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_stage_chain   ON stage_events(chain_id);
        """)
        self._conn.commit()

    def save_chain(self, chain: DecisionChain):
        self._conn.execute("""
            INSERT INTO decision_chains (chain_id, session_id, created_at, completed, total_latency_ms, chain_json)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(chain_id) DO UPDATE SET
                completed        = excluded.completed,
                total_latency_ms = excluded.total_latency_ms,
                chain_json       = excluded.chain_json
        """, (
            chain.chain_id, chain.session_id, chain.created_at,
            int(chain.completed), chain.total_latency_ms,
            json.dumps(chain.to_dict()),
        ))
        self._conn.commit()

    def log_stage(self, chain_id: str, stage: str, data: dict):
        self._conn.execute("""
            INSERT INTO stage_events (chain_id, stage, event_at, data_json)
            VALUES (?, ?, ?, ?)
        """, (chain_id, stage, datetime.utcnow().isoformat(), json.dumps(data)))
        self._conn.commit()

    def get_recent_chains(self, limit: int = 50) -> list[DecisionChain]:
        rows = self._conn.execute(
            "SELECT chain_json FROM decision_chains ORDER BY created_at DESC LIMIT ?",
            (limit,)
        ).fetchall()
        chains = []
        for row in rows:
            try:
                d = json.loads(row["chain_json"])
                chains.append(_dict_to_chain(d))
            except Exception:
                pass
        return chains

    def get_chain(self, chain_id: str) -> Optional[DecisionChain]:
        row = self._conn.execute(
            "SELECT chain_json FROM decision_chains WHERE chain_id = ?", (chain_id,)
        ).fetchone()
        if row:
            return _dict_to_chain(json.loads(row["chain_json"]))
        return None

    def get_feedback_stats(self) -> dict:
        """Aggregate feedback sentiments for the dashboard stats panel."""
        rows = self._conn.execute("""
            SELECT
                json_extract(chain_json, '$.feedback.sentiment') as sentiment,
                COUNT(*) as n
            FROM decision_chains
            WHERE json_extract(chain_json, '$.feedback') IS NOT NULL
            GROUP BY sentiment
        """).fetchall()
        return {row["sentiment"]: row["n"] for row in rows if row["sentiment"]}

    def get_filler_stats(self) -> dict:
        """Which verbal fillers appear most in loved vs disliked responses."""
        rows = self._conn.execute("""
            SELECT chain_json FROM decision_chains
            WHERE json_extract(chain_json, '$.feedback.sentiment') IN ('loved', 'liked', 'disliked', 'hated')
            ORDER BY created_at DESC LIMIT 200
        """).fetchall()
        filler_sentiment: dict[str, dict] = {}
        for row in rows:
            try:
                d     = json.loads(row["chain_json"])
                sent  = d.get("feedback", {}).get("sentiment", "neutral")
                gen   = d.get("generation") or {}
                fillers = gen.get("fillers_in_output", [])
                for f in fillers:
                    if f not in filler_sentiment:
                        filler_sentiment[f] = {"loved": 0, "liked": 0, "disliked": 0, "hated": 0}
                    if sent in filler_sentiment[f]:
                        filler_sentiment[f][sent] += 1
            except Exception:
                pass
        return filler_sentiment


def _dict_to_chain(d: dict) -> DecisionChain:
    """Reconstruct a DecisionChain from its serialized dict."""
    c = DecisionChain()
    c.chain_id  = d.get("chain_id", "")
    c.session_id = d.get("session_id", "")
    c.created_at = d.get("created_at", "")
    c.completed  = d.get("completed", False)
    c.total_latency_ms = d.get("total_latency_ms", 0)

    def _maybe(cls, data):
        return cls(**data) if data else None

    c.intent      = _maybe(StageIntent,      d.get("intent"))
    c.memory      = _maybe(StageMemory,      d.get("memory"))
    c.personality = _maybe(StagePersonality, d.get("personality"))
    c.generation  = _maybe(StageGeneration,  d.get("generation"))
    c.voice       = _maybe(StageVoice,       d.get("voice"))
    c.feedback    = _maybe(ChainFeedback,    d.get("feedback"))
    return c


# ══════════════════════════════════════════════════════════════════════════════
# GLOBAL SINGLETONS
# ══════════════════════════════════════════════════════════════════════════════

_db          = DecisionStore()
_broadcaster = WSBroadcaster()
_active_chains: dict[str, DecisionChain] = {}   # chain_id → live chain


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC API — used by all other Luna modules
# ══════════════════════════════════════════════════════════════════════════════

def new_chain(session_id: str = "") -> DecisionChain:
    """Start a new decision chain. Call at the beginning of every response cycle."""
    chain = DecisionChain(session_id=session_id)
    _active_chains[chain.chain_id] = chain
    _broadcaster.push("chain_start", {"chain_id": chain.chain_id, "session_id": session_id})
    return chain


def log_intent(chain: DecisionChain, **kwargs) -> DecisionChain:
    chain.intent = StageIntent(**kwargs)
    _db.log_stage(chain.chain_id, "intent", asdict(chain.intent))
    _broadcaster.push("stage_update", {
        "chain_id": chain.chain_id,
        "stage": "intent",
        "data": asdict(chain.intent),
    })
    _db.save_chain(chain)
    return chain


def log_memory(chain: DecisionChain, **kwargs) -> DecisionChain:
    chain.memory = StageMemory(**kwargs)
    _db.log_stage(chain.chain_id, "memory", asdict(chain.memory))
    _broadcaster.push("stage_update", {
        "chain_id": chain.chain_id,
        "stage": "memory",
        "data": asdict(chain.memory),
    })
    _db.save_chain(chain)
    return chain


def log_personality(chain: DecisionChain, **kwargs) -> DecisionChain:
    chain.personality = StagePersonality(**kwargs)
    _db.log_stage(chain.chain_id, "personality", asdict(chain.personality))
    _broadcaster.push("stage_update", {
        "chain_id": chain.chain_id,
        "stage": "personality",
        "data": asdict(chain.personality),
    })
    _db.save_chain(chain)
    return chain


def log_generation(chain: DecisionChain, raw_output: str = "", **kwargs) -> DecisionChain:
    fillers = detect_fillers(raw_output)
    asides  = detect_emotive_asides(raw_output)
    chain.generation = StageGeneration(
        raw_output         = raw_output[:2000],   # cap stored output size
        fillers_in_output  = fillers,
        **kwargs,
    )
    _db.log_stage(chain.chain_id, "generation", asdict(chain.generation))
    _broadcaster.push("stage_update", {
        "chain_id": chain.chain_id,
        "stage": "generation",
        "data": {**asdict(chain.generation), "emotive_asides": asides},
    })
    _db.save_chain(chain)
    return chain


def log_voice(chain: DecisionChain, **kwargs) -> DecisionChain:
    chain.voice = StageVoice(**kwargs)
    _db.log_stage(chain.chain_id, "voice", asdict(chain.voice))
    _broadcaster.push("stage_update", {
        "chain_id": chain.chain_id,
        "stage": "voice",
        "data": asdict(chain.voice),
    })
    _db.save_chain(chain)
    return chain


def complete_chain(chain: DecisionChain) -> DecisionChain:
    """Mark chain as done, compute total latency, broadcast completion."""
    chain.completed = True
    latencies = []
    if chain.intent:     latencies.append(chain.intent.latency_ms)
    if chain.generation: latencies.append(chain.generation.latency_ms)
    if chain.voice:      latencies.append(chain.voice.synthesis_latency_ms)
    chain.total_latency_ms = sum(latencies)

    _db.save_chain(chain)
    _broadcaster.push("chain_complete", {
        "chain_id":   chain.chain_id,
        "summary":    chain.stage_summary(),
        "latency_ms": chain.total_latency_ms,
    })
    _active_chains.pop(chain.chain_id, None)
    print(f"[Logger] Chain complete: {chain.stage_summary()}")
    return chain


def apply_feedback(
    chain_id:  str,
    sentiment: str,
    tags:      list[str] = None,
    source:    str       = "reaction",
    raw:       str       = "",
    memory_engine = None,
) -> Optional[DecisionChain]:
    """
    Apply user feedback to a completed chain.
    Optionally feeds sentiment back into the MemoryEngine.
    Returns the updated chain.
    """
    chain = _db.get_chain(chain_id)
    if not chain:
        print(f"[Logger] apply_feedback: chain {chain_id} not found")
        return None

    memory_effect = ""

    # ── Feed back into memory engine ──────────────────────────────────────────
    if memory_engine and chain.generation:
        output_snippet = (chain.generation.raw_output or "")[:200]
        fillers        = chain.generation.fillers_in_output or []

        if sentiment in ("loved", "liked"):
            # Boost importance of any style/humor memories that were active
            if chain.memory and chain.memory.memories_injected:
                for mem in chain.memory.memories_injected:
                    memory_engine.update_importance(mem["id"], delta=+0.08)

            # Store what made the user happy
            if fillers:
                filler_str = ", ".join(fillers)
                memory_engine.add(
                    f"User {sentiment} a response that used verbal fillers: {filler_str}. "
                    f"Snippet: \"{output_snippet[:100]}\"",
                    category   = "humor",
                    importance = 0.75 if sentiment == "loved" else 0.60,
                    source     = "feedback",
                    tags       = ["positive_feedback", "verbal_style"] + (tags or []),
                )
                memory_effect = f"Stored positive filler pattern: {filler_str}"

            if tags:
                tag_str = ", ".join(tags)
                memory_engine.add(
                    f"User tagged response as: {tag_str}. They {sentiment} it. "
                    f"Context: {output_snippet[:100]}",
                    category   = "preference",
                    importance = 0.70,
                    source     = "feedback",
                    tags       = ["positive_feedback"] + tags,
                )
                memory_effect += f" | Tagged: {tag_str}"

        elif sentiment in ("disliked", "hated"):
            # Record what to avoid
            if fillers:
                filler_str = ", ".join(fillers)
                memory_engine.add(
                    f"User {sentiment} a response. Fillers present: {filler_str}. "
                    f"Consider reducing filler frequency in similar contexts.",
                    category   = "humor",
                    importance = 0.65,
                    source     = "feedback",
                    tags       = ["negative_feedback", "verbal_style"] + (tags or []),
                )
                memory_effect = f"Noted negative pattern: {filler_str}"

            # Dampen importance of memories used in this chain
            if chain.memory and chain.memory.memories_injected:
                for mem in chain.memory.memories_injected:
                    memory_engine.update_importance(mem["id"], delta=-0.05)

            if tags:
                tag_str = ", ".join(tags)
                memory_engine.add(
                    f"User {sentiment} and tagged: {tag_str}. "
                    f"Avoid this pattern: {output_snippet[:100]}",
                    category   = "preference",
                    importance = 0.65,
                    source     = "feedback",
                    tags       = ["negative_feedback"] + tags,
                )
                memory_effect += f" | Avoid: {tag_str}"

    chain.feedback = ChainFeedback(
        sentiment     = sentiment,
        tags          = tags or [],
        source        = source,
        raw_feedback  = raw,
        memory_effect = memory_effect,
        given_at      = datetime.utcnow().isoformat(),
    )

    _db.save_chain(chain)
    _broadcaster.push("feedback_received", {
        "chain_id":      chain_id,
        "sentiment":     sentiment,
        "tags":          tags or [],
        "memory_effect": memory_effect,
    })

    print(f"[Logger] Feedback on {chain_id}: {sentiment} {tags} → {memory_effect}")
    return chain


async def start_ws_server():
    """Call once at bot startup to begin broadcasting."""
    await _broadcaster.start()


def get_recent_chains(limit: int = 50) -> list[DecisionChain]:
    return _db.get_recent_chains(limit=limit)

def get_stats() -> dict:
    return {
        "feedback_sentiment": _db.get_feedback_stats(),
        "filler_sentiment":   _db.get_filler_stats(),
    }
