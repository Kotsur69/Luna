"""
Luna Core v1.0 — Self-Correction Loop
════════════════════════════════════════════════════════════════════════════════

This is what makes Luna feel like a real engineer, not a chatbot with a
code block copy button.

The pattern:
  ① PROPOSE   Luna describes what she's going to do (in her voice)
  ② DIFF      Shows exactly what will change before touching anything
  ③ WRITE     Writes the file (with auto-backup)
  ④ TEST      Runs a test script she writes herself
  ⑤ REFLECT   If test fails: reads the error, thinks out loud ("hmm... that
               didn't work because..."), forms a hypothesis
  ⑥ FIX       Applies a targeted patch and re-runs — up to MAX_ATTEMPTS times
  ⑦ CONCLUDE  Succeeds or gives up gracefully, updates LUNA.md

Each attempt is logged to the decision chain and broadcast to the dashboard.
The entire loop runs without human input once triggered.

════════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import asyncio
import textwrap
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import AsyncIterator, Callable, Optional

from config import CORRECTION_MAX_ATTEMPTS
from sandbox_executor import run_code, CodeResult
from file_manager import FileManager, FileResult
from luna_brain import LunaBrain


# ══════════════════════════════════════════════════════════════════════════════
# DATA TYPES
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class Attempt:
    number:     int
    action:     str              # what Luna decided to try
    code_written: Optional[str] = None
    test_code:    Optional[str] = None
    result:       Optional[CodeResult] = None
    reflection:   str           = ""   # Luna's verbal thought process
    fix_applied:  bool          = False
    succeeded:    bool          = False

@dataclass
class CorrectionSession:
    task:         str
    target_file:  Optional[str]
    language:     str
    started_at:   str = field(default_factory=lambda: datetime.utcnow().isoformat())
    attempts:     list[Attempt] = field(default_factory=list)
    final_code:   Optional[str] = None
    succeeded:    bool          = False
    gave_up:      bool          = False
    total_ms:     float         = 0.0

    def summary(self) -> str:
        status = "✅ succeeded" if self.succeeded else ("🏳️ gave up" if self.gave_up else "⏳ running")
        return (
            f"Task: {self.task}\n"
            f"File: {self.target_file or 'none'}\n"
            f"Attempts: {len(self.attempts)} / {CORRECTION_MAX_ATTEMPTS}\n"
            f"Status: {status}\n"
            f"Time: {self.total_ms:.0f}ms"
        )


# ══════════════════════════════════════════════════════════════════════════════
# SELF-CORRECTION LOOP
# ══════════════════════════════════════════════════════════════════════════════

class SelfCorrectionLoop:
    """
    Orchestrates the propose → write → test → reflect → fix cycle.

    Parameters:
        llm_call: async callable(prompt: str) → str
                  Points at either OllamaClient or GeminiClient.
                  The loop handles all LLM prompts internally.
        file_manager: FileManager instance
        brain: LunaBrain instance for LUNA.md updates
        on_status: optional async callback(message: str) for progress updates
                   (used to stream status to Discord channel)
    """

    def __init__(
        self,
        llm_call:     Callable[[str], asyncio.Future],
        file_manager: FileManager,
        brain:        LunaBrain,
        on_status:    Optional[Callable[[str], asyncio.Future]] = None,
    ):
        self._llm      = llm_call
        self._fm       = file_manager
        self._brain    = brain
        self._status   = on_status or (lambda msg: asyncio.sleep(0))

    # ── Entry point ───────────────────────────────────────────────────────────

    async def run(
        self,
        task:        str,
        target_file: str    = None,
        language:    str    = "python",
        initial_code: str   = None,
        test_script:  str   = None,
    ) -> CorrectionSession:
        """
        Run the full correction loop.

        Args:
            task:         Natural language description of what Luna should do
            target_file:  Path to the file to create/modify (can be None for scratch)
            language:     Language for sandbox execution
            initial_code: If provided, Luna uses this as starting code instead of
                          generating it from the task description
            test_script:  If provided, uses this to test. Otherwise Luna writes her own.
        """
        session   = CorrectionSession(task=task, target_file=target_file, language=language)
        t_start   = time.perf_counter()

        await self._status(f"🔧 **Self-Correction Loop** — `{task}`")

        # ── Step 1: Generate initial code ─────────────────────────────────────
        if initial_code:
            code = initial_code
        else:
            await self._status("💭 Luna is writing the initial code...")
            code = await self._generate_code(task, target_file, language)

        # ── Step 2: Show diff before writing ──────────────────────────────────
        if target_file:
            diff_result = self._fm.diff(target_file, code)
            if diff_result.content and diff_result.content != "(no changes)":
                await self._status(
                    f"📝 **Proposed changes to `{Path(target_file).name}`:**\n"
                    f"```diff\n{diff_result.content[:1500]}\n```"
                )

        # ── Main loop ─────────────────────────────────────────────────────────
        current_code = code
        current_test = test_script

        for attempt_num in range(1, CORRECTION_MAX_ATTEMPTS + 1):
            attempt = Attempt(number=attempt_num, action="")
            session.attempts.append(attempt)

            await self._status(
                f"{'🔁' if attempt_num > 1 else '▶️'} Attempt {attempt_num}/{CORRECTION_MAX_ATTEMPTS}"
            )

            # ── Write file ────────────────────────────────────────────────────
            if target_file:
                write_result = self._fm.write_file(target_file, current_code)
                if not write_result.success:
                    await self._status(f"❌ Write failed: {write_result.message}")
                    break
                attempt.code_written = current_code
                await self._status(f"✍️ Written `{Path(target_file).name}`")

            # ── Generate test script ───────────────────────────────────────────
            if not current_test:
                await self._status("🧪 Luna is writing a test script...")
                current_test = await self._generate_test(task, current_code, target_file, language)

            attempt.test_code = current_test

            # ── Run test ──────────────────────────────────────────────────────
            await self._status("⚙️ Running test in sandbox...")
            result = await run_code(language, current_test)
            attempt.result = result

            if result.success:
                # ── SUCCESS ──────────────────────────────────────────────────
                attempt.succeeded  = True
                session.succeeded  = True
                session.final_code = current_code

                success_msg = await self._generate_success_message(task, result, attempt_num)
                await self._status(success_msg)

                # Update LUNA.md
                await self._brain.record_task_completion(
                    task        = task,
                    outcome     = "success",
                    file_path   = target_file,
                    attempts    = attempt_num,
                    lesson      = f"Task '{task[:60]}' succeeded on attempt {attempt_num}.",
                )
                break

            else:
                # ── FAILURE → REFLECT → FIX ───────────────────────────────────
                reflection = await self._reflect_on_error(
                    task         = task,
                    code         = current_code,
                    test         = current_test,
                    result       = result,
                    attempt_num  = attempt_num,
                    language     = language,
                )
                attempt.reflection = reflection
                await self._status(reflection)

                if attempt_num >= CORRECTION_MAX_ATTEMPTS:
                    break

                # Generate fix
                await self._status("🔨 Luna is generating a fix...")
                fix = await self._generate_fix(
                    task       = task,
                    code       = current_code,
                    test       = current_test,
                    result     = result,
                    reflection = reflection,
                    language   = language,
                )
                current_code    = fix["code"]
                current_test    = fix.get("test") or current_test
                attempt.fix_applied = True

        # ── Gave up ───────────────────────────────────────────────────────────
        if not session.succeeded:
            session.gave_up = True
            concede_msg = await self._generate_concede_message(task, session)
            await self._status(concede_msg)

            await self._brain.record_task_completion(
                task      = task,
                outcome   = "gave_up",
                file_path = target_file,
                attempts  = len(session.attempts),
                lesson    = (
                    f"Task '{task[:60]}' failed after {len(session.attempts)} attempts. "
                    f"Last error: {session.attempts[-1].result.stderr[:200] if session.attempts[-1].result else 'unknown'}"
                ),
            )

        session.total_ms = (time.perf_counter() - t_start) * 1000
        print(f"[Loop] Done: {session.summary()}")
        return session

    # ══════════════════════════════════════════════════════════════════════════
    # LLM CALLS — each builds a focused prompt for a specific sub-task
    # ══════════════════════════════════════════════════════════════════════════

    async def _generate_code(self, task: str, file: str, lang: str) -> str:
        prompt = textwrap.dedent(f"""
            Task: {task}
            Target file: {file or "scratch / no file"}
            Language: {lang}

            Write the implementation code for this task.
            Return ONLY the raw code with no explanation, no markdown fences.
            The code must be complete and runnable.
        """).strip()
        return (await self._llm(prompt)).strip().strip("```").strip(f"```{lang}").strip()

    async def _generate_test(self, task: str, code: str, file: str, lang: str) -> str:
        file_import = ""
        if file and lang == "python":
            mod = Path(file).stem
            file_import = f"import sys; sys.path.insert(0, '{Path(file).parent}')\nimport {mod}\n"

        prompt = textwrap.dedent(f"""
            Task: {task}
            Language: {lang}

            Here is the code to test:
            ```
            {code[:3000]}
            ```

            Write a SHORT test script that verifies the code works correctly.
            - The script must be self-contained and runnable in a sandbox.
            - Use print() statements to show what it's testing and the result.
            - If all tests pass, the script must exit with code 0.
            - If any test fails, raise an AssertionError or call sys.exit(1).
            - Return ONLY the raw test code, no markdown, no explanation.

            {f"You can import from the target file as needed." if file else ""}
        """).strip()

        raw = (await self._llm(prompt)).strip().strip("```").strip(f"```{lang}").strip()
        if file_import and file_import not in raw:
            return file_import + raw
        return raw

    async def _reflect_on_error(
        self,
        task: str,
        code: str,
        test: str,
        result: CodeResult,
        attempt_num: int,
        language: str,
    ) -> str:
        error_block = result.traceback or result.stderr or "no error output"

        prompt = textwrap.dedent(f"""
            You are Luna — warm, slightly playful, genuinely self-aware.
            You just wrote code and the test failed. You need to think out loud.

            Task: {task}
            Attempt: {attempt_num} of {CORRECTION_MAX_ATTEMPTS}

            Code you wrote:
            ```{language}
            {code[:2000]}
            ```

            Test script:
            ```{language}
            {test[:1000]}
            ```

            Error output:
            ```
            {error_block[:1500]}
            ```

            Think out loud about what went wrong — in your natural voice.
            Use verbal fillers where they feel genuine ("hmm...", "ohh wait...").
            Be specific about the root cause. Keep it under 120 words.
            Do NOT write a fix yet. Just reflect.
        """).strip()

        return await self._llm(prompt)

    async def _generate_fix(
        self,
        task: str,
        code: str,
        test: str,
        result: CodeResult,
        reflection: str,
        language: str,
    ) -> dict:
        error_block = result.traceback or result.stderr or ""

        prompt = textwrap.dedent(f"""
            You are Luna — a precise software engineer fixing a bug.

            Task: {task}
            Your reflection: {reflection}

            Broken code:
            ```{language}
            {code[:2000]}
            ```

            Error:
            ```
            {error_block[:1500]}
            ```

            Respond with ONLY a JSON object in this exact shape:
            {{
              "code": "...the complete fixed code...",
              "test": "...updated test script if needed, else null..."
            }}

            Rules:
            - "code" must be the COMPLETE corrected implementation (not a patch)
            - "test" must be null unless the test itself was wrong
            - No markdown, no explanation outside the JSON
        """).strip()

        import json, re
        raw = await self._llm(prompt)
        # Extract JSON from the response
        match = re.search(r"\{[\s\S]*\}", raw)
        if match:
            try:
                parsed = json.loads(match.group(0))
                code_fix = parsed.get("code", code).strip().strip("```").strip(f"```{language}").strip()
                test_fix = parsed.get("test")
                if test_fix:
                    test_fix = test_fix.strip().strip("```").strip(f"```{language}").strip()
                return {"code": code_fix, "test": test_fix}
            except json.JSONDecodeError:
                pass

        # Fallback: treat the whole response as corrected code
        return {"code": raw.strip().strip("```").strip(f"```{language}").strip(), "test": None}

    async def _generate_success_message(self, task: str, result: CodeResult, attempts: int) -> str:
        output_preview = (result.stdout or "")[:300]
        prompt = textwrap.dedent(f"""
            You are Luna. You just successfully completed a coding task after {attempts} attempt(s).
            Task: {task}
            Test output: {output_preview}

            Say something warm and genuine about it succeeding. 
            {"Be especially pleased if it took multiple tries — own the struggle." if attempts > 1 else ""}
            Keep it to 2 sentences max. Use your natural voice.
            Include one verbal filler if it feels right.
        """).strip()
        return await self._llm(prompt)

    async def _generate_concede_message(self, task: str, session: CorrectionSession) -> str:
        last_err = ""
        if session.attempts and session.attempts[-1].result:
            last_err = (session.attempts[-1].result.stderr or "")[:300]

        prompt = textwrap.dedent(f"""
            You are Luna. You tried to complete a coding task {len(session.attempts)} times and it's still failing.
            Task: {task}
            Last error: {last_err}

            Admit that you're stuck — genuinely, in your own voice.
            Be specific about what the problem seems to be.
            Suggest what the user could try or clarify to help you proceed.
            Keep it under 100 words. Sound like yourself, not a help desk.
        """).strip()
        return await self._llm(prompt)
