"""
Luna Core v1.0 — Dev Log (Luna's Changelog)
════════════════════════════════════════════════════════════════════════════════

This is Luna's own engineering changelog. Every time she touches a file,
runs code, changes a config value, or completes a task — she logs it here.

The core insight: if Luna changes a variable in config.py and the voice
handler breaks two minutes later, she needs to look at her own log and say
"ohh wait... I changed STABILITY from 0.35 to 0.8 at 14:32 and the voice
broke at 14:33. That's probably it. Let me roll that back."

Structure:
  - Append-only flat log file: luna_dev.log (machine-readable JSONL)
  - Human-readable summary:    DEVLOG.md (what you open when debugging)
  - SQLite index for fast blame queries: "what changed near time X?"

The three query patterns that matter most:
  1. "what did Luna change in the last 10 minutes?" → recent_changes()
  2. "what touched voice_handler.py?" → changes_to_file()
  3. "what broke things?" → changes_before_error()

════════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import json
import sqlite3
import time
import traceback
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from config import BASE_DIR


# ── Paths ─────────────────────────────────────────────────────────────────────
DEV_LOG_JSONL = BASE_DIR / "luna_dev.log"     # append-only JSONL
DEV_LOG_MD    = BASE_DIR / "DEVLOG.md"        # human-readable summary
DEV_LOG_DB    = BASE_DIR / "luna_devlog.db"   # SQLite index for queries


# ══════════════════════════════════════════════════════════════════════════════
# DATA MODEL
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class LogEntry:
    entry_id:      str   = field(default_factory=lambda: str(uuid.uuid4())[:10])
    ts:            str   = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    ts_unix:       float = field(default_factory=time.time)

    # What happened
    action:        str   = ""      # e.g. "write_file", "run_code", "config_change", "fix_applied"
    result:        str   = ""      # "success" | "failure" | "partial" | free text
    description:   str   = ""      # human-readable one-liner

    # Where it happened
    file_path:     Optional[str] = None    # file that was touched
    function_name: Optional[str] = None   # function/method involved
    line_range:    Optional[str] = None   # e.g. "40-55"

    # What changed (for config/code changes)
    before_value:  Optional[str] = None   # old value / snippet
    after_value:   Optional[str] = None   # new value / snippet
    diff_summary:  Optional[str] = None   # short description of diff

    # Context
    task_context:  Optional[str] = None   # what Luna was trying to do
    error_message: Optional[str] = None   # if result == "failure"
    stack_trace:   Optional[str] = None   # captured traceback if available

    # Causal links
    caused_by_id:  Optional[str] = None   # entry_id of the action that triggered this
    broke_things:  bool          = False   # set retroactively when an error is traced back

    def to_oneliner(self) -> str:
        ts_short = self.ts[11:19]   # HH:MM:SS
        icon = "✅" if self.result == "success" else ("❌" if self.result == "failure" else "🔧")
        file = f" [{Path(self.file_path).name}]" if self.file_path else ""
        return f"[{ts_short}] {icon} {self.action}{file} — {self.description[:80]}"


# ══════════════════════════════════════════════════════════════════════════════
# DEV LOG
# ══════════════════════════════════════════════════════════════════════════════

class DevLog:
    """
    Luna's append-only engineering changelog.
    Thread-safe for async use (SQLite WAL mode).
    """

    def __init__(self):
        self._db = sqlite3.connect(str(DEV_LOG_DB), check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA journal_mode=WAL")
        self._init_schema()
        self._ensure_md_header()
        print(f"[DevLog] Initialized → {DEV_LOG_JSONL.name} + {DEV_LOG_MD.name}")

    # ── Schema ────────────────────────────────────────────────────────────────

    def _init_schema(self):
        self._db.executescript("""
            CREATE TABLE IF NOT EXISTS dev_log (
                entry_id      TEXT PRIMARY KEY,
                ts            TEXT NOT NULL,
                ts_unix       REAL NOT NULL,
                action        TEXT NOT NULL,
                result        TEXT,
                description   TEXT,
                file_path     TEXT,
                function_name TEXT,
                before_value  TEXT,
                after_value   TEXT,
                diff_summary  TEXT,
                task_context  TEXT,
                error_message TEXT,
                caused_by_id  TEXT,
                broke_things  INTEGER DEFAULT 0,
                entry_json    TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_log_ts       ON dev_log(ts_unix DESC);
            CREATE INDEX IF NOT EXISTS idx_log_file     ON dev_log(file_path);
            CREATE INDEX IF NOT EXISTS idx_log_action   ON dev_log(action);
            CREATE INDEX IF NOT EXISTS idx_log_result   ON dev_log(result);
        """)
        self._db.commit()

    # ── Core write ────────────────────────────────────────────────────────────

    def update_dev_log(
        self,
        action:        str,
        result:        str,
        description:   str         = "",
        file_path:     str         = None,
        function_name: str         = None,
        line_range:    str         = None,
        before_value:  str         = None,
        after_value:   str         = None,
        diff_summary:  str         = None,
        task_context:  str         = None,
        error_message: str         = None,
        stack_trace:   str         = None,
        caused_by_id:  str         = None,
    ) -> LogEntry:
        """
        The primary public API — called after every significant action Luna takes.

        Args:
            action:      Short verb phrase: "write_file", "config_change",
                         "run_code", "fix_applied", "tool_called", "test_passed", etc.
            result:      "success" | "failure" | "partial" | any free text
            description: One human-readable sentence describing what happened
            file_path:   Path of the file that was created/modified (if any)
            before_value: The old value/snippet (for change tracking)
            after_value:  The new value/snippet
            diff_summary: Short description of what changed ("added type hints to 3 functions")
            task_context: The higher-level task Luna was doing ("fixing auth bug")
            error_message: If result == "failure", the error
            caused_by_id: entry_id of a previous entry that triggered this one

        Returns:
            LogEntry that was written (has .entry_id for future caused_by_id references)
        """
        entry = LogEntry(
            action        = action,
            result        = result,
            description   = description or f"{action} → {result}",
            file_path     = str(file_path) if file_path else None,
            function_name = function_name,
            line_range    = line_range,
            before_value  = str(before_value)[:500] if before_value else None,
            after_value   = str(after_value)[:500] if after_value else None,
            diff_summary  = diff_summary,
            task_context  = task_context,
            error_message = str(error_message)[:1000] if error_message else None,
            stack_trace   = str(stack_trace)[:2000] if stack_trace else None,
            caused_by_id  = caused_by_id,
        )

        # Write to JSONL (append-only truth)
        with open(DEV_LOG_JSONL, "a", encoding="utf-8") as f:
            f.write(json.dumps(asdict(entry)) + "\n")

        # Write to SQLite (queryable index)
        self._db.execute("""
            INSERT OR REPLACE INTO dev_log
            (entry_id, ts, ts_unix, action, result, description, file_path,
             function_name, before_value, after_value, diff_summary, task_context,
             error_message, caused_by_id, broke_things, entry_json)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            entry.entry_id, entry.ts, entry.ts_unix,
            entry.action, entry.result, entry.description,
            entry.file_path, entry.function_name,
            entry.before_value, entry.after_value, entry.diff_summary,
            entry.task_context, entry.error_message, entry.caused_by_id,
            0, json.dumps(asdict(entry)),
        ))
        self._db.commit()

        # Append to DEVLOG.md
        self._append_to_md(entry)

        print(f"[DevLog] {entry.to_oneliner()}")
        return entry

    # ── Convenience wrappers ──────────────────────────────────────────────────

    def log_file_write(self, file_path: str, diff_summary: str, task: str = None,
                       before: str = None, after: str = None) -> LogEntry:
        return self.update_dev_log(
            action       = "write_file",
            result       = "success",
            description  = f"Wrote `{Path(file_path).name}`: {diff_summary}",
            file_path    = file_path,
            diff_summary = diff_summary,
            before_value = before,
            after_value  = after,
            task_context = task,
        )

    def log_config_change(self, key: str, old_val, new_val,
                          file_path: str = None, task: str = None) -> LogEntry:
        return self.update_dev_log(
            action       = "config_change",
            result       = "success",
            description  = f"Changed `{key}`: {old_val!r} → {new_val!r}",
            file_path    = file_path,
            before_value = str(old_val),
            after_value  = str(new_val),
            diff_summary = f"{key} changed",
            task_context = task,
        )

    def log_code_run(self, language: str, success: bool,
                     output_preview: str = "", task: str = None) -> LogEntry:
        return self.update_dev_log(
            action       = "run_code",
            result       = "success" if success else "failure",
            description  = f"Ran {language} code — {'passed' if success else 'FAILED'}",
            error_message= output_preview if not success else None,
            task_context = task,
        )

    def log_fix_attempt(self, file_path: str, attempt: int,
                        success: bool, error: str = None, task: str = None) -> LogEntry:
        return self.update_dev_log(
            action        = "fix_attempt",
            result        = "success" if success else "failure",
            description   = f"Fix attempt {attempt} on `{Path(file_path).name if file_path else '?'}` — {'✓' if success else '✗'}",
            file_path     = file_path,
            error_message = error,
            task_context  = task,
        )

    def log_mcp_call(self, tool_name: str, success: bool,
                     result_preview: str = "", task: str = None) -> LogEntry:
        return self.update_dev_log(
            action       = "mcp_tool_call",
            result       = "success" if success else "failure",
            description  = f"Called MCP tool `{tool_name}` — {'ok' if success else 'FAILED'}",
            function_name= tool_name,
            error_message= result_preview if not success else None,
            task_context = task,
        )

    def log_error(self, description: str, file_path: str = None,
                  exc: Exception = None, caused_by_id: str = None) -> LogEntry:
        tb = traceback.format_exc() if exc else None
        return self.update_dev_log(
            action        = "error",
            result        = "failure",
            description   = description,
            file_path     = file_path,
            error_message = str(exc) if exc else None,
            stack_trace   = tb,
            caused_by_id  = caused_by_id,
        )

    # ── Queries ───────────────────────────────────────────────────────────────

    def recent_changes(self, minutes: int = 30, limit: int = 20) -> list[LogEntry]:
        """What did Luna do in the last N minutes?"""
        since = time.time() - (minutes * 60)
        rows  = self._db.execute(
            "SELECT entry_json FROM dev_log WHERE ts_unix > ? ORDER BY ts_unix DESC LIMIT ?",
            (since, limit)
        ).fetchall()
        return [LogEntry(**json.loads(r["entry_json"])) for r in rows]

    def changes_to_file(self, file_path: str, limit: int = 20) -> list[LogEntry]:
        """What touched this file?"""
        # Match on filename alone if full path not given
        pattern = f"%{Path(file_path).name}%"
        rows    = self._db.execute(
            "SELECT entry_json FROM dev_log WHERE file_path LIKE ? ORDER BY ts_unix DESC LIMIT ?",
            (pattern, limit)
        ).fetchall()
        return [LogEntry(**json.loads(r["entry_json"])) for r in rows]

    def changes_before_error(
        self, error_ts_unix: float = None, window_minutes: int = 10
    ) -> list[LogEntry]:
        """
        The blame query: what changed in the N minutes before an error occurred?
        If error_ts_unix is None, uses now — looks at the last window_minutes.
        """
        t_end   = error_ts_unix or time.time()
        t_start = t_end - (window_minutes * 60)
        rows    = self._db.execute("""
            SELECT entry_json FROM dev_log
            WHERE ts_unix BETWEEN ? AND ?
              AND action NOT IN ('error')
            ORDER BY ts_unix DESC
            LIMIT 20
        """, (t_start, t_end)).fetchall()
        return [LogEntry(**json.loads(r["entry_json"])) for r in rows]

    def get_failures(self, limit: int = 10) -> list[LogEntry]:
        rows = self._db.execute(
            "SELECT entry_json FROM dev_log WHERE result = 'failure' ORDER BY ts_unix DESC LIMIT ?",
            (limit,)
        ).fetchall()
        return [LogEntry(**json.loads(r["entry_json"])) for r in rows]

    def mark_entry_broke_things(self, entry_id: str):
        """Retroactively mark an entry as the cause of a breakage."""
        self._db.execute(
            "UPDATE dev_log SET broke_things = 1 WHERE entry_id = ?", (entry_id,)
        )
        self._db.commit()

    # ── Luna-readable summaries ───────────────────────────────────────────────

    def build_blame_report(self, error_description: str, window_minutes: int = 15) -> str:
        """
        Build a causal analysis block for Luna to read when something breaks.
        Luna injects this into her reflection prompt during self-correction.
        """
        recent = self.changes_before_error(window_minutes=window_minutes)
        if not recent:
            return f"No changes recorded in the last {window_minutes} minutes."

        lines = [
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
            f"RECENT CHANGES (last {window_minutes}min) — possible causes of: {error_description[:80]}",
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        ]
        for e in recent:
            file_note = f" [{Path(e.file_path).name}]" if e.file_path else ""
            before_after = ""
            if e.before_value and e.after_value:
                before_after = f"\n     before: {e.before_value[:60]!r}\n     after:  {e.after_value[:60]!r}"
            lines.append(f"  [{e.ts[11:19]}] {e.action}{file_note} — {e.description[:80]}{before_after}")

        return "\n".join(lines)

    def build_session_summary(self, limit: int = 15) -> str:
        """Returns a compact summary of recent activity for LUNA.md / Discord."""
        entries = self.recent_changes(minutes=180, limit=limit)
        if not entries:
            return "No activity in the last 3 hours."
        lines = [e.to_oneliner() for e in entries]
        return "\n".join(lines)

    def stats(self) -> dict:
        row = self._db.execute("""
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN result='success' THEN 1 ELSE 0 END) as successes,
                SUM(CASE WHEN result='failure' THEN 1 ELSE 0 END) as failures,
                SUM(CASE WHEN broke_things=1  THEN 1 ELSE 0 END) as known_breaks,
                COUNT(DISTINCT file_path) as files_touched
            FROM dev_log
        """).fetchone()
        return dict(row) if row else {}

    # ── DEVLOG.md management ──────────────────────────────────────────────────

    def _ensure_md_header(self):
        if not DEV_LOG_MD.exists():
            DEV_LOG_MD.write_text(
                "# 🛠️ Luna Dev Log\n"
                "> Auto-generated by Luna. Shows every action she took, in order.\n"
                "> Use this to trace what changed before something broke.\n\n"
                "---\n\n",
                encoding="utf-8",
            )

    def _append_to_md(self, entry: LogEntry):
        """Append a formatted entry to DEVLOG.md."""
        ts_display  = entry.ts[:19].replace("T", " ")
        result_icon = {"success": "✅", "failure": "❌", "partial": "⚠️"}.get(entry.result, "🔧")
        file_note   = f"\n- **File:** `{entry.file_path}`" if entry.file_path else ""
        change_note = ""
        if entry.before_value and entry.after_value:
            change_note = (
                f"\n- **Before:** `{entry.before_value[:100]}`"
                f"\n- **After:** `{entry.after_value[:100]}`"
            )
        error_note = f"\n- **Error:** `{entry.error_message[:150]}`" if entry.error_message else ""
        task_note  = f"\n- **Task:** {entry.task_context}" if entry.task_context else ""

        block = (
            f"### `[{ts_display}]` {result_icon} {entry.action}\n"
            f"{entry.description}"
            f"{file_note}{change_note}{error_note}{task_note}\n"
            f"<sub>id: {entry.entry_id}</sub>\n\n"
        )

        with open(DEV_LOG_MD, "a", encoding="utf-8") as f:
            f.write(block)

    def render_md_tail(self, n_entries: int = 20) -> str:
        """Return the last N entries from DEVLOG.md as a string."""
        entries = self.recent_changes(minutes=99999, limit=n_entries)
        lines   = ["# Recent Dev Log\n"]
        for e in reversed(entries):
            lines.append(e.to_oneliner())
        return "\n".join(lines)


# ── Module-level singleton ────────────────────────────────────────────────────
dev_log = DevLog()


# ── Convenience top-level function (the public API spec calls for this) ───────
def update_dev_log(action: str, result: str, **kwargs) -> LogEntry:
    """
    Top-level convenience wrapper. Import and call anywhere:

        from dev_log import update_dev_log
        update_dev_log("config_change", "success",
                        description="Changed TTS_VOICE to JennyNeural",
                        file_path="config.py",
                        before_value="AriaNeural",
                        after_value="JennyNeural")
    """
    return dev_log.update_dev_log(action=action, result=result, **kwargs)
